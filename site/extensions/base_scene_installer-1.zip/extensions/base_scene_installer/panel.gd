extends VBoxContainer
## File selection and installation UI owned by the optional installer extension.
const Installation = preload("res://extensions/base_scene_installer/installation.gd")
var menu
var install_button: Button
var status: Label
var callback: JavaScriptObject
var incoming: FileAccess
var total := 0
var busy := false

func build(settings_menu) -> void:
	menu = settings_menu
	add_child(menu._label("Basisszenen installieren", 20, menu.ACTIVE))
	install_button = menu.add_action_button(self, "Aus Datei installieren …")
	install_button.pressed.connect(_choose)
	status = menu._label("", 18, menu.MUTED)
	add_child(status)
	BaseScenePackages.changed.connect(_refresh)
	visibility_changed.connect(_refresh)
	if OS.has_feature("web"):
		JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/base_scene_installer/package_file.js"), true)
		callback = JavaScriptBridge.create_callback(_browser_event)
	_refresh()

func _refresh() -> void:
	install_button.disabled = busy or not menu.simulation_scene_tree.stopped()
	if busy: return
	if not BaseScenePackages.startup_error.is_empty(): status.text = BaseScenePackages.startup_error
	elif not BaseScenePackages.installed.is_empty(): status.text = "Installiert: " + ", ".join(BaseScenePackages.installed.keys())
	else: status.text = "Paket herunterladen und die Datei auswählen. Installation bei Stop."

func _choose() -> void:
	if busy or not menu.simulation_scene_tree.stopped(): return
	busy = true
	_refresh()
	if OS.has_feature("web"):
		if not OS.is_userfs_persistent():
			_finish("Dauerhafter Browserspeicher ist nicht verfügbar.")
			return
		JavaScriptBridge.get_interface("VeskiPackageFile").choose(callback)
	else:
		var picker := FileDialog.new()
		picker.access = FileDialog.ACCESS_FILESYSTEM
		picker.file_mode = FileDialog.FILE_MODE_OPEN_FILE
		picker.filters = PackedStringArray(["*.zip ; VeSKi-Basisszenen-Paket"])
		add_child(picker)
		picker.file_selected.connect(func(path): picker.queue_free(); _desktop_file(path))
		picker.canceled.connect(func(): picker.queue_free(); _finish("Installation abgebrochen."))
		picker.popup_centered_ratio(0.8)

func _desktop_file(path: String) -> void:
	var source := FileAccess.open(path, FileAccess.READ)
	if source == null:
		_finish("Datei kann nicht gelesen werden.")
		return
	if not _start(source.get_length()): return
	while source.get_position() < source.get_length():
		if not _chunk(source.get_buffer(1024 * 1024)): return
		await get_tree().process_frame
	_complete()

func _browser_event(args: Array) -> void:
	var bridge = JavaScriptBridge.get_interface("VeskiPackageFile")
	match str(args[0]):
		"start": bridge.accepted = _start(int(args[1]))
		"chunk": bridge.accepted = _chunk(JavaScriptBridge.js_buffer_to_packed_byte_array(args[1]))
		"done": _complete.call_deferred()
		"cancel": _finish("Installation abgebrochen.")
		"error": _finish(str(args[1]))

func _start(bytes: int) -> bool:
	if not menu.simulation_scene_tree.stopped():
		_finish("Bitte die Simulation vor der Installation stoppen.")
		return false
	total = bytes
	incoming = FileAccess.open(Installation.incoming_path(), FileAccess.WRITE)
	if incoming == null:
		_finish("Nicht genügend Speicher oder kein Schreibzugriff.")
		return false
	return true

func _chunk(bytes: PackedByteArray) -> bool:
	if incoming == null: return false
	incoming.store_buffer(bytes)
	if incoming.get_error() != OK:
		_finish("Datei konnte nicht vollständig gespeichert werden.")
		return false
	status.text = "Paket einlesen: %d %%" % (100 * incoming.get_position() / maxi(total, 1))
	return true

func _complete() -> void:
	incoming.close()
	incoming = null
	status.text = "Paket prüfen …"
	await get_tree().process_frame
	var entry := Installation.read_package(Installation.incoming_path())
	if entry.is_empty():
		_finish("Ungültiges oder inkompatibles Basisszenen-Paket.")
		return
	var confirmation := ConfirmationDialog.new()
	confirmation.title = "Basisszenen-Paket installieren"
	confirmation.dialog_text = "%s · Version %s\n\nDas Paket kann Programmcode ausführen. Installiere es nur, wenn du der Quelle vertraust." % [entry.title, entry.version]
	confirmation.ok_button_text = "Quelle vertrauen und installieren"
	confirmation.cancel_button_text = "Abbrechen"
	add_child(confirmation)
	confirmation.confirmed.connect(func(): confirmation.queue_free(); _install(entry))
	confirmation.canceled.connect(func(): confirmation.queue_free(); _finish("Installation abgebrochen."))
	confirmation.popup_centered()

func _install(entry: Dictionary) -> void:
	status.text = "Paket dauerhaft speichern …"
	var error := await Installation.install_incoming(entry)
	menu.simulation_scene_tree.refresh()
	_finish("Installiert. Die Basisszenen stehen unter Szenen → Basis zur Auswahl." if error.is_empty() else error)

func _finish(message: String) -> void:
	if incoming:
		incoming.close()
		incoming = null
	DirAccess.remove_absolute(Installation.incoming_path())
	busy = false
	_refresh()
	status.text = message
