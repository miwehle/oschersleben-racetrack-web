extends RefCounted
## Installation is optional; mounted packages are owned by the core registry.
static func incoming_path() -> String:
	return "/tmp/veski-base-scene.zip" if OS.has_feature("web") else "user://base-scenes/incoming.zip"

static func read_package(path: String) -> Dictionary:
	var zip := ZIPReader.new()
	if zip.open(path) != OK: return {}
	var entry = JSON.parse_string(zip.read_file("manifest.json").get_string_from_utf8())
	var files := zip.get_files()
	zip.close()
	if not entry is Dictionary or entry.get("api") != 1: return {}
	if not entry.get("id") is String or not entry.id.replace("-", "_").is_valid_identifier(): return {}
	if not entry.get("title") is String or not entry.get("version") is String: return {}
	if not entry.get("bases") is Dictionary or entry.bases.is_empty(): return {}
	for id in entry.bases:
		if not id is String or not id.replace("-", "_").is_valid_identifier(): return {}
		if id != entry.id and not id.begins_with(entry.id + "_"): return {}
		var base = entry.bases[id]
		if not base is Dictionary or not base.has_all(["title", "script", "spawn", "heading", "height_reference", "height_datum"]): return {}
		if not base.title is String or not base.script is String or not base.height_datum is String: return {}
		if not base.script.begins_with("res://environments/" + id + "/") or ".." in base.script: return {}
		var script_path: String = base.script.trim_prefix("res://")
		if not files.has(script_path) and not files.has(script_path + ".remap"): return {}
		if not base.spawn is Array or base.spawn.size() != 2: return {}
		for value in [base.spawn[0], base.spawn[1], base.heading, base.height_reference, base.get("camera_far", 2500.0)]:
			if not (value is float or value is int) or not is_finite(value): return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null: return {}
	entry.bytes = file.get_length()
	entry.sha256 = FileAccess.get_sha256(path)
	return entry

static func install_incoming(entry: Dictionary) -> String:
	if _registry().installed.has(entry.id): return "Dieses Paket ist bereits installiert."
	for id in entry.bases:
		if _registry().bases.has(id): return "Eine Basisszene mit dieser ID ist bereits vorhanden."
	var destination: String = _registry().package_path(entry.id)
	if DirAccess.rename_absolute(incoming_path(), destination) != OK: return "Paket konnte nicht gespeichert werden."
	if OS.has_feature("web"):
		var source := FileAccess.open(destination, FileAccess.READ)
		var index := 0
		while source.get_position() < source.get_length():
			JavaScriptBridge.get_interface("VeskiPackageFile").beginSave()
			var part := FileAccess.open(_registry().part_path(entry.id, index), FileAccess.WRITE)
			if part == null: return "Paket konnte nicht gespeichert werden."
			var block := source.get_buffer(_registry().CHUNK_BYTES)
			part.store_buffer(block)
			if part.get_error() != OK: return "Paket konnte nicht gespeichert werden."
			part.close()
			var saved := await _confirm_saved(_registry().part_path(entry.id, index), block.size())
			if not saved.is_empty(): return saved
			index += 1
	var metadata_path: String = _registry().DIRECTORY + entry.id + ".json"
	if OS.has_feature("web"): JavaScriptBridge.get_interface("VeskiPackageFile").beginSave()
	var metadata := FileAccess.open(metadata_path, FileAccess.WRITE)
	if metadata == null: return "Paketbeschreibung konnte nicht gespeichert werden."
	var text := JSON.stringify(entry)
	metadata.store_string(text)
	metadata.close()
	if OS.has_feature("web"):
		var saved := await _confirm_saved(metadata_path, text.to_utf8_buffer().size())
		if not saved.is_empty(): return saved
	var error: String = _registry().mount(destination, entry)
	if not error.is_empty():
		DirAccess.remove_absolute(metadata_path)
		DirAccess.remove_absolute(destination)
	return error


static func _registry() -> Node:
	return Engine.get_main_loop().root.get_node("BaseScenePackages")

static func _confirm_saved(path: String, bytes: int) -> String:
	var bridge = JavaScriptBridge.get_interface("VeskiPackageFile")
	bridge.waitForSaved(ProjectSettings.globalize_path(path), bytes)
	JavaScriptBridge.force_fs_sync()
	while bridge.saving: await Engine.get_main_loop().process_frame
	return str(bridge.saveError)
