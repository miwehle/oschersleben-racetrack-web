# Basisszenen-Installer

Mitgelieferte, zuschaltbare Erweiterung für „Aus Datei installieren …“. `panel.gd` übernimmt Dateiauswahl und Quellenbestätigung; `installation.gd` prüft und installiert das Paket. Die Browser-Dateiauswahl liegt in `package_file.js`.

## Verwendung

Das Paket beim jeweiligen Landschaftsprojekt herunterladen. Simulation unter Szenen stoppen, den Basisszenen-Installer über den Erweiterungskatalog hinzufügen und unter Erweiterungen „Aus Datei installieren …“ wählen. Nach der Paketprüfung die vertrauenswürdige Quelle bestätigen und die Erfolgsmeldung abwarten. Anschließend unter Szenen → Basis eine installierte Landschaft auswählen. Pakete können Programmcode ausführen; die Formatprüfung ersetzt keine Prüfung ihrer Quelle.

`BaseScenePackages` liest beim Start nur die Beschreibungen installierter Pakete für den Auswahlkatalog. Erst beim Auswählen einer enthaltenen Basisszene wird ihr Paket zusammengesetzt, geprüft und geladen; danach bleibt es für die Sitzung geladen. Eine als Startszene gespeicherte Landschaft wird entsprechend beim Start geladen. Dies funktioniert unabhängig vom Installer. Entfernen des Installers entfernt nur sein Bedienfeld. Während einer offenen Dateiauswahl oder Installation bleibt er geladen. Bereits mit dem früheren festen Paketkatalog installierte Pakete einmal aus der vorhandenen ZIP neu installieren; ein erneuter Download ist nicht nötig.

Die Desktop-App speichert ZIP und Paketbeschreibung unter `user://base-scenes/`. Im Browser verwendet Godot IndexedDB: Das Paket wird in einzeln bestätigten 16-MiB-Dateien gespeichert. Eine gemeinsame große Transaktion schlug im Chrome-Test mit `InvalidBlob` fehl. Beim Start setzt der Kerndienst die Teile temporär zusammen und prüft ihre SHA-256-Summe. Website-Daten löschen entfernt auch die Installation. Der Web-Start mit installiertem Paket benötigt zusätzlich Speicher und Zeit für das lokale Laden. Eine Paket-Deinstallation über die Oberfläche ist noch offen.

## Paket-Schnittstelle, API 1

Eine mit derselben Godot-Version exportierte Ressourcen-ZIP enthält `manifest.json`:

```json
{
  "api": 1, "id": "example", "title": "Beispiellandschaft", "version": "1",
  "bases": {
    "example": {
      "title": "Tal", "description": "Beschreibung im Szenenbaum",
      "script": "res://environments/example/terrain.gd",
      "spawn": [0, 0], "heading": 0,
      "height_reference": 0, "height_datum": "lokal", "camera_far": 2500
    }
  }
}
```

Paket- und Basis-IDs bestehen aus Bezeichnern, zusätzlich sind Bindestriche erlaubt. Eine Basis-ID entspricht der Paket-ID oder beginnt mit ihr und einem Unterstrich. Ihre Ressourcen liegen unter `environments/<Basis-ID>/`. Der Installer akzeptiert exportierte Skripte samt Godot-Remap. Größe und Prüfsumme werden bei der Installation ermittelt und mit der Beschreibung lokal gespeichert. Sie erkennen spätere Beschädigungen, authentifizieren aber keinen Herausgeber.

Das Gelände-Skript erzeugt einen `Node3D` und bietet `height_at(x, z)` für die Bodenhöhe. Es richtet Darstellung und Bodenkollision selbst ein. Optional bereitet `ensure_surface(position)` eine gestreamte Physikoberfläche vor. VeSKi hängt den Knoten an die Spielwelt neben `Player`; das Gelände kann dessen Position für Streaming nutzen. `spawn` enthält X/Z in Metern, `heading` Grad und `height_reference` den Höhenbezug in Metern. `node_name` ist optional, Standard „Landscape“.

Paketbau, Veröffentlichung und landschaftsspezifische Integrationstests gehören zum jeweiligen Landschaftsprojekt. VeSKi prüft seine allgemeine Schnittstelle mit einem kleinen synthetischen Testpaket.
