extends Node
## The installer can be removed independently of the packages it installed.
var panel

func _ready() -> void:
	var menu = get_parent().get_node("Player/HUD/SettingsMenu")
	panel = preload("res://extensions/base_scene_installer/panel.gd").new()
	panel.name = "BaseSceneInstallerPanel"
	menu.extensions.add_child(panel)
	panel.build(menu)

func can_remove() -> bool:
	if is_instance_valid(panel) and panel.busy:
		panel.status.text = "Bitte die Dateiauswahl oder Installation zuerst abschließen."
		return false
	return true

func _exit_tree() -> void:
	if is_instance_valid(panel):
		panel.get_parent().remove_child(panel)
		panel.queue_free()
