extends VehicleView
## Display choice belongs to this aircraft extension; both views share the same physics.
const SETTINGS := "user://cessna172-visual.cfg"
const ASSETS := "res://extensions/cessna172/visual/"
static var detailed := true
var body: Node3D
var rig: Dictionary = {}
var pivots: Dictionary = {}
var _last_time := 0.0
var _phase := 0.0
var _state: Dictionary = {}

static func load_choice() -> void:
	var config := ConfigFile.new()
	if config.load(SETTINGS) == OK: detailed = config.get_value("visual", "detailed", true)

static func save_choice() -> void:
	var config := ConfigFile.new()
	config.set_value("visual", "detailed", detailed)
	if config.save(SETTINGS) != OK: push_error("Cessna-Darstellung konnte nicht gespeichert werden.")

func _ready() -> void:
	if OS.has_feature("web"):
		chase_offset = Vector3(0, 1.5, 10)
		chase_pitch = -1.2
	set_detailed(detailed)

func set_detailed(enabled: bool) -> void:
	var next: Node3D
	if enabled:
		var document := GLTFDocument.new()
		var data := GLTFState.new()
		var error := document.append_from_buffer(FileAccess.get_file_as_bytes(ASSETS + "c172p.glb"), "", data)
		if error == OK: next = document.generate_scene(data)
		if next == null:
			push_error("C172P-Außenmodell konnte nicht geladen werden (%s)." % error)
			return
	else:
		next = preload("simple_view.tscn").instantiate()
	if is_instance_valid(body):
		remove_child(body)
		body.queue_free()
	body = next
	add_child(body)
	pivots.clear()
	if enabled:
		rig = JSON.parse_string(FileAccess.get_file_as_string(ASSETS + "rig.json"))
		for key in rig: pivots[key] = body.find_child(key + "_pivot", true, false)
	apply_model_state(_state)

func apply_model_state(state: Dictionary) -> void:
	_state = state
	if state.is_empty() or pivots.is_empty(): return
	# JSBSim reports actual deflections in radians, not normalized stick commands.
	for pair in [["leftaileron", "left_aileron_rad", 1], ["rightaileron", "right_aileron_rad", 1],
		["elevatorleft", "elevator_rad", -1], ["elevatorright", "elevator_rad", -1], ["rudder_1", "rudder_rad", 1]]:
		_rotate(pair[0], state.get(pair[1], 0.0) * pair[2])
	var time: float = state.get("time_s", 0.0)
	var rpm: float = state.get("propeller_rpm", 0.0)
	if time < _last_time: _phase = 0.0
	_phase = fposmod(_phase - maxf(0, time - _last_time) * rpm * TAU / 60.0, TAU)
	_last_time = time
	_rotate("Propeller", _phase)
	# At flight RPM use the source's transparent blur disk instead of strobing blades.
	body.find_child("Propeller", true, false).visible = rpm < 500.0
	body.find_child("Propeller_Fast", true, false).visible = rpm >= 500.0

func _rotate(key: String, angle: float) -> void:
	var axis: Array = rig[key].axis
	pivots[key].quaternion = Quaternion(Vector3(axis[0], axis[1], axis[2]), angle)
