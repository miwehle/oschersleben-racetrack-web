# Flugassistent (Flight Assist)

Das Flugmodell steuert auf beiden Achsen Winkelgeschwindigkeiten. Ohne Assistent gilt die mittlere Stufe: standardmäßig maximal 25°/s horizontal und vertikal. Beide Grundwerte gehören ins Fahrzeugmodell „Erkundungsflug“. Die maximale Steig-/Sinkwinkelbegrenzung bleibt separat. Neutral hält den Steigwinkel und lässt die horizontale Drehbewegung mit der gewohnten Glättung auslaufen. Es gibt keine automatische Rückkehr zum Horizontalflug. Die Standard-Stickkennlinie ist auf beiden Achsen linear.

Der optionale Assistent ergänzt **Schnell** und **Fein**. **LB** schaltet dauerhaft zwischen Mitte (wie ohne Assistent) und Schnell um. **RB** hat beim Fliegen keine Funktion. **Y halten** überschreibt beide mit Fein; beim Loslassen gilt wieder die gewählte Stufe. Die Wahl bleibt während der Sitzung erhalten; beim Start oder erneuten Hinzufügen gilt Mitte. Die frühere zusätzliche Trägheit ist entfernt. Alle Stufen verwenden dieselbe horizontale Glättung; vertikal steuert der Stick unmittelbar die Änderungsrate des Winkels.

## Parameter

Unter Einstellungen → Erweiterungen → Flugassistent öffnen „Winkelgeschwindigkeiten“ und „Weitere Parameter“ zwei unabhängig verschiebbare HUD-Panels. Das erste enthält die sechs Winkelgeschwindigkeiten für Fein, Mitte und Schnell. Das zweite enthält maximalen Steig-/Sinkwinkel, Stick-Totzone, horizontale und vertikale Lenkprogression, Y-Übergangszeit und Marker-Deckkraft. Beide bleiben beim Weiterfliegen bedienbar. Ohne geladene Erweiterung gibt es keine Oberfläche zum Ändern dieser Werte.

- **Max. Steig- und Sinkwinkel**: 1–90°, Standard 90°.
- **Mitte (LB): Horizontal / Vertikal**: Standard 25 / 25°/s, auch ohne Assistent wirksam.
- **Stick-Totzone / Lenkprogression horizontal und vertikal**: Standard 3 % / 1 / 1.
- **Marker: Deckkraft (%)**: 0–100, Standard 50.
- **Flugrichtung halten (Y): Horizontal (°/s)**: Standard 10.
- **Flugrichtung halten (Y): Vertikal (°/s)**: Standard 10.
- **Flugrichtung halten (Y): Übergangszeit (s)**: 0–2, Standard 0,2. Nur beim Drücken wird die vorhandene horizontale Drehbewegung abgefangen. Bei neutralem Stick kommt sie innerhalb dieser Zeit zum Stillstand; der Kurs wandert währenddessen noch etwas weiter. 0 stoppt sofort. Loslassen oder Unterbrechen bricht den Übergang ab.
- **Schnellsteuerung (LB): Horizontal (°/s)**: Standard 50.
- **Schnellsteuerung (LB): Vertikal (°/s)**: Standard 50.

Die vier Assistenz-Drehraten sind direkt von 0,05 bis 720°/s in 0,05er-Schritten einstellbar. Sie bleiben unabhängig von späteren Änderungen an den mittleren Modellwerten. Die Standardabstufung ist Fein < Mitte < Schnell; die frei einstellbaren Werte erlauben auch andere Abstimmungen. Die Begrenzung des maximalen Pitchwinkels gilt für alle Stufen.

Alle Zahlenfelder verwenden die gemeinsame Zahleneingabe mit Dezimalkomma, ohne SpinBox-Pfeiltasten. Enter oder Verlassen des Feldes übernimmt die Eingabe in den Einstellungsentwurf, Esc verwirft sie. Während des Tippens bleiben Text und Cursor unverändert; die Prüfung auf ungespeicherte Änderungen formatiert keine Eingaben um.

„Standard wiederherstellen“ setzt jeweils nur die sechs Parameter des betreffenden Panels auf ihre Werkswerte zurück. Übernehmen gilt für die Sitzung, Speichern dauerhaft, Abbrechen stellt die zuvor angewendeten Werte wieder her.

Alle Modell-, Steuerungs- und Assistentenparameter gelten gemeinsam für den Erkundungsflug und werden in `user://erkundungsflug.cfg` gespeichert. Sie gehören zu keinem Fahrzeug-Setup. Ein Wechsel des Fahr-Setups verändert sie nicht. Auch ohne aktive Erweiterung gelten die gespeicherten Modell- und Steuerungswerte weiter; Fein/Schnell und die Einstelloberfläche entfallen. Die Marker-Deckkraft bleibt in `user://flight_path_assist.cfg`, die beiden Panelpositionen separat in `user://flight_assist_rates_panel.cfg` und `user://flight_assist_other_panel.cfg`.

Erkundungsflug wird nicht als Fahrzeug-Setup angeboten. Vorhandene persönliche Flug-Setups werden beim Laden entfernt, ohne ihre Werte zu übernehmen. Die gemeinsame Konfiguration beginnt mit Standardwerten. X schaltet weiterhin aus jedem Fahr-Setup in den Erkundungsflug und zurück.

Pause, Fokusverlust, Gamepad-Trennung, Modus-/Steuerungswechsel, Rücksetzen und Entfernen der Erweiterung beenden das gehaltene Y-Hold. Danach Y neu drücken. A und B haben im Flug keine Assistenzfunktion. Beim Fahren hält B das Tempo; A ist für den geplanten Rückwärtsgang frei. In Menüs bleiben A/B Bestätigen/Zurück und LB/RB der Tabwechsel; X wechselt Fahren/Fliegen.

## Marker

Der Marker zeigt die gemessene Bewegungsrichtung, einschließlich automatischem Sinkflug und Höhenbegrenzungen, aber keine vorhergesagte Kurve. Bei gehaltenem Y werden die weißen Innenlinien blassrot; schwarze Kontur und Deckkraft bleiben erhalten. Er erkennt keine Ziele oder Ringe. Im Stillstand, bei Pause oder Fokusverlust und außerhalb des Blickfelds ist er unsichtbar. Blickrichtung und Zoom werden berücksichtigt; die Symbolgröße folgt der Oberflächengröße. Er blockiert keine Eingaben. Frühere Flugwegmarker-Auswahl und Deckkraft werden übernommen.

## Tests

Mit isoliertem Benutzerprofil: `--headless --path godot --script res://extensions/flight_path_assist/tests/test_fine_steering.gd` prüft die drei Stufen und das Speichern. `test_hold.gd` prüft Einrasten und Markerfarbe, `test_marker.gd` Projektion und Einstellungen.

`test_setup_panel.gd` prüft das Entfernen alter Flug-Setups, das HUD-Panel im laufenden Flug, Unabhängigkeit vom Fahr-Setup, Standards, Abbrechen, Neustart und das Deaktivieren der Erweiterung. `test_flight_setups.gd` prüft das Laden ohne Assistent und den X-Wechsel aus jedem Standard-Fahr-Setup.

Die Hintergrund-Deckkraft aller Parameterpanels wird gemeinsam unter Einstellungen → Darstellung → Parameterpanels: Deckkraft eingestellt (Standard 20 %). Schrift und Bedienelemente bleiben deckend. Der Wert gehört zu den allgemeinen Darstellungseinstellungen und wird von deren „Standard wiederherstellen“ zurückgesetzt.
