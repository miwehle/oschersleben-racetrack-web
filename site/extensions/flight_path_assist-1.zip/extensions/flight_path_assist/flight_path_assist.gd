extends Control
## Optional marker, Hold, and fine flight steering.
const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
var symbol: ImageTexture
const HOLD_COLOR := Color(1.0, 0.65, 0.65)
const DEFAULT_OPACITY := 50
const SETTINGS := "user://flight_path_assist.cfg"
var vehicle: Vehicle
var step_origin := Vector3.ZERO
var movement := Vector3.ZERO
var opacity := DEFAULT_OPACITY
var opacity_input := Range.new()
var fast_selected := false # Session choice; shoulder release does not change it.
var fast_horizontal_rate: float:
	get: return vehicle.flight.limits.get("fast_horizontal_rate", DrivingSetup.ASSIST_DEFAULTS["fast_horizontal_rate"])
var fast_vertical_rate: float:
	get: return vehicle.flight.limits.get("fast_vertical_rate", DrivingSetup.ASSIST_DEFAULTS["fast_vertical_rate"])
var steering_rate: float:
	get: return vehicle.flight.limits.get("steering_rate", DrivingSetup.ASSIST_DEFAULTS["steering_rate"])
var vertical_steering_rate: float:
	get: return vehicle.flight.limits.get("vertical_steering_rate", DrivingSetup.ASSIST_DEFAULTS["vertical_steering_rate"])
var hold_entry_seconds: float:
	get: return vehicle.flight.limits.get("hold_entry_seconds", DrivingSetup.ASSIST_DEFAULTS["hold_entry_seconds"])
var number_fields: Dictionary = {} # Range -> LineEdit, using the shared numeric input.
var rows: VBoxContainer
var menu
var panel
var other_panel
var other_open_button: Button
var open_button: Button

func _ready() -> void:
	var image := Image.new()
	image.load_svg_from_string(FileAccess.get_file_as_string("res://extensions/flight_path_assist/marker.svg"))
	symbol = ImageTexture.create_from_image(image)
	vehicle = get_parent().get_node("Player")
	var saved := ConfigFile.new()
	if saved.load(SETTINGS) != OK:
		saved.load("user://flight_path_marker.cfg") # Preserve the marker's saved opacity.
	opacity = clampi(int(saved.get_value("view", "opacity", DEFAULT_OPACITY)), 0, 100)
	self_modulate.a = opacity / 100.0
	menu = vehicle.get_node("HUD/SettingsMenu")
	rows = menu.add_extension_settings("Flugassistent")
	vehicle.flight.limits.merge(DrivingSetup.ASSIST_DEFAULTS)
	panel = _create_panel(false)
	other_panel = _create_panel(true)
	open_button = menu.add_action_button(rows, "Winkelgeschwindigkeiten", _open_panel.bind(panel))
	other_open_button = menu.add_action_button(rows, "Weitere Parameter", _open_panel.bind(other_panel))
	_add_number("Marker-Deckkraft (%)", opacity_input, opacity, 0)
	other_panel.rows.move_child(other_panel.rows.get_node("Reset"), -1)
	other_panel.rows.get_node("Reset").pressed.connect(func():
		opacity_input.value = DEFAULT_OPACITY
		opacity_input.value_changed.emit(opacity_input.value))
	menu.extension_changes.append(_has_changes)
	menu.save_requested.connect(_apply.bind(true))
	menu.session_applied.connect(_apply.bind(false))
	menu.discard_requested.connect(_discard)
	process_priority = 20 # Project after Vehicle has updated the camera.
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	vehicle.physics_started.connect(_begin_step)
	vehicle.physics_finished.connect(_end_step)
	vehicle.flight_steering_toggle_requested.connect(_toggle_response)
	vehicle.reduced_flight_steering_requested.connect(_set_fine_steering)
	vehicle.control_mode_changed.connect(_cancel_assistance)
	vehicle.simulation_event.connect(_on_event)
	hide()
	queue_redraw()

func _create_panel(other: bool):
	var result = preload("res://extensions/flight_path_assist/assist_panel.gd").new()
	result.other_parameters = other
	result.model = vehicle.flight.limits
	result.controls = vehicle.gamepad.flight_settings
	vehicle.get_node("HUD").add_child(result)
	result.apply_values(menu.setups.flight_values)
	menu.setups.flight_panels.append(result)
	return result

func _open_panel(target) -> void:
	menu.setups.open_flight_panel(menu.setups.flight_panels.find(target))
	target.reset_size()

func _begin_step() -> void:
	step_origin = vehicle.global_position
	_update_response()

func _end_step() -> void:
	# Includes automatic descent and height limits, unlike the aircraft's nose.
	movement = vehicle.global_position - step_origin

func _process(_delta: float) -> void:
	# Tint white interiors; black stays black and opacity remains unchanged.
	self_modulate = Color(HOLD_COLOR if vehicle.gamepad.fine_steering_active else Color.WHITE, opacity / 100.0)
	var camera := vehicle.camera
	if not vehicle.flight_mode or vehicle.simulation_paused or not vehicle.has_focus or not camera or not camera.is_current() or movement.length_squared() < 0.000001:
		hide()
		return
	var target := camera.get_camera_transform().origin + movement.normalized() * 1000.0
	if camera.is_position_behind(target):
		hide()
		return
	var point := camera.unproject_position(target)
	if not get_viewport_rect().has_point(point):
		hide()
		return
	position = point
	scale = Vector2.ONE * UiLayout.factor
	show()

func _draw() -> void:
	# Composite black and white once, then apply opacity to the whole symbol.
	draw_texture_rect(symbol, Rect2(-16, -16, 32, 32), false)

func _has_changes() -> bool:
	# Reading dirty state must never commit or reformat text while typing.
	for source in number_fields:
		var value = UiNumbers.parse(number_fields[source].text)
		if value == null or not is_equal_approx(value, source.value):
			return true
	return int(opacity_input.value) != opacity

func _apply(persist: bool) -> void:
	for field in number_fields.values(): field.focus_exited.emit()
	opacity = int(opacity_input.value)
	self_modulate.a = opacity / 100.0
	if persist and not DrivingSetup.temporary:
		var saved := ConfigFile.new()
		saved.set_value("view", "opacity", opacity)
		if saved.save(SETTINGS) != OK:
			push_warning("Flugassistent: Einstellungen konnten nicht gespeichert werden.")

func _discard() -> void:
	opacity_input.value = opacity
	opacity_input.value_changed.emit(opacity_input.value)

func _exit_tree() -> void:
	if is_instance_valid(vehicle):
		_cancel_assistance()
	if is_instance_valid(menu):
		menu.extension_changes.erase(_has_changes)
		menu.setups.flight_panels.erase(panel)
		menu.setups.flight_panels.erase(other_panel)
	if is_instance_valid(panel): panel.queue_free()
	if is_instance_valid(other_panel): other_panel.queue_free()
	if is_instance_valid(rows):
		rows.get_parent().get_child(rows.get_index() - 1).queue_free()
		rows.queue_free()

func _toggle_response() -> void:
	if vehicle.flight_mode and not vehicle.flight.landing and not vehicle.simulation_paused and vehicle.has_focus:
		fast_selected = not fast_selected
		_update_response()

func _update_response() -> void:
	var horizontal := 1.0
	var vertical := 1.0
	if vehicle.flight_mode and not vehicle.flight.landing and not vehicle.simulation_paused and vehicle.has_focus:
		if vehicle.gamepad.fine_steering_active:
			horizontal = steering_rate / float(vehicle.flight.limits.turn_deg_s)
			vertical = vertical_steering_rate / float(vehicle.flight.limits.pitch_rate_deg_s)
		elif fast_selected:
			horizontal = fast_horizontal_rate / float(vehicle.flight.limits.turn_deg_s)
			vertical = fast_vertical_rate / float(vehicle.flight.limits.pitch_rate_deg_s)
	vehicle.gamepad.flight_steering_scale = horizontal
	vehicle.gamepad.flight_pitch_steering_scale = vertical

func _set_fine_steering(pressed: bool) -> void:
	if not pressed:
		vehicle.flight.cancel_hold_entry()
		vehicle.gamepad.fine_steering_active = false
		vehicle.gamepad.flight_steering_scale = 1.0
		vehicle.gamepad.flight_pitch_steering_scale = 1.0
	elif vehicle.flight_mode and not vehicle.flight.landing and not vehicle.simulation_paused and vehicle.has_focus:
		if not vehicle.gamepad.fine_steering_active:
			vehicle.flight.begin_hold(hold_entry_seconds)
		vehicle.gamepad.fine_steering_active = true
		vehicle.gamepad.flight_steering_scale = steering_rate / float(vehicle.flight.limits.turn_deg_s)
		vehicle.gamepad.flight_pitch_steering_scale = vertical_steering_rate / float(vehicle.flight.limits.pitch_rate_deg_s)

	_update_response()

func _cancel_assistance() -> void:
	vehicle.flight.cancel_hold_entry()
	vehicle.gamepad.fine_steering_active = false
	vehicle.gamepad.flight_steering_scale = 1.0
	vehicle.gamepad.flight_pitch_steering_scale = 1.0

func _on_event(kind: StringName, _lap: int, _seconds: float) -> void:
	if kind == &"mode_change" and not vehicle.flight_mode:
		panel.hide()
		other_panel.hide()
	if kind in [&"mode_change", &"reset", &"pause", &"focus_out"]:
		_cancel_assistance()
		movement = Vector3.ZERO

func _add_number(caption: String, field: Range, value: float, minimum: float, maximum := 100.0, increment := 1.0) -> void:
	var row := HBoxContainer.new()
	other_panel.rows.add_child(row)
	var label := Label.new()
	label.text = caption
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(label)
	field.min_value = minimum
	field.max_value = maximum
	field.step = increment
	field.value = value
	field.hide()
	row.add_child(field)
	var edit := LineEdit.new()
	edit.custom_minimum_size.x = 110
	edit.alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(edit)
	number_fields[field] = edit
	UiNumbers.bind_field(edit, field, "%.0f" if increment >= 1 else "%.2f", other_panel.rows)
