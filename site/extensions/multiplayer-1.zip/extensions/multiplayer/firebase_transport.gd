extends Node
## Implements the transport contract in MULTIPLAYER_DESIGN.md.
## Firebase configuration, browser URLs, JSON and JS lifetime stay here.

signal event_received(event: Dictionary)

var _bridge: JavaScriptObject
var _callback: JavaScriptObject

func start() -> void:
	if not OS.has_feature("web"):
		return
	JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/multiplayer/firebase_bridge.js"), true)
	_bridge = JavaScriptBridge.get_interface("OscherslebenMultiplayer")
	_callback = JavaScriptBridge.create_callback(_on_event)
	_bridge.bind(_callback)

func is_available() -> bool:
	return _bridge != null

func initial_invitation() -> String:
	return str(_bridge.initialRoom()) if is_available() else ""

func create_room_code() -> String:
	return str(_bridge.newRoom()) if is_available() else ""

func join(invitation: String, nickname: String) -> void:
	if not is_available():
		return
	var room := invitation.strip_edges()
	if "#room=" in room:
		room = room.get_slice("#room=", 1).get_slice("&", 0)
	_bridge.join(FileAccess.get_file_as_string("res://extensions/multiplayer/firebase_config.json"), room, nickname)

func leave() -> void:
	if is_available():
		_bridge.leave()

func send_state(state: Dictionary) -> void:
	if is_available():
		_bridge.send(JSON.stringify(state))

func statistics() -> Dictionary:
	if is_available():
		var result: Variant = JSON.parse_string(str(_bridge.stats()))
		if result is Dictionary:
			return result
	return {"sent": 0, "received": 0}

func _on_event(args: Array) -> void:
	if args.is_empty():
		return
	var event: Variant = JSON.parse_string(str(args[0]))
	if event is Dictionary:
		event_received.emit(event)

func stop() -> void:
	if is_available():
		# Unbind before releasing the retained Godot callback.
		_bridge.bind(null)
		_bridge.dispose()
	_bridge = null
	_callback = null

func _exit_tree() -> void:
	stop()
