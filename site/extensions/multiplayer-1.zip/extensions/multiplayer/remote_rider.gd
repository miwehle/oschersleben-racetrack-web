extends Node3D
## Pure presentation: no transport, input, local camera or driving physics.

const PREDICTION_LIMIT := 0.25
const SMOOTHING_SECONDS := 0.08
const STALE_SECONDS := 3.0
var snapshot: Dictionary = {}
var received_at := 0.0
var initial_age := 0.0
var label: Label3D
var show_uncertainty := false
var correction := Vector3.ZERO
var yaw_correction := 0.0
var errors := Vector2.ZERO # Longitudinal / transverse observed prediction error.
var receive_interval := 0.0
var ellipse: MeshInstance3D

func data_age() -> float:
	return initial_age + maxf(0, Time.get_ticks_msec() / 1000.0 - received_at)

static func velocity(state: Dictionary) -> Vector3:
	if state.paused or state.crashed:
		return Vector3.ZERO
	return Vector3(state.vx, state.vy, state.vz)

func uncertainty_radii(age: float) -> Vector2:
	# Heuristic, not a statistical confidence interval. No acceleration prediction.
	return Vector2.ONE * (0.25 + age * age) + errors * (1.0 + age / maxf(receive_interval, 0.067))


static func predict(state: Dictionary, seconds: float) -> Transform3D:
	var t := clampf(seconds, 0.0, PREDICTION_LIMIT)
	var p := Vector3(state.x, state.y, state.z)
	var yaw := float(state.yaw)
	var turn := float(state.turn)
	if not state.paused and not state.crashed:
		p += velocity(state) * t
		yaw += turn * t
	return Transform3D(Basis(Vector3.UP, yaw), p)

func _ready() -> void:
	add_child(preload("res://vehicles/landspeeder.tscn").instantiate())
	label = Label3D.new()
	label.position.y = 0.6
	label.modulate = Color.from_hsv(float(absi(name.hash()) % 360) / 360.0, 0.45, 1.0)
	label.font_size = 48
	label.pixel_size = 0.008
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(label)
	ellipse = MeshInstance3D.new()
	ellipse.mesh = _uncertainty_mesh()
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.albedo_color = Color(0.4, 0.8, 1, 0.55)
	ellipse.material_override = material
	ellipse.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ellipse)
	ellipse.top_level = true
	ellipse.hide()

static func _uncertainty_mesh() -> ImmediateMesh:
	var mesh := ImmediateMesh.new()
	# Open cylinder mantle, 25 cm high; no floor or lid.
	# Build once; the existing transform scales it with the uncertainty ellipse.
	mesh.surface_begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(64):
		var angle := TAU * i / 64.0
		var next_angle := TAU * (i + 1) / 64.0
		var a := Vector3(cos(angle), 0, sin(angle))
		var b := Vector3(cos(next_angle), 0, sin(next_angle))
		var up := Vector3.UP * 0.25
		var vertices := [a, b, a + up, b, b + up, a + up]
		for vertex in vertices:
			mesh.surface_add_vertex(vertex)
	mesh.surface_end()
	return mesh

func accept(state: Dictionary, age_seconds: float) -> void:
	if not snapshot.is_empty() and float(state.t) <= float(snapshot.t):
		return
	var snap := snapshot.is_empty() or int(state.revision) != int(snapshot.get("revision", -1))
	var now := Time.get_ticks_msec() / 1000.0
	var displayed_now := transform
	if not snap:
		# Advance the previous estimate to the same instant before comparing.
		# Otherwise each message would reintroduce one render frame of lag.
		displayed_now = predict(snapshot, initial_age + now - received_at)
		displayed_now.origin += correction
		displayed_now.basis = Basis(Vector3.UP, displayed_now.basis.get_euler().y + yaw_correction)
	if not snap:
		receive_interval = maxf(0.001, now - received_at)
		var dt := (float(state.t) - float(snapshot.t)) / 1000.0
		var error := Vector3(state.x, state.y, state.z) - predict(snapshot, dt).origin
		var direction := velocity(snapshot)
		direction.y = 0
		direction = direction.normalized() if direction.length() > 0.1 else Vector3.FORWARD
		var observed := Vector2(absf(error.dot(direction)), absf(error.dot(direction.cross(Vector3.UP))))
		var decayed := errors * exp(-receive_interval / 2.0)
		errors = Vector2(maxf(observed.x, decayed.x), maxf(observed.y, decayed.y))
	else:
		errors = Vector2.ZERO
		receive_interval = 0.0
	snapshot = state.duplicate()
	received_at = now
	initial_age = maxf(age_seconds, 0.0)
	var target := predict(snapshot, initial_age)
	if snap or position.distance_to(target.origin) > 12.0:
		transform = target
		correction = Vector3.ZERO
		yaw_correction = 0.0
	else:
		correction = displayed_now.origin - target.origin
		yaw_correction = angle_difference(target.basis.get_euler().y, displayed_now.basis.get_euler().y)
	label.text = str(state.nick) + (" (Pause)" if state.paused else "")
	visible = true

func _process(delta: float) -> void:
	if snapshot.is_empty():
		return
	var age := data_age()
	visible = age < STALE_SECONDS
	var target := predict(snapshot, age)
	var decay := exp(-delta / SMOOTHING_SECONDS)
	correction *= decay
	yaw_correction *= decay
	# Follow the current estimate directly; only the correction offset decays.
	position = target.origin + correction
	rotation.y = target.basis.get_euler().y + yaw_correction
	ellipse.visible = show_uncertainty and visible
	if ellipse.visible:
		var radii := uncertainty_radii(age)
		var v := velocity(snapshot)
		var course := atan2(-v.x, -v.z) if Vector2(v.x, v.z).length() > 0.1 else float(snapshot.yaw)
		var axes := Basis(Vector3.UP, course)
		# Include the displayed correction offset as extra uncertainty.
		radii.x += absf(correction.dot(-axes.z))
		radii.y += absf(correction.dot(axes.x))
		ellipse.global_transform = Transform3D(axes.scaled_local(Vector3(radii.y, 1, radii.x)), global_position + Vector3(0, -0.3, 0))
