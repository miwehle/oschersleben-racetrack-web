extends Node3D
## Local X points right, Y up and -Z in the direction of travel.
var tube: float
var road_edges: Vector2
var ring: bool
var radius: float
var paint := ShaderMaterial.new()

func build(spec: Dictionary, shape: Dictionary) -> void:
	ring = spec.ring
	radius = shape.diameter * 0.5
	tube = shape.tube
	paint.shader = preload("res://extensions/ringflug/target.gdshader")
	paint.set_shader_parameter("ring", ring)
	if ring:
		var torus := TorusMesh.new()
		torus.outer_radius = radius + tube
		torus.inner_radius = radius
		torus.rings = 64
		torus.ring_segments = 10
		_piece(torus).rotation.x = PI / 2
	else:
		road_edges = Vector2(_road_edge(-1), _road_edge(1))
		var edge := road_edges.x if spec.side < 0 else road_edges.y
		_add_cone(edge + spec.side * (0.30 + 0.20))

func _add_cone(x: float) -> void:
	var foot := to_global(Vector3(x, 0, 0))
	var ray := PhysicsRayQueryParameters3D.create(foot + Vector3.UP * 5, foot - Vector3.UP * 5, 3)
	var hit := get_world_3d().direct_space_state.intersect_ray(ray)
	if not hit.is_empty(): foot.y = hit.position.y
	var base := BoxMesh.new()
	base.size = Vector3(0.40, 0.04, 0.40)
	_piece(base).global_position = foot + Vector3.UP * 0.02
	var cone := CylinderMesh.new()
	cone.height = 0.71
	cone.bottom_radius = 0.18
	cone.top_radius = 0.025
	cone.radial_segments = 24
	cone.rings = 0
	_piece(cone).global_position = foot + Vector3.UP * (0.04 + cone.height / 2)

func _pavement(x: float) -> Dictionary:
	var center := to_global(Vector3(x, 0, 0))
	var ray := PhysicsRayQueryParameters3D.create(center + Vector3.UP * 3, center - Vector3.UP * 3, 1)
	var hit := get_world_3d().direct_space_state.intersect_ray(ray)
	if hit.is_empty(): return {}
	# The asphalt layer also includes pit lane and paved runoff.
	return hit if String(hit.collider.get_parent().name).begins_with("Motorcycle track | Image boundaries") else {}

func _road_edge(side: int) -> float:
	var inside := 0.0
	while inside < 50 and not _pavement(side * (inside + 0.5)).is_empty():
		inside += 0.5
	var outside := inside + 0.5
	for i in 6:
		var middle := (inside + outside) * 0.5
		if _pavement(side * middle).is_empty(): outside = middle
		else: inside = middle
	return side * outside

func _piece(mesh: Mesh) -> MeshInstance3D:
	var piece := MeshInstance3D.new()
	piece.mesh = mesh
	piece.material_override = paint
	piece.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(piece)
	return piece

func crossed(from: Vector3, to: Vector3, flying: bool) -> bool:
	if flying != ring: return false
	var a := to_local(from)
	var b := to_local(to)
	if a.z < 0 or b.z >= 0: return false
	var point := a.lerp(b, a.z / (a.z - b.z))
	if ring: return Vector2(point.x, point.y).length_squared() <= radius * radius
	if point.x < road_edges.x or point.x > road_edges.y: return false
	var pavement := _pavement(point.x)
	if pavement.is_empty(): return false
	var clearance: float = to_global(point).y - pavement.position.y
	return clearance >= -0.5 and clearance <= 3

func flash() -> void:
	paint.set_shader_parameter("hit", 1.0)
	create_tween().tween_property(paint, "shader_parameter/hit", 0.0, 0.65)

func add_shadow(ray: Vector3, space: PhysicsDirectSpaceState3D) -> MeshInstance3D:
	# Project a feathered annulus once onto the actual asphalt or terrain.
	var mesh := ImmediateMesh.new()
	var mat := StandardMaterial3D.new()
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	var offsets := [-0.28, tube * 0.25, tube * 0.75, tube + 0.28]
	var opacity := [0.0, 0.27, 0.27, 0.0]
	var samples: Array[PackedVector3Array] = []
	for offset: float in offsets:
		var row := PackedVector3Array()
		for i in 64:
			var angle := TAU * i / 64
			var origin := to_global(Vector3(cos(angle), sin(angle), 0) * (radius + offset))
			var hit := space.intersect_ray(PhysicsRayQueryParameters3D.create(origin, origin + ray * 400, 3))
			if hit.is_empty(): return null
			row.append(to_local(hit.position + Vector3.UP * 0.035))
		samples.append(row)
	for band in 3:
		mesh.surface_begin(Mesh.PRIMITIVE_TRIANGLE_STRIP, mat)
		for i in 65:
			for row in [band, band + 1]:
				mesh.surface_set_color(Color(0.04, 0.05, 0.06, opacity[row]))
				mesh.surface_add_vertex(samples[row][i % 64])
		mesh.surface_end()
	var shadow := MeshInstance3D.new()
	shadow.mesh = mesh
	shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(shadow)
	return shadow
