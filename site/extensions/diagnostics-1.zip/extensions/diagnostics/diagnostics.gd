extends Node

const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
## Controller physics time is accumulated per displayed frame; transport and UI stay here.
signal dialog_visibility_changed(is_open: bool)
var enabled := false
var minimal_enabled := false
var ground_enabled := false
var ground_trace = preload("res://extensions/diagnostics/ground_trace.gd").new()
var dialog: Control
var bridge: JavaScriptObject
var callback: JavaScriptObject
var _gpu_query_started := false
var _next_gpu_probe_us := 0
var physics_time_us := 0
var reference
var _applying := false
var player
var settings_menu
var controls: VBoxContainer
var removal_hint := Label.new()
var steering_dialog = preload("res://extensions/diagnostics/steering_diagnostics_dialog.gd").new()
var instruments: Array[Control] = []
var presentation_start_us := 0
var physics_start_us := 0

func _ready() -> void:
	player = get_parent().get_node("Player")
	settings_menu = player.get_node("HUD/SettingsMenu")
	controls = settings_menu.add_extension_tab("Diagnose")
	if OS.has_feature("web"):
		settings_menu.add_action_button(controls, "Diagnose öffnen", show_settings)
	settings_menu.add_action_button(controls, "Gamepad-Diagnose öffnen", _show_steering)
	removal_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	controls.add_child(removal_hint)
	for kind in 3:
		var instrument = preload("res://extensions/diagnostics/steering_diagnostics.gd").new()
		instrument.pad = player.gamepad
		instrument.trigger_mode = kind == 1
		instrument.brake_mode = kind == 2
		player.get_node("HUD").add_child(instrument)
		instruments.append(instrument)
	player.get_node("HUD").add_child(steering_dialog)
	steering_dialog.enabled_changed.connect(_toggle_instrument.bind(0))
	steering_dialog.throttle_enabled_changed.connect(_toggle_instrument.bind(1))
	steering_dialog.brake_enabled_changed.connect(_toggle_instrument.bind(2))
	steering_dialog.closed.connect(_return_to_settings)
	dialog_visibility_changed.connect(_dialog_visibility)
	player.presentation_started.connect(_presentation_started)
	player.presentation_finished.connect(_presentation_finished)
	player.physics_started.connect(_physics_started)
	player.physics_finished.connect(_physics_finished)
	player.simulation_step_started.connect(_step_started)
	player.ground_contact_failed.connect(_ground_failed)
	player.simulation_event.connect(_simulation_event)
	if not OS.has_feature("web"):
		return
	reference = preload("res://extensions/diagnostics/reference_benchmark.gd").new()
	add_child(reference)
	JavaScriptBridge.eval("window.OscherslebenUiNumber = (n, digits) => n.toFixed(digits).replace('.', %s)" % JSON.stringify(UiNumbers.DECIMAL_SEPARATOR), true)
	JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/diagnostics/js/live_frame_stats.js"), true)
	JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/diagnostics/js/ui/overlay_drag.js"), true)
	JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/diagnostics/js/ui/frame_timeline.js"), true)
	JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/diagnostics/js/gpu_timer.js"), true)
	JavaScriptBridge.eval(FileAccess.get_file_as_string("res://ui/session_info.js"), true)
	JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/diagnostics/js/minimal_measurement.js"), true)
	JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/diagnostics/js/ui/frame_histogram.js"), true)
	JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/diagnostics/js/performance.js"), true)
	bridge = JavaScriptBridge.get_interface("OscherslebenDiagnostics")
	callback = JavaScriptBridge.create_callback(func(args):
		enabled = bool(args[0])
		minimal_enabled = bool(args[2])
		var next_ground := bool(args[1])
		if next_ground != ground_enabled:
			ground_trace = preload("res://extensions/diagnostics/ground_trace.gd").new()
		ground_enabled = next_ground)
	bridge.init(FileAccess.get_file_as_string("res://extensions/diagnostics/firebase_config.json"), callback)
	var layer := CanvasLayer.new()
	layer.layer = 20
	add_child(layer)
	var blocker := ColorRect.new()
	blocker.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	blocker.color = Color(0, 0, 0, 0.65)
	layer.add_child(blocker)
	dialog = preload("res://extensions/diagnostics/diagnostics_dialog.gd").new()
	layer.add_child(dialog)
	dialog.visibility_changed.connect(func():
		blocker.visible = dialog.visible
		bridge.setDialogVisible(dialog.visible)
		dialog_visibility_changed.emit(dialog.visible))
	blocker.hide()
	dialog.apply_requested.connect(_apply_configuration)
	var timer := Timer.new()
	timer.wait_time = 1.0
	timer.timeout.connect(_update_status)
	add_child(timer)
	timer.start()
	RenderQuality.changed.connect(_update_render_quality)
	_update_render_quality()
	RenderingServer.frame_pre_draw.connect(_begin_gpu_measurement)
	RenderingServer.frame_post_draw.connect(_end_gpu_measurement)

func _apply_configuration(display: bool, performance_recording: bool, ground_recording: bool, target: int, device: String, timeline: bool, minimal_requested: bool) -> void:
	if _applying:
		return
	_applying = true
	var was_recording: bool = JSON.parse_string(bridge.state()).performance
	var stopping_minimal: bool = minimal_enabled and not minimal_requested
	var before := {}
	if performance_recording and not was_recording:
		before = await reference.sample()
	if bridge.configure(display, performance_recording, ground_recording, target, device, timeline, minimal_requested):
		if not before.is_empty():
			bridge.recordReference("before", JSON.stringify(before))
		if was_recording and not performance_recording:
			var after: Dictionary = await reference.sample()
			bridge.recordReference("after", JSON.stringify(after))
		physics_time_us = 0
		bridge.resetFrameClock()
		if stopping_minimal:
			dialog.open(JSON.parse_string(bridge.state()))
			dialog.show_minimal_result()
		else:
			dialog.hide()
	_applying = false
	_update_status()

func _begin_gpu_measurement() -> void:
	if not enabled or bridge == null:
		return
	var now := Time.get_ticks_usec()
	if now < _next_gpu_probe_us:
		return
	_next_gpu_probe_us = now + 250000
	_gpu_query_started = bool(bridge.beginGpu())

func _end_gpu_measurement() -> void:
	if _gpu_query_started and bridge != null:
		bridge.endGpu()
	_gpu_query_started = false

func _update_render_quality() -> void:
	if bridge != null:
		bridge.setRenderQuality(RenderQuality.scale_factor, RenderQuality.msaa_samples, RenderQuality.mode_for(RenderQuality.snapshot()), RenderQuality.shadow_variant)

func show_settings() -> void:
	if bridge != null:
		dialog.open(JSON.parse_string(bridge.state()))

func _update_status() -> void:
	if bridge != null and dialog.visible:
		var state: Dictionary = JSON.parse_string(bridge.state())
		dialog.status_label.text = state.status
		dialog.update_minimal_result(state.get("minimal_result"))

func record_ground_motion(position: Vector3, yaw: float, speed: float, input: Vector3) -> void:
	if ground_enabled:
		ground_trace.record(Time.get_ticks_msec(), position, yaw, speed, input)

func clear_ground_history() -> void:
	ground_trace.clear_history()

func report_ground_failure(position: Vector3, speed: float, query: Dictionary, context := "driving") -> void:
	if not ground_enabled:
		return
	var event: Dictionary = ground_trace.failure(Time.get_ticks_msec(), position, speed, query, context)
	if not event.is_empty():
		bridge.groundFailure(JSON.stringify(event))

func finish_lap(number: int, seconds: float, speed_mps: float) -> void:
	if enabled and bridge != null:
		bridge.finishLap(number, seconds, speed_mps * 3.6)

func sample(start_us: int, phase: String, lap: int, seconds: float, speed_mps: float, at: Vector3) -> void:
	# Sum every physics tick since the last rendered frame, including catch-up ticks.
	var cpu_us := Time.get_ticks_usec() - start_us + physics_time_us
	physics_time_us = 0
	if bridge != null:
		bridge.sample(cpu_us / 1000.0, phase, lap, seconds, speed_mps * 3.6, at.x, at.y, at.z)

func sample_minimal(phase: String) -> void:
	bridge.sampleMinimal(phase)

func _exit_tree() -> void:
	enabled = false
	for hook in [RenderingServer.frame_pre_draw, RenderingServer.frame_post_draw, RenderQuality.changed]:
		for connection in hook.get_connections():
			if connection.callable.get_object() == self: hook.disconnect(connection.callable)
	if is_instance_valid(player):
		for hook in [player.presentation_started, player.presentation_finished, player.physics_started, player.physics_finished, player.simulation_step_started, player.ground_contact_failed, player.simulation_event]:
			for connection in hook.get_connections():
				if connection.callable.get_object() == self: hook.disconnect(connection.callable)
	# HUD and settings controls live outside this extension's own subtree.
	for control in instruments + [steering_dialog]:
		if is_instance_valid(control):
			if control.get_parent(): control.get_parent().remove_child(control)
			control.queue_free()
	if is_instance_valid(controls) and is_instance_valid(player):
		settings_menu.remove_extension_tab(controls)
	if bridge != null:
		bridge.dispose()

func can_remove() -> bool:
	if _applying or (bridge != null and not bridge.canRemove()):
		removal_hint.text = "Vor dem Entfernen Aufnahme beenden und ausstehende Übertragung abwarten."
		settings_menu._show_tab(settings_menu.pages.find(controls))
		return false
	return true

func _show_steering() -> void:
	settings_menu.hide()
	steering_dialog.open(instruments[0].visible, instruments[1].visible, instruments[2].visible)

func _toggle_instrument(value: bool, index: int) -> void:
	instruments[index].visible = value
	if not value: instruments[index].remaining = 0.0

func _return_to_settings() -> void:
	settings_menu.show()

func _dialog_visibility(is_open: bool) -> void:
	# Covered controls must not receive touch input through the modal.
	settings_menu.visible = not is_open

func _input(event: InputEvent) -> void:
	if not steering_dialog.visible: return
	if event is InputEventJoypadButton and event.device == player.gamepad.device and event.pressed and event.button_index == JOY_BUTTON_B:
		steering_dialog.close()
	if event is InputEventJoypadButton or event is InputEventJoypadMotion:
		get_viewport().set_input_as_handled()

func _unhandled_key_input(event: InputEvent) -> void:
	if not steering_dialog.visible: return
	if event.is_pressed() and event.keycode == KEY_ESCAPE:
		steering_dialog.close()
	get_viewport().set_input_as_handled()

func _presentation_started(dt: float) -> void:
	for instrument in instruments:
		instrument.refresh(dt, player.keyboard_controls.is_gamepad(), player.has_focus, not player.simulation_paused and not player.crashed)
	presentation_start_us = Time.get_ticks_usec() if enabled else 0

func _presentation_finished() -> void:
	var phase := "pause" if player.simulation_paused or not player.has_focus else ("flight" if player.flight_mode else "driving")
	if enabled:
		var lap: int = 0 if player.flight_mode or player.lap_timing.lap_invalid else player.lap_timing.completed_laps + 1
		sample(presentation_start_us, phase, lap, player.lap_timing.lap_elapsed, player.speed_mps, player.global_position)
	else:
		physics_time_us = 0
	if minimal_enabled: sample_minimal(phase)

func _physics_started() -> void:
	physics_start_us = Time.get_ticks_usec() if enabled else 0
	if ground_enabled and (player.simulation_paused or not player.has_focus or player.flight_mode or player.crashed):
		clear_ground_history()

func _physics_finished() -> void:
	if enabled: physics_time_us += Time.get_ticks_usec() - physics_start_us

func _step_started(_dt: float, input: Vector3, _hold: bool, _flight: Vector2, _target: float) -> void:
	if not player.flight_mode:
		record_ground_motion(player.position, player.heading_yaw, player.speed_mps, input)

func _ground_failed(candidate: Vector3, context: String) -> void:
	if ground_enabled:
		# Detailed ray results are collected only on failure and before motion resets.
		player.ground.sample_pose(candidate, player.heading_yaw, true)
		report_ground_failure(player.position, player.speed_mps, player.ground.last_query, context)

func _simulation_event(kind: StringName, lap: int, seconds: float) -> void:
	if kind == &"lap": finish_lap(lap, seconds, player.speed_mps)
