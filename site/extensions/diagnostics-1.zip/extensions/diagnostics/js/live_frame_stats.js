/* Bounded ten-second window, evaluated only when the visible UI refreshes.
 * EMA has a one-second time constant, independent of frame rate. */
(() => {
  class LiveFrameStats {
    constructor(capacity=4096) {
      this.times = new Float64Array(capacity);
      this.frames = new Float64Array(capacity);
      this.cpu = new Float64Array(capacity);
      this.reset();
    }
    reset(preserveEma = false) {
      this.head = 0; this.count = 0;
      if(!preserveEma) { this.ema = 0; this.hasEma = false; }
    }
    add(now, interval, cpu) {
      this.expire(now);
      const i = this.head;
      this.times[i] = now; this.frames[i] = interval; this.cpu[i] = cpu;
      this.head = (i + 1) % this.times.length;
      this.count = Math.min(this.count + 1, this.times.length);
      this.ema = this.hasEma ? this.ema + (-Math.expm1(-interval / 1000)) * (interval - this.ema) : interval;
      this.hasEma = true;
    }
    expire(now) {
      while (this.count && this.times[(this.head - this.count + this.times.length) % this.times.length] <= now - 10000) this.count--;
    }
    visit(now, consume) {
      this.expire(now);
      for (let n = this.count; n > 0; n--) {
        const i = (this.head - n + this.times.length) % this.times.length;
        consume(this.frames[i], this.cpu[i]);
      }
    }
  }
  if (typeof module !== 'undefined') module.exports = LiveFrameStats;
  else window.OscherslebenLiveFrameStats = LiveFrameStats;
})();
