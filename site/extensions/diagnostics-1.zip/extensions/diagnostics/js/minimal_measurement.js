(function(root) {
  'use strict';
  class MinimalMeasurement {
    constructor(capacity = 65536) {
      this.samples = new Float32Array(capacity);
      this.enabled = false;
      this.previous = null;
      this.count = 0;
      this.result = null;
    }
    configure(enabled) {
      if (enabled && !this.enabled) {
        this.count = 0;
        this.result = null;
        this.previous = null;
      }
      if (!enabled && this.enabled) this.stop();
      this.enabled = enabled;
    }
    suspend() { this.previous = null; }
    sample(now) {
      if (!this.enabled) return null;
      const interval = this.previous === null ? null : now - this.previous;
      this.previous = now;
      if (interval !== null && interval > 0) {
        this.samples[this.count++] = interval;
        if (this.count === this.samples.length) this.stop(true);
      }
      return interval;
    }
    stop(limit = false) {
      const values = this.samples.slice(0, this.count);
      let total = 0, over50 = 0;
      for (const value of values) { total += value; if (value > 50) over50++; }
      values.sort();
      this.result = {count: this.count, duration_ms: total,
        mean_ms: this.count ? total / this.count : null,
        p95_ms: this.count ? values[Math.ceil(this.count * .95) - 1] : null, over50, limit};
      this.enabled = false;
      this.previous = null;
    }
  }
  if (typeof module !== 'undefined') module.exports = MinimalMeasurement;
  else root.OscherslebenMinimalMeasurement = MinimalMeasurement;
})(typeof window !== 'undefined' ? window : globalThis);
