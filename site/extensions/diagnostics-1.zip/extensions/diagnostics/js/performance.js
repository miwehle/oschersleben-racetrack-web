/* Opt-in diagnostics. No Firebase listeners, no work while disabled.
 * Frame intervals include browser waits; CPU sums controller physics ticks and presentation per frame.
 * Histograms bound memory independently of recording duration (0.25 ms bins).
 */
(() => {
  if (window.OscherslebenDiagnostics) return;
  const histogram = () => ({bins:new Uint32Array(1001), n:0, sum:0, max:0, late:0});
  function add(h, ms, budget) {
    h.bins[Math.min(1000, Math.floor(ms * 4))]++;
    h.n++; h.sum += ms; h.max = Math.max(h.max, ms);
    if (ms > budget * 1.5) h.late++;
  }
  const rounded = n => Math.round(n * 100) / 100;
  function summary(h) {
    const percentile = p => {
      if (!h.n) return 0;
      let count = 0;
      for (let i = 0; i < h.bins.length; i++) {
        count += h.bins[i];
        if (count >= Math.ceil(h.n * p)) return i === 1000 ? h.max : Math.min(h.max, (i + 0.5) / 4);
      }
      return 0;
    };
    return {n:h.n, mean:rounded(h.n ? h.sum/h.n : 0), p50:rounded(percentile(.5)),
      p95:rounded(percentile(.95)), max:rounded(h.max), late:h.late};
  }
  let config, callback, visible = false, recording = false, target = 60;
  let groundRecording = false, groundCount = 0, groundSent = 0;
  let dialogVisible = false;
  let timelineVisible = false;
  const timeline = new window.OscherslebenFrameTimeline();
  const minimal = new window.OscherslebenMinimalMeasurement();
  let renderScale = 1, msaaSamples = 0, graphicsMode = 'custom', shadowVariant = 'off';
  let fullscreen = !!document.fullscreenElement;
  let previous = 0, phase = '', segmentStart = 0, blockStart = 0, liveStart = 0;
  let frame = histogram(), cpu = histogram(), gpu = histogram(), phases = {};
  const live = new window.OscherslebenLiveFrameStats();
  const gpuTimer = new window.OscherslebenGpuTimer((ms,time)=>{
    add(gpu,ms,1000/target);
  });
  let queue = [], uid = '', token = '', busy = false, epoch = 0, slot = 0;
  let recordStart = 0, nextUpload = 0, uploadedBytes = 0, dropped = 0, status = 'Aus';
  let failures = 0;
  let sessionHeader = null, deviceName = '';
  let startupPending = null, startupSent = !!window.OscherslebenDiagnosticsStartupSent;
  let referenceRun = 0;
  try {deviceName = (localStorage.getItem('oschersleben.diagnostics.device_name') || '').slice(0,80);} catch (_) {}
  let lapNumber = 0, lapSeconds = 0, speedKmh = 0, blockStartProgress = null;
  const lapSnapshot = () => ({lap_number:lapNumber > 0 ? lapNumber : null,
    lap_time_ms:lapNumber > 0 ? Math.round(lapSeconds*1000) : null, speed_kmh:rounded(speedKmh)});
  let battery = null, batteryStatus = 'not_requested';
  async function readBattery(generation) {
    battery = null;
    batteryStatus = typeof navigator.getBattery === 'function' ? 'pending' : 'unavailable';
    if (batteryStatus !== 'pending') return;
    try {
      const result = await navigator.getBattery();
      if (generation === epoch) {battery = result; batteryStatus = 'available';}
    } catch (_) {if (generation === epoch) batteryStatus = 'error';}
  }
  function testContext() {
    // End-of-block snapshot, not proof of the state throughout the block or of throttling.
    return {observed_utc:Date.now(),
      recording:{performance:recording, ground:groundRecording},
      battery:{status:batteryStatus,
        level_percent:battery && Number.isFinite(battery.level) ? Math.round(battery.level*100) : null,
        charging:battery && typeof battery.charging === 'boolean' ? battery.charging : null}};
  }
  function batteryLabel() {
    if (batteryStatus === 'available') {
      const b = testContext().battery;
      return 'Akku: '+(b.level_percent===null?'unbekannt':b.level_percent+' %')+' · '+
        (b.charging===null?'Ladezustand unbekannt':b.charging?'wird geladen':'wird nicht geladen');
    }
    return 'Akku: '+({not_requested:'wird erst bei Aufnahmebeginn abgefragt',pending:'Abfrage läuft',
      unavailable:'im Browser nicht verfügbar',error:'Abfrage fehlgeschlagen'}[batteryStatus]);
  }
  const histogramView = new window.OscherslebenFrameHistogram();
  const limits = [1000/60,25,1000/30,50,100,Infinity];
  const phaseName = () => document.hidden ? 'background' : phase || 'loading';
  const active = () => visible || recording || (timelineVisible && !dialogVisible);
  const recordingAny = () => recording || groundRecording;
  function notify() { if(!active()) gpuTimer.reset(); if (callback) callback(active(), groundRecording, minimal.enabled); }
  const buildVersion = () => {
    const script=document.querySelector('script[src*="build-"]');
    return script ? script.getAttribute('src').split('/').pop() : 'local';
  };
  function enqueue(payload, kind) {
    if(payload.length>6000 || slot>=120) {dropped++;return false;}
    if(queue.length===4) {queue.shift();dropped++;}
    queue.push({slot:slot++,payload,kind});
    return true;
  }
  function resetSamples(now, preserveMotionHistory = false) {
    if(!preserveMotionHistory) {
      timeline.reset(now); liveStart=now;
    }
    histogramView.reset(preserveMotionHistory);
    previous = 0; frame = histogram(); cpu = histogram(); gpu = histogram(); live.reset(preserveMotionHistory); gpuTimer.reset();
    segmentStart = now;
  }
  function sealSegment(now) {
    if (!recording || !segmentStart) return;
    sealTransition(now, phaseName());
  }
  function finishBlock(now, recordingComplete = false) {
    if (!recording || (!recordingComplete && now <= blockStart)) return;
    sealSegment(now);
    const canvas = document.querySelector('canvas');
    const data = {schema:2, kind:'performance', version:buildVersion(), recording_complete:recordingComplete, reference_run:referenceRun,
      utc:Date.now(), duration_ms:Math.round(now-blockStart), target_fps:target, render_3d_scale:renderScale, msaa_samples:msaaSamples,
      graphics_mode:graphicsMode, shadow_variant:shadowVariant, gpu_timer:gpuTimer.status, gpu_sample_interval_ms:250,
      render:[canvas ? canvas.width : 0,canvas ? canvas.height : 0],
      viewport:[innerWidth,innerHeight], dpr:devicePixelRatio, fullscreen, test_context:testContext(),
      start:blockStartProgress, end:lapSnapshot(), phases:{}};
    for(const [name,item] of Object.entries(phases)) data.phases[name]={duration_ms:Math.round(item.duration), frame_ms:summary(item.frame), controller_cpu_ms:summary(item.cpu), gpu_ms:item.gpu.n?summary(item.gpu):null};
    const payload=JSON.stringify(data);
    enqueue(payload, 'performance');
    phases={}; blockStart=now; blockStartProgress=lapSnapshot();
  }
  async function request(url, options) {
    const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),15000);
    try {const result=await fetch(url,{...options,signal:controller.signal}); if(!result.ok) throw new Error('HTTP '+result.status); return result.status===204 ? null : await result.json();}
    finally {clearTimeout(timer);}
  }
  function queueStartup() {
    if (!recording || startupSent || startupPending) return;
    const measurement = window.OscherslebenStartup?.snapshot();
    if (!measurement || slot >= 120) return;
    startupPending = {slot:slot++, payload:JSON.stringify({schema:2,kind:'startup',version:buildVersion(),
      ...window.OscherslebenSessionInfo(navigator.userAgent,deviceName), startup:measurement})};
  }
  async function upload() {
    if(busy || !token || (!queue.length && !sessionHeader && !startupPending) || document.hidden) return;
    busy=true; const generation=epoch; const batch=queue.splice(0,4); const startupBatch=startupPending; const body={};
    // Keep the one session header until confirmed, even if measurement blocks overflow.
    if(sessionHeader) body['0']={t:{'.sv':'timestamp'},payload:sessionHeader};
    if(startupBatch) body[String(startupBatch.slot)]={t:{'.sv':'timestamp'},payload:startupBatch.payload};
    batch.forEach(item=>{body[String(item.slot)]={t:{'.sv':'timestamp'},payload:item.payload};});
    const json=JSON.stringify(body);
    try {
      await request(config.databaseURL+'/diagnostics/'+uid+'.json?print=silent&auth='+encodeURIComponent(token),{method:'PATCH',headers:{'Content-Type':'application/json'},body:json});
      if(generation===epoch) {
        if(startupBatch) {startupSent=true;window.OscherslebenDiagnosticsStartupSent=true;startupPending=null;}
        failures=0;sessionHeader=null;uploadedBytes+=new TextEncoder().encode(json).length;status='Gesendet';
        groundSent+=batch.filter(item=>item.kind==='ground_failure').length;
      }
    } catch(error) {
      if(generation===epoch) {
        queue=batch.concat(queue); while(queue.length>4){queue.shift();dropped++;}
        status='Versand fehlgeschlagen: '+error.message;
        if(++failures>=3) {recording=false;groundRecording=false;dropped+=queue.length+(sessionHeader?1:0)+(startupPending?1:0);queue=[];sessionHeader=null;startupPending=null;status+=' · nach 3 Fehlern beendet';notify();}
      }
    } finally {busy=false;}
  }
  async function startSession() {
    const generation=++epoch; const now=performance.now();
    readBattery(generation);
    queue=[];startupPending=null;slot=1;uploadedBytes=0;dropped=0;failures=0;phases={};token='';blockStartProgress=null;
    sessionHeader=JSON.stringify({schema:2,kind:'session',version:buildVersion(),utc:Date.now(),
      ...window.OscherslebenSessionInfo(navigator.userAgent,deviceName),
      recording:{performance:recording,ground:groundRecording}});
    groundCount=0;groundSent=0;
    queueStartup();
    recordStart=blockStart=now;nextUpload=now+60000;resetSamples(now);notify();status='Anonyme Anmeldung …';
    try {
      const auth=await request('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key='+encodeURIComponent(config.apiKey),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({returnSecureToken:true})});
      if(generation!==epoch) return;
      uid=auth.localId;token=auth.idToken;status='Aufzeichnung läuft';
      if(!recordingAny()) status='Aufzeichnung beendet';
      if(startupPending || queue.some(item=>item.kind==='ground_failure') || !recordingAny()) upload();
    } catch(error) {if(generation===epoch){recording=false;groundRecording=false;dropped+=queue.length+1+(startupPending?1:0);queue=[];sessionHeader=null;startupPending=null;status='Anmeldung fehlgeschlagen: '+error.message;notify();}}
  }
  function stopRecording() {
    finishBlock(performance.now(), true);recording=false;groundRecording=false;notify();
    status='Aufzeichnung beendet';upload();
  }
  function configure(display, performanceRecording, ground, fps, device = deviceName, showTimeline = false, minimalEnabled = false) {
    if(![30,60,90,120].includes(fps)) return false;
    const wasRecording=recordingAny(), wantsRecording=performanceRecording || ground;
    if(!wasRecording && wantsRecording && (busy || queue.length || sessionHeader || startupPending)) {
      status='Vorherige Aufnahme wird noch versendet. Bitte gleich erneut übernehmen.';return false;
    }
    const nextDevice=String(device).trim().slice(0,80);
    if(wasRecording && nextDevice!==deviceName) {status='Gerätename erst nach Beenden der Aufnahme ändern.';return false;}
    const now=performance.now();
    if(recording && (recording!==performanceRecording || groundRecording!==!!ground || target!==fps)) finishBlock(now, !performanceRecording);
    else sealSegment(now);
    if(!recording && performanceRecording) {referenceRun++;phases={};blockStart=now;blockStartProgress=null;}
    visible=!!display;recording=!!performanceRecording;groundRecording=!!ground;target=fps;
    minimal.configure(!!minimalEnabled);
    timelineVisible=!!showTimeline;
    timeline.setVisible(timelineVisible && !dialogVisible,now);
    deviceName=nextDevice;
    try {localStorage.setItem('oschersleben.diagnostics.device_name',deviceName);} catch (_) {}
    histogramView.setVisible(visible && !dialogVisible);resetSamples(now);notify();
    if(!wasRecording && wantsRecording) startSession();
    else if(wasRecording && !wantsRecording) {status='Aufzeichnung beendet';upload();}
    else if(performanceRecording) {queueStartup();if(startupPending) upload();}
    return true;
  }
  function groundFailure(json) {
    if(!groundRecording || document.hidden || groundCount>=20) return false;
    let event;
    try {event=JSON.parse(json);} catch (_) {return false;}
    if(event.kind!=='ground_failure' || !Array.isArray(event.history) || event.history.length>51) return false;
    event.version=buildVersion();event.utc=Date.now();
    event.test_context=testContext();
    // Micrometre precision for ray endpoints is ample; avoid float-string inflation.
    const payload=JSON.stringify(event,(_key,value)=>typeof value==='number'?Math.round(value*1e6)/1e6:value);
    if(!enqueue(payload,'ground_failure')) return false;
    groundCount++;upload();
    if(groundCount===20) {groundRecording=false;notify();}
    return true;
  }
  function state() {
    const info=window.OscherslebenSessionInfo(navigator.userAgent,deviceName);
    const startup=window.OscherslebenStartup?.snapshot();
    return JSON.stringify({startup:startup || null,minimal_enabled:minimal.enabled,minimal_result:minimal.result,display:visible,timeline:timelineVisible,performance:recording,ground:groundRecording,target,device_name:deviceName,
      environment:(info.device_type==='unknown'?'Geräteart unbekannt':info.device_type)+' · '+info.browser.name+' '+(info.browser.version || '')+' · '+info.operating_system+' (Browserangabe)',
      status:'Leistungsaufzeichnung '+(recording?'aktiv':'aus')+' · Bodenaufzeichnung '+(groundRecording?'aktiv':'aus')+
        '\nBodenereignisse: '+groundSent+' gesendet / '+groundCount+' erfasst (max. 20)'+
        '\n'+status+' · '+window.OscherslebenUiNumber(uploadedBytes/1024,1)+' KiB bestätigt · '+(queue.length+(sessionHeader?1:0)+(startupPending?1:0))+' offen · '+dropped+' verworfen'+
        '\n'+batteryLabel()+'\nStartzeit: '+(startup ? window.OscherslebenUiNumber(startup.total_ms/1000,2)+' s'+(startup.hidden_during_start?' · zeitweise im Hintergrund':'') : 'nicht gemessen')});
  }
  function visibilityChanged() {
    minimal.suspend();
    // visibilitychange already exposes the new state: seal using the old phase.
    const now=performance.now();
    if(recording) {
      sealTransition(now, document.hidden ? phase || 'loading' : 'background');
    }
    resetSamples(now);
  }
  document.addEventListener('visibilitychange',visibilityChanged);
  function fullscreenChanged() {
    const now = performance.now();
    finishBlock(now);
    fullscreen = !!document.fullscreenElement;
    resetSamples(now);
  }
  document.addEventListener('fullscreenchange',fullscreenChanged);
  function sealTransition(now, oldPhase) {
    // A temporary override avoids attributing foreground samples to background.
    const item=phases[oldPhase]||(phases[oldPhase]={duration:0,frame:histogram(),cpu:histogram(),gpu:histogram()});
    item.duration+=Math.max(0,now-segmentStart);
    for(const [source,dest] of [[frame,item.frame],[cpu,item.cpu],[gpu,item.gpu]]) {
      for(let i=0;i<source.bins.length;i++) dest.bins[i]+=source.bins[i];
      dest.n+=source.n;dest.sum+=source.sum;dest.max=Math.max(dest.max,source.max);dest.late+=source.late;
    }
    frame=histogram();cpu=histogram();gpu=histogram();gpuTimer.reset();segmentStart=now;
  }
  const timer=setInterval(()=>{
    queueStartup();
    if(startupPending) upload();
    if(!recordingAny() && !queue.length && !sessionHeader && !startupPending) return;
    const now=performance.now();
    if(recording && now-blockStart>=30000) finishBlock(now);
    if(recordingAny() && now-recordStart>=55*60000) stopRecording();
    if(now>=nextUpload && (queue.length || sessionHeader || startupPending)) {nextUpload=now+60000;upload();}
  },1000);
  window.OscherslebenDiagnostics={
    init(json, fn){config=JSON.parse(json);callback=fn;},
    configure, state, groundFailure,
    canRemove(){return !recordingAny() && !minimal.enabled && !queue.length && !sessionHeader && !startupPending && !busy;},
    recordReference(stage, json) {
      if (!['before','after'].includes(stage) || !referenceRun) return false;
      const data = JSON.parse(json);
      const added = enqueue(JSON.stringify({schema:2,kind:'reference',version:buildVersion(),
        reference_run:referenceRun,stage,...data}), 'reference');
      nextUpload=0; upload(); return added;
    },
    resetFrameClock(){resetSamples(performance.now());minimal.suspend();},
    sampleMinimal(phase) {
      if (!minimal.enabled) return;
      if (document.hidden || dialogVisible || phase === 'pause' || phase === 'loading') { minimal.suspend(); return; }
      minimal.sample(performance.now());
      if (!minimal.enabled) notify();
    },
    finishLap(number, seconds, kmh){
      if(!active()) return;
      const now=performance.now();
      lapNumber=number;lapSeconds=seconds;speedKmh=kmh;
      finishBlock(now);resetSamples(now);
      lapNumber=number+1;lapSeconds=0;blockStartProgress=lapSnapshot();
    },
    setDialogVisible(value){
      minimal.suspend();
      dialogVisible=!!value;histogramView.setVisible(visible && !dialogVisible);
      timeline.setVisible(timelineVisible && !dialogVisible,performance.now());
      if(!visible && !recording) previous=0;
      notify();
    },
    setRenderQuality(value, samples=0, mode='custom', variant='off'){
      if(![1,.75,.5].includes(value) || ![0,2,4,8].includes(samples) ||
        !['mobile','desktop','custom'].includes(mode) || !['off','lightmaps'].includes(variant) ||
        (value===renderScale && samples===msaaSamples && mode===graphicsMode && variant===shadowVariant)) return;
      const now=performance.now();
      finishBlock(now);renderScale=value;msaaSamples=samples;graphicsMode=mode;shadowVariant=variant;resetSamples(now);
    },
    beginGpu(){return (visible || recording) && !document.hidden && gpuTimer.begin(performance.now());},
    endGpu(){gpuTimer.end();},
    sample(cpuMs, newPhase, number=0, seconds=0, kmh=0, x=0, y=0, z=0) {
      if(!active()) return;
      const now=performance.now();
      if(document.hidden) {previous=0;return;}
      // Resets and entering/leaving flight also must not mix lap identities.
      if(blockStartProgress && (number!==lapNumber || seconds<lapSeconds)) {
        finishBlock(now);resetSamples(now);blockStartProgress=null;
      }
      lapNumber=number;lapSeconds=seconds;speedKmh=Math.abs(kmh);
      if(!blockStartProgress) blockStartProgress=lapSnapshot();
      if(newPhase==='driving' && speedKmh<1) newPhase='stationary';
      if(newPhase!==phase) {
        const movementChange = (phase==='driving' && newPhase==='stationary') ||
          (phase==='stationary' && newPhase==='driving');
        // Keep the visual history continuous, including the transition interval.
        // Histograms still exclude cross-phase intervals; EMA keeps their timing.
        if(movementChange && previous) {
          if(timeline.enabled) timeline.sample(now,now-previous);
          if(visible) live.add(now,now-previous,cpuMs);
        }
        sealSegment(now);phase=newPhase;resetSamples(now,movementChange);
      }
      if(previous) {
        const interval=now-previous;
        if(visible || recording) {add(frame,interval,1000/target);add(cpu,cpuMs,1000/target);}
        if(timeline.enabled) timeline.sample(now,interval);
        if(visible) live.add(now,interval,cpuMs);
      }
      previous=now;
      if(visible && now-liveStart>=500) {
        const frames=histogram(), counts=new Uint32Array(limits.length);
        live.visit(now,(ms,cpuMs)=>{
          add(frames,ms,1000/target);
          counts[limits.findIndex(limit=>ms<=limit)]++;
        });
        const s=summary(frames);
        histogramView.update(s, counts, live.hasEma ? live.ema : null);
        liveStart=now;
      }
    },
    dispose(){epoch++;gpuTimer.reset();clearInterval(timer);histogramView.dispose();timeline.dispose();document.removeEventListener('visibilitychange',visibilityChanged);document.removeEventListener('fullscreenchange',fullscreenChanged);delete window.OscherslebenDiagnostics;}
  };
})();
