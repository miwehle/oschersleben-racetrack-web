extends Node
## Runs only at recording boundaries, with simulation and engine rendering suspended.
const CPU = preload("res://performance/reference_cpu.gd")
var bridge: JavaScriptObject
var running := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if OS.has_feature("web"):
		JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/diagnostics/js/gpu_reference.js"), true)
		JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/diagnostics/js/reference_bridge.js"), true)
		bridge = JavaScriptBridge.get_interface("VehicleReferenceBridge")

func sample() -> Dictionary:
	if bridge == null or running:
		return {"cpu": {"status": "unavailable"}, "gpu": {"status": "unavailable"}}
	running = true
	var tree := get_tree()
	var was_paused := tree.paused
	var was_rendering := RenderingServer.is_render_loop_enabled()
	tree.paused = true
	RenderingServer.set_render_loop_enabled(false)
	bridge.begin()
	await tree.process_frame
	for repeat in 100:
		CPU.workload()
		if (repeat + 1) % 10 == 0:
			await tree.process_frame
	var cpu := CPU.sample()
	cpu.merge({"version": "gdscript-cpu-web-v2", "workload_version": CPU.VERSION,
		"extra_warmups": 100, "warmup_batch_size": 10, "status": "ok"})
	bridge.startGpu()
	while not bridge.done:
		await tree.process_frame
	var result: Dictionary = JSON.parse_string(bridge.finish(JSON.stringify(cpu)))
	RenderingServer.set_render_loop_enabled(was_rendering)
	tree.paused = was_paused
	running = false
	return result

func _exit_tree() -> void:
	if bridge != null:
		bridge.dispose()
