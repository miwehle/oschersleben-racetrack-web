/* Local export only. No network and no Google account access. */
(() => {
  if (window.OscherslebenTelemetryFiles) return;
  let callback, directory, prepared, unsaved = false;
  const report = (kind, message) => callback?.(kind, message);
  const db = () => new Promise((resolve, reject) => {
    const request = indexedDB.open('oschersleben-telemetry', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('settings');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  async function stored(value, write = false) {
    const database = await db();
    try {
      return await new Promise((resolve, reject) => {
        const tx = database.transaction('settings', write ? 'readwrite' : 'readonly');
        const request = write ? tx.objectStore('settings').put(value, 'directory') : tx.objectStore('settings').get('directory');
        tx.oncomplete = () => resolve(request.result);
        tx.onabort = tx.onerror = () => reject(tx.error);
      });
    } finally { database.close(); }
  }
  let loaded = Promise.resolve();
  async function choose() {
    if (!window.showDirectoryPicker) {
      report('info', 'Dieser Browser verwaltet das Ziel über seine Download-Einstellungen.');
      return;
    }
    directory = await window.showDirectoryPicker({id: 'telemetry', mode: 'readwrite', ...(directory ? {startIn: directory} : {})});
    try { await stored(directory, true); }
    catch (_) { report('info', 'Ordner nur für diese Sitzung gemerkt.'); return; }
    report('info', 'Zielordner: ' + directory.name);
  }
  function failure(error) {
    prepared = null;
    report('error', error?.name === 'AbortError' ? 'Speichern/Ordnerwahl abgebrochen. Aufnahme bleibt erhalten.' : 'Dateizugriff fehlgeschlagen: ' + error.message + '. Aufnahme bleibt erhalten.');
  }
  window.addEventListener('beforeunload', event => {
    if (unsaved) { event.preventDefault(); event.returnValue = ''; }
  });
  window.OscherslebenTelemetryFiles = {
    init(cb) {
      callback = cb;
      loaded = stored().then(handle => { directory = handle; }).catch(() => {});
    },
    setUnsaved(value) { unsaved = !!value; },
    detach() { callback = null; unsaved = false; prepared = null; },
    async choose() { try { await loaded; await choose(); } catch (error) { failure(error); } },
    async prepare() {
      try {
        await loaded;
        if (window.showDirectoryPicker) {
          if (!directory) await choose();
          if (await directory.queryPermission({mode: 'readwrite'}) !== 'granted' &&
              await directory.requestPermission({mode: 'readwrite'}) !== 'granted') throw new Error('Schreibzugriff nicht erlaubt');
          prepared = directory;
        }
        report('ready', '');
      } catch (error) { failure(error); }
    },
    async save(base64, filename) {
      try {
        const bytes = Uint8Array.from(atob(base64), char => char.charCodeAt(0));
        const blob = new Blob([bytes], {type: 'application/zip'});
        if (prepared) {
          const file = await prepared.getFileHandle(filename, {create: true});
          const stream = await file.createWritable();
          try { await stream.write(blob); await stream.close(); }
          catch (error) { try { await stream.abort(); } catch (_) {} throw error; }
          prepared = null;
          report('saved', 'Gespeichert: ' + filename);
        } else {
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url; link.download = filename;
          document.body.appendChild(link); link.click(); link.remove();
          setTimeout(() => URL.revokeObjectURL(url), 60000);
          report('download', 'Download übergeben. Datei prüfen; danach Aufnahme verwerfen.');
        }
      } catch (error) { failure(error); }
    }
  };
})();
