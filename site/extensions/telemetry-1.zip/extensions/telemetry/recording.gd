extends RefCounted
## Fixed-size numeric buffers. No strings, dictionaries or I/O in the sample path.
const INPUT_COLUMNS := "tick,time_s,throttle,brake,steering,speed_hold,flight_x,flight_y,target_kmh"
const STATE_COLUMNS := "tick,time_s,x_m,y_m,z_m,qx,qy,qz,qw,vx_m_s,vy_m_s,vz_m_s,wx_rad_s,wy_rad_s,wz_rad_s,acc_forward_m_s2,acc_left_m_s2,front_fx_N,front_fy_N,rear_fx_N,rear_fy_N,front_normal_N,rear_normal_N,grip_mu,front_limit_N,rear_limit_N,ground_contact,flight_mode,track_distance_m"
const EVENT_COLUMNS := "tick,time_s,event,lap,lap_seconds"
const INPUT_WIDTH := 9
const STATE_WIDTH := 29
const EVENT_WIDTH := 5
const EVENT_NAMES := ["start", "stop", "pause", "resume", "reset", "start_finish", "lap", "mode_change", "focus_out", "focus_in", "buffer_full"]
const MAX_EVENTS := 2048
const DEFAULT_BUDGET := 32 * 1024 * 1024
var inputs := PackedFloat64Array()
var states := PackedFloat64Array()
var events := PackedFloat64Array()
var input_count := 0
var state_count := 0
var event_count := 0
var capacity := 0
var tick := 0
var time_s := 0.0
var active := false
var full := false
var metadata := {}

func start(info: Dictionary, budget := DEFAULT_BUDGET) -> void:
	metadata = info.duplicate(true)
	# Reserve event space and one initial state, then complete groups of three ticks.
	capacity = maxi(0, (budget / 8 - MAX_EVENTS * EVENT_WIDTH - STATE_WIDTH) / (3 * INPUT_WIDTH + STATE_WIDTH)) * 3
	inputs.resize(capacity * INPUT_WIDTH)
	states.resize((capacity / 3 + 1) * STATE_WIDTH)
	events.resize(MAX_EVENTS * EVENT_WIDTH)
	input_count = 0
	state_count = 0
	event_count = 0
	tick = 0
	time_s = 0
	full = false
	active = capacity > 0
	event(0)

func begin_step(dt: float, ground: Vector3, hold: bool, stick: Vector2, target: float) -> bool:
	if not active: return false
	if input_count >= capacity:
		stop(true)
		return false
	tick += 1
	time_s += dt
	var i := input_count * INPUT_WIDTH
	inputs[i] = tick
	inputs[i + 1] = time_s
	inputs[i + 2] = ground.x
	inputs[i + 3] = ground.y
	inputs[i + 4] = ground.z
	inputs[i + 5] = float(hold)
	inputs[i + 6] = stick.x
	inputs[i + 7] = stick.y
	inputs[i + 8] = target
	input_count += 1
	return true

func sample(row: PackedFloat64Array) -> void:
	if not active or tick % 3 != 0: return
	var offset := state_count * STATE_WIDTH
	states[offset] = tick
	states[offset + 1] = time_s
	for i in STATE_WIDTH - 2: states[offset + i + 2] = row[i]
	state_count += 1

func event(kind: int, lap := 0, seconds := NAN) -> void:
	if not active: return
	if event_count >= MAX_EVENTS - 1:
		stop(true)
		return
	_append_event(kind, lap, seconds)

func _append_event(kind: int, lap: int, seconds: float) -> void:
	var i := event_count * EVENT_WIDTH
	events[i] = tick
	events[i + 1] = time_s
	events[i + 2] = kind
	events[i + 3] = lap
	events[i + 4] = seconds
	event_count += 1

func stop(buffer_full := false) -> void:
	if not active: return
	full = buffer_full
	_append_event(10 if full else 1, 0, NAN)
	active = false

func write_zip(path: String) -> Error:
	if active: return ERR_BUSY
	var zip := ZIPPacker.new()
	var error := zip.open(path)
	if error != OK: return error
	var info := metadata.duplicate(true)
	info.merge({"ticks": tick, "duration_s": time_s, "buffer_full": full, "input_rows": input_count, "state_rows": state_count, "event_rows": event_count})
	error = _entry(zip, "metadata.yaml", yaml(info).to_utf8_buffer())
	for spec in [["inputs.csv", INPUT_COLUMNS, inputs, input_count, INPUT_WIDTH], ["states.csv", STATE_COLUMNS, states, state_count, STATE_WIDTH], ["events.csv", EVENT_COLUMNS, events, event_count, EVENT_WIDTH]]:
		if error != OK: break
		error = zip.start_file(spec[0])
		if error != OK: break
		error = zip.write_file((spec[1] + "\n").to_utf8_buffer())
		# Stream rows to the compressor instead of building one huge CSV string.
		var cells := PackedStringArray()
		cells.resize(spec[4])
		for r in spec[3]:
			if error != OK: break
			for c in spec[4]:
				var value: float = spec[2][r * spec[4] + c]
				cells[c] = "" if is_nan(value) else String.num(value, 9)
				if c == 0: cells[c] = str(int(value))
				if spec[0] == "events.csv" and c == 2: cells[c] = EVENT_NAMES[int(value)]
			error = zip.write_file((",".join(cells) + "\n").to_utf8_buffer())
		var close_error := zip.close_file()
		if error == OK: error = close_error
	var close_error := zip.close()
	return close_error if error == OK else error

func _entry(zip: ZIPPacker, name: String, data: PackedByteArray) -> Error:
	var error := zip.start_file(name)
	if error != OK: return error
	error = zip.write_file(data)
	var closed := zip.close_file()
	return closed if error == OK else error

static func yaml(value: Variant, indent := "") -> String:
	# Small YAML emitter for the snapshot's scalar/map/list/vector types.
	if value is Dictionary:
		if value.is_empty(): return "{}\n"
		var result := ""
		for key in value:
			var child: Variant = value[key]
			result += indent + JSON.stringify(str(key)) + ":"
			result += "\n" + yaml(child, indent + "  ") if child is Dictionary and not child.is_empty() else " " + yaml(child)
		return result
	if value is Vector3: return "[%s, %s, %s]\n" % [value.x, value.y, value.z]
	if value is Vector2: return "[%s, %s]\n" % [value.x, value.y]
	return JSON.stringify(value) + "\n"
