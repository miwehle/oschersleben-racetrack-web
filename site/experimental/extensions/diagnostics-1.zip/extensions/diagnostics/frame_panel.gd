extends PanelContainer
## Native frame intervals from the monotonic clock, including waiting for presentation.
const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
const POSITION_FILE := "user://frame_diagnostics_position.cfg"
var stats = preload("frame_stats.gd").new()
var value := Label.new()
var chart := Chart.new()
var move_button := Button.new()
var _last_us := 0
var _next_refresh_us := 0
var _focused := true
var _dragging := false
var _drag_offset := Vector2.ZERO

class Chart extends Control:
	var data := {"count": 0, "counts": [0, 0, 0, 0, 0, 0], "p95": 0.0}
	func _draw() -> void:
		var font := ThemeDB.fallback_font
		var width := size.x
		draw_string(font, Vector2(0, 16), "P95", HORIZONTAL_ALIGNMENT_LEFT, -1, 14)
		for i in 3:
			draw_rect(Rect2(width * i / 3.0, 25, width / 3.0, 8), [Color("48bd76"), Color("e9ba48"), Color("e35b52")][i])
		if data.count > 0:
			var x := clampf((data.p95 - 10.0) / 30.0, 0, 1) * width
			draw_line(Vector2(x, 21), Vector2(x, 37), Color.WHITE, 3)
		for i in 4:
			draw_string(font, Vector2((width - 30) * i / 3.0, 53), str(10 + 10 * i), HORIZONTAL_ALIGNMENT_LEFT, -1, 13)
		for i in 6:
			var share: float = float(data.counts[i]) / data.count if data.count else 0.0
			var x := width * i / 6.0
			var height := maxf(1, share * 60.0)
			draw_rect(Rect2(x, 143 - height, width / 6.0 - 6, height), Color("67cfff"))
			draw_string(font, Vector2(x, 138 - height), "%d%%" % roundi(share * 100), HORIZONTAL_ALIGNMENT_LEFT, -1, 13)
			draw_string(font, Vector2(x, 161), ["17", "25", "33", "50", "100", ">100"][i], HORIZONTAL_ALIGNMENT_LEFT, -1, 13)
		draw_string(font, Vector2(0, 186), "Letzte 10 s", HORIZONTAL_ALIGNMENT_LEFT, -1, 13)

func _ready() -> void:
	custom_minimum_size.x = 300
	position = Vector2(12, get_viewport_rect().size.y - 320)
	var saved := ConfigFile.new()
	if saved.load(POSITION_FILE) == OK:
		var at = saved.get_value("panel", "position", position)
		if at is Vector2 and at.is_finite(): position = at
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.06, 0.13, 0.17, 0.8)
	style.set_content_margin_all(12)
	add_theme_stylebox_override("panel", style)
	var rows := VBoxContainer.new()
	rows.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(rows)
	move_button.toggle_mode = true
	move_button.custom_minimum_size = Vector2(32, 32)
	move_button.size_flags_horizontal = Control.SIZE_SHRINK_END
	move_button.icon = preload("res://ui/icons/lock_icon.svg")
	move_button.toggled.connect(func(unlocked):
		_dragging = false
		move_button.icon = preload("res://ui/icons/unlock_icon.svg") if unlocked else preload("res://ui/icons/lock_icon.svg"))
	rows.add_child(move_button)
	var title := Label.new()
	title.text = "Framezeit (ms)"
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rows.add_child(title)
	value.add_theme_font_size_override("font_size", 24)
	value.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rows.add_child(value)
	chart.custom_minimum_size = Vector2(276, 190)
	chart.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rows.add_child(chart)
	visibility_changed.connect(_reset)
	get_viewport().size_changed.connect(_clamp_position)
	resized.connect(_clamp_position)
	UiLayout.bind_hud.call_deferred(self)
	hide()
	_reset()

func _reset() -> void:
	stats.reset()
	_last_us = 0
	_next_refresh_us = 0
	_dragging = false
	value.text = "EMA –"
	chart.data = stats.snapshot(0)
	chart.queue_redraw()
	set_process(visible)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_FOCUS_IN:
		_focused = what == NOTIFICATION_APPLICATION_FOCUS_IN
		_reset()

func _process(_delta: float) -> void:
	if not _focused: return
	var now := Time.get_ticks_usec()
	if _last_us > 0: stats.add(now / 1000.0, (now - _last_us) / 1000.0)
	_last_us = now
	if now < _next_refresh_us: return
	_next_refresh_us = now + 200000
	chart.data = stats.snapshot(now / 1000.0)
	value.text = UiNumbers.display("EMA %.1f" % stats.ema) if stats.count else "EMA –"
	chart.queue_redraw()

func _clamp_position() -> void:
	position = position.clamp(Vector2.ZERO, (get_viewport_rect().size - size * scale).max(Vector2.ZERO))

func _gui_input(event: InputEvent) -> void:
	if not move_button.button_pressed: return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_dragging = event.pressed
		if _dragging: _drag_offset = event.position
		elif not DrivingSetup.temporary:
			var saved := ConfigFile.new()
			saved.set_value("panel", "position", position)
			saved.save(POSITION_FILE)
		accept_event()
	elif event is InputEventMouseMotion and _dragging:
		position += (event.position - _drag_offset) * scale
		_clamp_position()
		accept_event()
