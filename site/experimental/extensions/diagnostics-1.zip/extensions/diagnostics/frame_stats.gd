extends RefCounted
## Same ten-second window, class limits and one-second EMA as the browser display.
const CAPACITY := 4096
const LIMITS := [1000.0 / 60.0, 25.0, 1000.0 / 30.0, 50.0, 100.0, INF]
var times := PackedFloat64Array()
var frames := PackedFloat64Array()
var head := 0
var count := 0
var ema := 0.0

func _init() -> void:
	times.resize(CAPACITY)
	frames.resize(CAPACITY)

func reset() -> void:
	head = 0
	count = 0
	ema = 0.0

func add(now_ms: float, interval_ms: float) -> void:
	if not is_finite(interval_ms) or interval_ms <= 0: return
	_expire(now_ms)
	ema = interval_ms if count == 0 else lerpf(ema, interval_ms, 1.0 - exp(-interval_ms / 1000.0))
	times[head] = now_ms
	frames[head] = interval_ms
	head = (head + 1) % CAPACITY
	count = mini(count + 1, CAPACITY)

func snapshot(now_ms: float) -> Dictionary:
	_expire(now_ms)
	var values: Array[float] = []
	var counts := [0, 0, 0, 0, 0, 0]
	for n in count:
		var value := frames[(head - count + n + CAPACITY) % CAPACITY]
		values.append(value)
		for i in LIMITS.size():
			if value <= LIMITS[i]:
				counts[i] += 1
				break
	values.sort()
	return {"count": count, "counts": counts, "ema": ema,
		"p95": values[ceili(count * 0.95) - 1] if count else 0.0}

func _expire(now_ms: float) -> void:
	while count > 0 and times[(head - count + CAPACITY) % CAPACITY] <= now_ms - 10000.0:
		count -= 1
