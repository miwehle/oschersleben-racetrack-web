# Diagnose

## Optionale Erweiterung

Unter **Einstellungen → Erweiterungen → Diagnose hinzufügen** aktivieren. Dadurch erscheint der eigene Tab **Diagnose** mit Browser-Aufzeichnung und lokaler Gamepad-Diagnose. **Info** enthält nur die allgemeinen App-Informationen. Die Erweiterung startet keine Aufnahme von selbst; ihre Auswahl wird wie bei den anderen Erweiterungen lokal gemerkt.

Entfernen beendet Anzeigen und entfernt Tab, Dialoge, Beobachter und Browser-Timer. Während einer Aufnahme, Referenzmessung oder ausstehenden Übertragung bleibt die Erweiterung aktiv; zuerst die Aufnahme beenden und die Übertragung abwarten. Erneutes Hinzufügen erzeugt genau eine neue Instanz. Der Kraftvektor und alle normalen Cockpit-Instrumente bleiben unabhängig davon sichtbar.

Die Kern-App stellt nur Beobachtungssignale an den Grenzen von Physik und Darstellung sowie bei fehlendem Bodenkontakt bereit. Fahrzeugbefehle und Runden kommen über die vorhandenen Simulationssignale. Der Gamepad-Monitor verwendet diese direkt und benötigt die Diagnose nicht. Messung, Historie, Anzeigen und Aufzeichnung gehören der Erweiterung.

Zwei gemeinsam benötigte Bausteine bleiben im Kern: `res://performance/startup.js` erfasst den Start schon vor dem Laden einer Erweiterung; `res://ui/session_info.js` liefert auch die Geräteklasse für Grafikvorgaben. Die CPU-Referenz unter `res://performance/` wird weiterhin von Tests und Diagnose verwendet. Entwickler-Anmeldung und Gastfreigaben sind noch nicht implementiert.

## Quellstruktur

- `diagnostics.gd` und `ground_trace.gd`: Godot-Anbindung und Bodenkontakterfassung.
- `js/`: JavaScript für Messung und Aufzeichnung im Browser.
- `js/ui/`: Histogramm, Zeitverlauf und Verschieben der Anzeigen; das Histogramm erhält fertige Messwerte von `performance.js`.
- `js/tests/`: Node.js-Tests; `ui/` spiegelt die Anzeigenstruktur. Der Histogrammtest prüft die Darstellung, der Performance-Test die Übergabe der Messwerte. Tests sind nicht Teil des Web-Exports.
- `tests/`: Godot-Tests für Erweiterungslebenszyklus, Messung, Instrumente und Touch-Bedienung.


Unter **Einstellungen → Diagnose** gruppiert **Anzeigen** die Optionen **Framezeiten – Wert und Histogramm** und **Framezeiten – Zeitverlauf**. **Aufzeichnen → Cloud** enthält **Leistung**, die zugehörige **Ziel-Framezeit**, **Bodenprobleme** und den gemeinsamen **Gerätenamen**. **Aufzeichnen → Lokal** enthält die **Minimalmessung** samt Ergebnis und Kopierknopf. Alle fünf Optionen sind unabhängig und bei jedem Laden aus.

**Details zur Diagnose** klappt Browserangaben, Bedienhinweise und Erläuterungen zum Messverfahren auf. Beim erneuten Öffnen ist dieser Bereich wieder geschlossen. Das Aufklappen verändert keine Diagnoseeinstellung. Die Ziel-Framezeit zeigt zusätzlich die entsprechenden FPS; ihr Wert und die Messlogik bleiben unverändert.
Der Godot-Dialog verwendet `DialogPanel`, `UiLayout` und die gemeinsame Touch-Scrollleiste.
Während er geöffnet ist, bleibt das Einstellungsfenster verborgen: Seine eigenen
`_input`-Handler würden sonst trotz darüberliegendem Dialog Touch-Ereignisse abfangen.
Beim Schließen wird der bestehende Einstellungsentwurf wieder sichtbar.
✓ übernimmt die Auswahl; × oder Escape verwirft den Entwurf und lässt bestehende
Aufnahmen weiterlaufen. Eine Aufnahme stoppt durch Abwählen und ✓.
Ziel-FPS bewusst passend
zum Gerät/Spielziel wählen: 60 FPS sind keine automatisch gemessene Displayfrequenz.

## Aufnahmen einfach lesen

Jede Aufnahme unter `diagnostics/<UID>` beginnt mit **einem Kopfdatensatz**
(`kind: session`, Slot 0). Darin stehen Build, Browser/Version, Betriebssystem,
selbst eingegebener Gerätename, anfängliche Aufzeichnungsoptionen und die
Stillstandsgrenze von 1 km/h. Browser/Version und Betriebssystem stammen aus der
Selbstauskunft des Browsers: reduziert oder verändert möglich, bei unbekannten
Angaben `unknown`/`null`. Keine Betriebssystemversion oder Modellbestimmung daraus
ableiten. `session_info.js` kapselt diese kleine Zuordnung; kein Fingerprinting.

**Leistungsblöcke** (`kind: performance`, jetzt `schema: 2`) beantworten:

| Frage | Feld | Einheit/Bedeutung |
|---|---|---|
| Welche Runde? | `start.lap_number`, `end.lap_number` | Rundennummer wie in der App |
| Welcher Abschnitt? | `start.lap_time_ms`, `end.lap_time_ms` | bisherige Rundenzeit in Millisekunden |
| Wie schnell? | `start.speed_kmh`, `end.speed_kmh` | Momentwerte in km/h |
| Gefahren oder gestanden? | `phases.driving`, `phases.stationary` | getrennte Dauer, Bildzeit-, CPU- und GPU-Statistik |

`stationary` bedeutet **unter 1 km/h im Fahrmodus**; ab 1 km/h zählt `driving`.
`pause`, `flight`, `background` und `loading` bleiben eigene Phasen. Diese Trennung
ist keine Beurteilung von Fahrzeugphysik oder Messqualität. Start/Ende sind keine
mittlere Geschwindigkeit. In älteren Leistungsdaten (`schema: 1`) umfasst
`driving` auch Stillstand; diese Daten nicht ungeprüft mit neuen Fahrwerten vergleichen.

Beispiel (gekürzter Leistungsblock, Statistikfelder weggelassen):

```json
{
  "kind": "performance",
  "schema": 2,
  "duration_ms": 30000,
  "start": {"lap_number": 2, "lap_time_ms": 45000, "speed_kmh": 80},
  "end": {"lap_number": 2, "lap_time_ms": 75000, "speed_kmh": 0},
  "phases": {
    "driving": {"duration_ms": 24000},
    "stationary": {"duration_ms": 6000}
  }
}
```

Das bedeutet: Runde 2, Abschnitt 0:45–1:15; 24 Sekunden gefahren, sechs Sekunden
gestanden. FPS der Fahrt ausschließlich aus `phases.driving.frame_ms` berechnen.
Wie bisher: FPS = 1000 / mittlerer Bildabstand in ms; Perzentile nicht mitteln.

Ein gezählter Rundenabschluss beendet den Block noch vor dem Zurücksetzen der
Rundenuhr; der nächste beginnt bei 0 in der neuen Runde. Rücksetzen und Übergänge
in/aus dem Flugmodus trennen ebenfalls Blöcke. Ohne laufende Rundenwertung sind
Rundennummer und Rundenzeit `null`. Sonstige Endwerte stammen aus dem letzten
angezeigten Frame; kurze Übergangsintervalle liefern keinen Bildzeitmesswert.
Der normale Abschluss erfolgt weiterhin nach etwa 30 Sekunden, Versand einmal
pro Minute. Keine zusätzlichen Rundenereignisse oder Blockende-Gründe.

Die optionale Live-Anzeige ergänzt **X/Y/Z in Metern**, Y ist die Höhe.
Formatierung und Textaktualisierung höchstens zweimal pro Sekunde. Die drei
Koordinaten reisen mit dem bestehenden Diagnoseaufruf mit und überschreiben
lediglich den aktuellen Wert; keine Wegliste und keine Koordinaten in Leistungsblöcken.
Nur die bereits vorhandenen Bodenereignisse speichern weiterhin ihre Wegspur.

Geprüfter Datenumfang: Kopf mit Beispielgerätename etwa 300 Bytes, Leistungsblock
mit Fahren und Stillstand etwa 1 kB JSON. Die zusätzliche Stillstandsphase braucht
drei Histogrammpuffer mit insgesamt 12.012 Bytes (rund 12 kB), keine zeitlich
wachsende Liste. Der lokale Node-Test lag bei etwa 0,002 ms pro Messaufruf ohne
Godot-Bridge/Rendering; das ist keine Laufzeitmessung auf dem Tablet.

## Testbedingungen: Gerät und Akku

Der optionale **Gerätename** (maximal 80 Zeichen) wird erst mit ✓ lokal unter
`oschersleben.diagnostics.device_name` gespeichert. Während einer Aufnahme ist er
gesperrt, damit deren Kopfdatensatz eindeutig bleibt. Er erzeugt keine Geräte-ID.
Browser/Version und Betriebssystem erscheinen im Dialog als „Browserangabe“.

Eine Testnotiz ist nicht erforderlich und wird nicht mehr erfasst. Jede passende Leistungsaufnahme geht in die P-Prüfung ein. Der letzte Leistungsblock beim Stoppen erhält `recording_complete: true`; normale Blöcke enthalten `false`. Das bestätigt das Aufnahmeende, keinen Rundenabschluss. Der P-Check summiert mindestens 60 Sekunden tatsächliche Fahrzeit pro Geräte-/Browser-/Grafikprofil über alle passenden, vollständig übertragenen Aufnahmen. Die lokale Minimalmessung liefert keine Firebase-Aufnahme.

Für die Texteingabe auf Tablet/Smartphone ist im Webexport Godots virtuelle
Tastatur aktiviert (`html/experimental_virtual_keyboard`). Die Bedienung auf
Firefox/Android muss am Gerät noch bestätigt werden.

Erst bei Beginn einer Leistungs- oder Bodenaufnahme wird `navigator.getBattery()`
einmal angefragt, sofern vorhanden. Der gelieferte `BatteryManager` stellt die
aktuellen Werte für spätere Momentaufnahmen bereit. Keine zusätzlichen Timer,
Listener, Aufrufe pro Bild oder Uploads. Firefox stellt diese API nicht bereit.
Fehler beim Akkuabruf stoppen die Diagnose nicht.

Leistungsblöcke und Bodenereignisse enthalten zusätzlich `test_context`:

- `observed_utc`: Zeitpunkt der Momentaufnahme, beim Leistungsblock dessen Ende.
- `recording`: aktive Leistungs-/Bodenaufzeichnung bei dieser Momentaufnahme.
- `battery.status`: `available`, `unavailable`, `pending`, `error` oder `not_requested`;
  `level_percent` und `charging` sind bei fehlenden Werten **null**, nicht 0/false.

Der Kontext gilt nicht rückwirkend als Zustand des gesamten Blocks. Änderungen
an Aufzeichnungsoptionen schließen den bisherigen Leistungsblock ab.
Akku- und Ladezustand sind Browserangaben, keine unabhängigen Sensormessungen.
Energiesparmodus, Temperatur, CPU-/GPU-Takt und Drosselung werden **nicht** erfasst
oder aus dem Akkustand abgeleitet. Keine Compute Pressure API.

Der Kontext bleibt klein. Bestehende 6000-Zeichen-
und Versandlimits bleiben bestehen. Ein voller Test-Bodenbericht mit Kontext
liegt bei rund 3,5 kB. Tablet-Laufzeitkosten wurden noch nicht gemessen.

## Bodenprobleme

`ground_trace.gd` hält nur lokal etwa zehn Positions-/Eingabestichproben pro Sekunde
in einem Ringpuffer mit 51 Einträgen (bis zu fünf Sekunden). Pause, Flug, Sturz und
Fokusverlust leeren die Vorgeschichte; Zeitlücken über 250 ms ebenfalls.
Bei fehlgeschlagener Bodenabfrage wird einmal mit Detailerfassung nachgemessen,
bevor der Controller Geschwindigkeit und Eingaben zurücksetzt. Beide Fühler werden
erfasst, auch wenn bereits der vordere keinen Boden trifft. Der Fahrablauf bleibt gleich.
Erfolgreiche Bodenabfragen erzeugen keine ausführlichen Diagnose-Dictionaries.

Ein Ereignis (`kind: ground_failure`, `schema: 1`) enthält:

- Build und UTC-Zeit, letzte gültige Position und Geschwindigkeit vor dem Stopp;
- abgelehnte Kandidatenposition, Gierwinkel, Fühlerursprünge und relative Zielvektoren;
- Asphalt-/Geländetreffer mit Punkt, Normale, Bodenart und Kollisionsobjekt-Pfad;
- Ursache `missing_front`, `missing_rear`, `missing_both` oder `invalid_orientation`;
- chronologische `history` mit Spaltennamen in `columns`: relative Zeit in ms,
  XYZ in Metern, Gierwinkel in Radiant, Geschwindigkeit in m/s und drei Eingabewerte.

Initiale Platzierung/Rückkehr ist mit `context: placement` gekennzeichnet, normale
Fahrt mit `context: driving`. Fehlende Treffer sind leere Objekte, keine erfundenen
Nullkoordinaten. Normale Fahrstichproben sind auf Zentimeter bzw. 0,001 rad gerundet;
die detaillierten Ray-Daten beim Versand auf sechs Nachkommastellen.

Höchstens 20 Ereignisse pro Aufnahme, mindestens zehn Sekunden zwischen Ereignissen.
Gleiche Ursache in derselben 2-m-Rasterzelle wird innerhalb der Aktivierung nur einmal
gemeldet. Die Transportgrenze von 20 bleibt auch beim Umschalten innerhalb einer
laufenden Leistungsaufnahme bestehen. Ereignisse werden zeitnah versendet; im
Hintergrund erfolgt kein Versand. Keine laufende Datenbank-Leseverbindung.

**Nur Bodenaufzeichnung** aktiviert weder CPU-/Bildzeitmessung noch GPU-Abfragen oder
Leistungsblöcke. Sie benötigt keinen Multiplayer-Raum. Der Status im Dialog zeigt
erfasste/gesendete Ereignisse, bestätigte Nutzbytes, Warteschlange und verworfene Daten.
Ein Testereignis mit voller Wegspur und Trefferdetails benötigt etwa 3,4 kB JSON.
Die bestehenden Grenzen von 6000 Zeichen pro Payload und insgesamt 120 Slots pro
Aufnahme gelten gemeinsam für Leistung und Boden; es sind keine neuen Firebase-Regeln nötig.

Zur Analyse `payload` als JSON lesen und nach `kind` unterscheiden (ältere Datensätze
ohne `kind` sind Leistungsdaten). `history` zeigt die Anfahrt; `query.candidate` und
`query.yaw` erlauben eine Wiederholung der Bodenabfrage im passenden Build.

## Messgrenzen

### Direkte GPU-Zeit im Webexport

`gpu_timer.js` verwendet `EXT_disjoint_timer_query_webgl2` auf dem bestehenden
Godot-WebGL2-Kontext. `frame_pre_draw`/`frame_post_draw` begrenzen die GPU-Abfrage
um den Renderdurchlauf (3D und Godot-2D; kein HTML-Overlay oder Browser-Compositing).
Godots eingebauter GLES-GPU-Timestamp-Zähler unterstützt diese Webmessung nicht:
[Godot 4.7 GLES Utilities](https://github.com/godotengine/godot/blob/4.7-stable/drivers/gles3/storage/utilities.cpp).

Nur bei aktiver Leistungsanzeige/-aufzeichnung: höchstens vier Stichproben/s, höchstens vier ausstehende
Abfragen. Ergebnisse werden erst nach `QUERY_RESULT_AVAILABLE` gelesen; kein
`finish()`, kein Warten auf die GPU. Disjoint-Ereignisse, Kontextverlust und
Phasen-/Qualitätswechsel verwerfen ausstehende Abfragen. Nach fünf Sekunden ohne
Ergebnis wird die begrenzte Warteschlange verworfen und erneut versucht.

Live: GPU-Mittelwert und P95 der letzten zehn Sekunden, mit Stichprobenzahl `n`.
Das GPU-P95 beruht auf weniger Stichproben als das Bildabstands-P95. Keine Aussage
über prozentuale Hardware-Auslastung oder den vollständigen Weg bis zum Display.
Die Messung kann selbst Aufwand verursachen; auf dem Tablet mit ausgeschalteter
Diagnose gegenprüfen. Der erste lokale Browsertest lieferte positive Zeitwerte
ohne WebGL-Fehler; Unterstützung auf Android/Firefox ist noch zu prüfen.

Firebase: zusätzlich `gpu_timer`, `gpu_sample_interval_ms` und pro Phase `gpu_ms`
mit derselben Statistikstruktur. Ohne gültige Messwerte ist `gpu_ms` **null**,
niemals ein erfundener Nullwert. Fehlende Erweiterung erscheint ausdrücklich als
„GPU: nicht verfügbar (Browser/Gerät)“. Die Versandhäufigkeit bleibt unverändert.
Tests: `node godot/extensions/diagnostics/js/tests/test_gpu_timer.cjs` und `test_performance.cjs`.

Das Diagnose-Overlay startet links unten. Das kleine Schloss schaltet zwischen
fixiert (geschlossen) und verschiebbar (offen, gestrichelter Rand) um. Im offenen
Zustand am Overlay ziehen, danach wieder sperren. Die Position wird lokal unter
`oschersleben.diagnostics.position` gespeichert und bei Fensterwechseln auf den
sichtbaren Bereich begrenzt. Nach dem Laden ist es immer gesperrt. Im gesperrten
Zustand gehen Berührungen außerhalb des Schlosses an die Simulation durch.

- Bildabstand: monotone Browserzeit zwischen Aufrufen des Fahrcontrollers;
  enthält Wartezeit, misst weder GPU-Arbeitszeit noch tatsächliche Präsentation.
- CPU: Summe der Fahr-/Flug-Physikschritte seit dem letzten Bild plus Kamera/HUD
  im Frame-Aufruf des Controllers. Auch mehrere nachgeholte Physiktakte werden
  gezählt. Andere Nodes, Klangerzeugung, Renderer und Diagnose selbst liegen
  außerhalb dieses Abschnitts; dies ist keine gesamte CPU-Auslastung.
- Grün: P95 ≤ 20,0 ms; Gelb ≤ 30,0 ms; Rot darüber, unabhängig vom Zielwert. „Spät“ zählt Abstände
  über 1,5 × Budget. Das sind Diagnose-Schwellen, keine Hardware-Auslastung.
- Histogramme: 0,25-ms-Bins bis 250 ms; darüber wird für Perzentile konservativ
  das Maximum ausgegeben. Mittelwert, Maximum und Zähler bleiben unquantisiert.
  Keine Mittelung von Perzentilen beim späteren Vergleich.
- Anzeige: gleitende letzte zehn Sekunden (maximal 4096 Bildabstände), auch für
  P95 und Histogramm. Histogramm mit sechs beschrifteten Klassen
  und absoluten Prozentanteilen; Balkenhöhe 0–100 %, keine automatische Skalierung.
  Die Klassen sind unterschiedlich breit; gezeigt wird der Anteil je Klasse,
  keine Wahrscheinlichkeitsdichte. 16,7 und 33,3 ms entsprechen 60 und 30 FPS.
  EMA glättet Bildabstände mit einer Zeitkonstante von einer Sekunde. Einzelne
  Ausreißer deshalb weiterhin anhand Histogramm und P95 beurteilen.
  Phasen-/Sichtbarkeitswechsel setzen das Live-Fenster zurück. Beim Wechsel zwischen Fahren und Stillstand wird der EMA einschließlich des Übergangsintervalls kontinuierlich weiterberechnet; die Anzeige zeigt dabei keinen neuen Platzhalter. Andere Phasenwechsel, Hintergrund- und Renderqualitätswechsel setzen auch den EMA zurück.
  `live_frame_stats.js` hält einen festen 96-KiB-Ringpuffer; pro Bild ein Eintrag,
  Auswertung und DOM-Aktualisierung höchstens zweimal pro Sekunde, nur bei
  eingeschalteter Anzeige. Aufzeichnung allein sammelt keine Live-Werte.
  Firebase-Schema, Datenumfang und Versandrhythmus bleiben unverändert.
  Datenbank: ca. 30-Sekunden-Blöcke mit separaten Zusammenfassungen für `driving`,
  `stationary`, `flight`, `pause`, `loading`, `background`. Histogramme bleiben lokal.
  Erster Abstand nach Wechsel entfällt.
  Hintergrund hat Dauer, aber keine Frame-/CPU-Samples. Browser können Timer
  einfrieren: dann enthält ein Block einen längeren Hintergrundabschnitt.

## Separater Zeitverlauf

Bezeichnung in beiden Anzeigen: **Framezeit (ms)**. Gemeint ist der Zeitabstand zwischen zwei aufeinanderfolgenden Aufrufen der Spiel-Bildschleife, einschließlich Wartezeiten; nicht die reine Rechenzeit oder eine direkt gemessene Anzeigedauer. Diese Definition steht auch in Hilfe & Info. EMA und Zielwerte haben eine Nachkommastelle. Skalenbeschriftungen und Klassenlegenden verwenden gerundete ganze Millisekunden; die internen Grenzen bleiben unverändert (z. B. steht 17 im Histogramm für 1000/60 ms). Die kompakte Anzeige zeigt nur EMA, P95-Ampel und Histogramm; zusätzliche Zahlen für FPS, Mittelwert, P95, CPU/GPU sowie Grafikeinstellungen, Phase, Aufnahmezustand und Koordinaten entfallen. Die Überschrift lautet „Framezeit (ms)“, die Fußzeile „Letzte 10 s“. Die Ampelposition ist linear zu P95 auf einer festen Skala von 10,0 bis 40,0 ms; kleinere Werte bleiben am linken, größere am rechten Rand. Die drei gleich breiten Bereiche sind Grün bis einschließlich 20,0 ms, Gelb bis einschließlich 30,0 ms und Rot darüber. Die Ampel ist unabhängig vom eingestellten Zielwert; die Aufzeichnungsmetrik „Spät“ bleibt dagegen zielabhängig. Übergänge werden über 0,2 Sekunden geglättet, außer bei reduzierter Bewegung im Browser. Ohne Messwerte erscheint „EMA –“ und kein Strich. Messung, interne Zielwerte und Aufzeichnungsformat (einschließlich `target_fps`) bleiben unverändert. Die Klassengrenzen des bisherigen Histogramms bleiben unverändert.

Die Checkbox **Anzeigen → Framezeiten – Zeitverlauf** unter Einstellungen → Diagnose schaltet ein eigenes, unabhängig verschiebbares Fenster. Standard nach dem Laden ist aus; ✓ übernimmt, × verwirft den Entwurf. Das bisherige Diagnosefenster bleibt separat wählbar. Die Position des neuen Fensters wird unter `oschersleben.diagnostics.timeline.position` lokal gespeichert.

`frame_timeline.js` zeigt sechs Kurven für Framezeitklassen: Grün bis einschließlich 18,0 ms, Blau darüber bis einschließlich 25,0 ms, darüber bis 1000/30 ms, darüber bis 50 ms, darüber bis 100 ms und > 100 ms. Die grüne Klasse enthält bewusst eine Toleranz um das unveränderte Standardziel von 16,7 ms, damit kleine Schwankungen dort nicht ständig zwischen Grün und Blau wechseln. Die Grenze 1000/30 ms wird gerundet als 33 ms beschriftet. Y ist der Anteil an den gemessenen Bildabständen (0–100 %), X die Zeit der letzten 30 Sekunden. Jeder Punkt kombiniert die absoluten Zähler zweier abgeschlossener 500-ms-Abschnitte zu einem Einsekundenfenster; kein zusätzlicher EMA. Ein Abstand wird dem Abschnitt seines Endzeitpunkts zugeordnet. Die Anzeige liegt dadurch bis zu etwa 0,5 Sekunden hinter der Messung; die Auswertung erfolgt beim nächsten Frame-Aufruf. Das erste volle Fenster erscheint nach einer Sekunde. Leere Fenster sind Lücken, keine gemessenen null Prozent.

Pro Bild wird nur eine der sechs Klassen erhöht. Zwei Zählerfelder und 61 Punkte mit je sechs Anteilen belegen zusammen 1512 Bytes numerische Puffer, zuzüglich Objekt- und Canvas-Speicher. Zeichnen erfolgt höchstens zweimal pro Sekunde im normalen Messbetrieb; Einblenden, Rücksetzen und Größenänderung können zusätzlich zeichnen. Die Canvas-Pixeldichte ist auf 2 begrenzt. Nur der Zeitverlauf allein aktiviert weder GPU-Abfragen noch die Histogramme der bisherigen Anzeige/Aufzeichnung. Die vorhandene Godot-Messklammer und die Übergabe der Bildwerte bleiben nötig.

Ausgeschaltet und bei geöffnetem Diagnosedialog sammelt oder zeichnet der Verlauf nicht. Beim Wechsel zwischen Fahren und Stillstand bleibt der Verlauf einschließlich des Übergangsintervalls erhalten; die Leistungsaufzeichnung und das Histogramm trennen diese Phasen weiterhin; der EMA läuft ebenfalls kontinuierlich weiter. Andere Phasen-, Runden-, Renderqualitäts- und Hintergrundwechsel setzen den Verlauf zurück. Nach Unterbrechungen über 30 Sekunden beginnt eine neue Historie; kürzere Hänger bleiben als lange Bildabstände enthalten. Keine zusätzlichen Netzwerkzugriffe oder Datenfelder im Firebase-Schema.

Die Tests prüfen Klassenränder, gewichtete Fenster, Speichergrenze, Lücken, unabhängige Schalter und fehlende Netzwerk-/GPU-Aktivität. Sie belegen keine vernachlässigbaren Kosten auf dem Tablet: dort dieselbe Fahrt mehrfach mit identischer minimaler Leistungsaufzeichnung und wechselnd ausgeschalteten Fenstern, nur alter Anzeige, nur Zeitverlauf und beiden Anzeigen vergleichen. Auch lange Bildabstände und das warme Gerät prüfen; CPU-Anzeige allein enthält die Zeichenkosten nicht.

## Aufbau und Daten

Die Einstellungen bieten **3D-Renderauflösung: 100 / 75 / 50 %**. Die Prozentzahl
skaliert beide Achsen (100 / 56,25 / 25 % der Pixel), nur für 3D; Canvas und UI
bleiben in voller Auflösung. `ui/render_quality.gd` kapselt die Einstellung und
speichert sie lokal (`oschersleben.render.scale`, nativ `user://render.cfg`).
Die Live-Anzeige nennt die Stufe. Aufzeichnungen enthalten `render_3d_scale`;
`render` bezeichnet weiterhin die Canvas-Auflösung, nicht die reduzierte 3D-Fläche.
Ein Wechsel schließt den laufenden Block ab und setzt Live-Werte zurück, ohne
sofortigen Upload. Häufiges Umschalten kann zusätzliche kurze Blöcke erzeugen;
die vorhandenen Speicher-/Versandlimits bleiben bestehen.

**Kantenglättung (MSAA): Aus / 2× / 4× / 8×** ist optional wieder verfügbar,
insbesondere zum Vergleich auf leistungsfähigeren Notebooks. Standard ist Aus.
Die Wahl gilt nur lokal für diesen Browser/dieses Gerät; keine Synchronisierung.
Der neue Schlüssel `oschersleben.render.msaa.v2` (nativ `render/msaa_v2` in
`render.cfg`) ignoriert alte Versuche, damit MSAA auf dem Tablet nicht unerwartet
wieder eingeschaltet wird. Die Diagnose zeigt die gewählte Stufe und schreibt
`msaa_samples` pro Block; ein Wechsel trennt die Messblöcke. Der Wert bezeichnet
die angeforderte Stufe, keine Messung eventuell abweichender Treibergrenzen.

`diagnostics.gd` kapselt die Godot-JavaScript-Grenze und verbindet den nativen Dialog
`extensions/diagnostics/diagnostics_dialog.gd` mit Messung und Aufnahme. Der Fahrcontroller hat
eine optionale Messklammer sowie Anschlüsse für Wegspur, Phasen und Bodenfehler.
`performance.js` enthält Leistungsmessung, kleine HTML-Anzeige und den gemeinsam
genutzten REST-Transport für beide Aufzeichnungsarten. Kein Firebase-SDK,
keine Datenbank-Leser, keine Verbindung zu Multiplayer-Räumen.

Erst bei Aufnahmebeginn erfolgt anonyme Firebase-Anmeldung. Ohne Google-Konto des
Spielers. Token nur im Arbeitsspeicher, nie in Logs. REST schreibt mit `print=silent`
unter `diagnostics/<anonyme UID>/<Blocknummer>`; Entwickler lesen/exportieren über
die Firebase-Konsole. Andere Spieler dürfen diese Daten nicht lesen.

Ein Leistungsdatensatz enthält Serverzeit `t` und `payload` als JSON-String (Schema 2),
mit Build-Dateiname, Clientzeit, Ziel-FPS, Render-/Viewport-Abmessungen, DPR und
Messwerten je Phase und Testkontext. Zum Auswerten `JSON.parse(payload)` verwenden.
Keine automatisch erfassten Namen, Streckenpositionen oder Gerätekennungen außer
der temporären anonymen UID; die optionale Notiz enthält den eingegebenen Text.
Bodenereignisse enthalten ausdrücklich die oben beschriebenen Simulationspositionen.

## Begrenzungen

- Leistung: zwei Blöcke pro Minute, zusätzlicher Abschlussversand beim Ausschalten.
  Boden: ereignisgesteuerter Versand, höchstens 20 Ereignisse pro Aufnahme.
- Maximal 55 Minuten pro bewusster Aufnahme; höchstens 120 Slots pro UID und
  6000 Zeichen pro Payload in Regeln. Slot 0 ist für den Kopf reserviert,
  somit höchstens 119 Leistungs-/Bodenblöcke. Keine öffentliche Lesefreigabe.
- Vier wartende Blöcke; bei Überlauf älteste verwerfen, nach drei Versandfehlern
  Aufnahme stoppen. Beim Tab-Schließen können ungesendete Daten verloren gehen.
- Die Anzeige zählt bestätigte JSON-Nutzbytes, nicht TLS-/HTTP-/Auth-Overhead oder
  das Firebase-Abrechnungskontingent. Firebase-Lesen zur Auswertung verbraucht
  ebenfalls Kontingent.
- Keine automatische Löschung auf Spark eingerichtet: nach Analyse ältere
  Diagnose-UIDs in der Konsole löschen (vorher bei Bedarf exportieren). Neue
  Aufnahmen erzeugen neue UIDs; es gibt keine globale Speicher- oder Missbrauchs-
  garantie durch Clientgrenzen. Für öffentliche Dauernutzung Aufbewahrung planen.

Tests: `node godot/extensions/diagnostics/js/tests/ui/test_frame_histogram.cjs` und
`node godot/extensions/diagnostics/js/tests/test_performance.cjs` und
`node godot/extensions/diagnostics/js/tests/ui/test_frame_timeline.cjs` sowie
`node godot/tests/ui/test_session_info.cjs` sowie
`node godot/extensions/diagnostics/js/tests/test_live_frame_stats.cjs`; Godot-Regressionen und
Webexport wie im Haupt-README. Kostenmessung auf dem Zielgerät durch vergleichbare
Abschnitte mit Anzeige allein und Anzeige + Aufnahme; FPS allein beweisen keine
Leistungsreserve. Der Test mit virtueller Zeit prüft keine Tablet-Performance.
`godot/extensions/diagnostics/tests/test_ground_diagnostics.gd` prüft Ringpuffer, Entwurf/Übernahme und
Dialoglayout; `test_ground_contact.gd` die vollständigen Fehlerdetails beider Fühler.
`test_diagnostics_touch.gd` prüft Berührungen samt emulierten Mausereignissen bei
geöffneten Einstellungen: Checkboxen und Beschriftungen schalten genau einmal;
Schließen stellt die Einstellungen samt Entwurf wieder her.

## Minimalmessung

Die Checkbox „Minimalmessung“ ist unabhängig von den vier anderen Diagnose-Checkboxen. Änderungen gelten nach ✓. Zum Beenden den Haken entfernen und ✓ drücken; das Fenster bleibt mit dem Ergebnis geöffnet. „Ergebnis kopieren“ kopiert den Text. Das Ergebnis bleibt bis zur nächsten Minimalmessung im Speicher; beim Neuladen geht es verloren.

Die Minimalmessung misst die Zeitabstände am Ende der Fahrcontroller-Bildschleife mittels `performance.now()`. Sie aktiviert keine CPU-/GPU-Messung, Histogramme oder Netzwerkübertragung. Es gibt keine laufende Anzeige. Pause, Diagnosefenster und Hintergrund werden ausgespart. Fahren und Stillstand bleiben verbunden. Ein vorab angelegtes Float32Array speichert bis zu 65.536 Abstände (256 KiB); dann endet die Messung automatisch. Mittelwert, P95 (Nearest Rank), aktive Messdauer als Summe der Abstände und Anzahl über 50 ms werden erst beim Beenden berechnet.

Für Vergleiche dieselbe Strecke unter gleichen Bedingungen mehrfach fahren: zuerst nur Minimalmessung ohne Zahl, dann zusätzlich die zu prüfenden Diagnoseoptionen aktivieren. Der Vergleich zeigt deren zusätzlichen Aufwand einschließlich möglicher Wechselwirkungen. Auch die Minimalmessung selbst kostet etwas Zeit; sie ist keine vollständig unbeeinflusste Referenz. Displaymodus, Gerätezustand und Testdauer zwischen Durchläufen möglichst gleich halten.

## Startzeit (informativ)

`startup.js` wird durch `scripts/prepare_web_startup.py` inline in den HTML-Kopf vor dem Engine-Loader eingefügt. Es misst unabhängig von Diagnose-Schaltern, ohne Netzwerk oder dauerhafte lokale Speicherung. `total_ms` beginnt am Navigationszeitursprung und endet, sobald der Player nach der Bodenplatzierung einen Frame dargestellt hat und der Godot-Ladebildschirm ausgeblendet ist. Scheitert der Start vorher, entsteht keine erfolgreiche Startmessung. Ein normaler Reload beginnt eine neue Messung; die Wiederherstellung einer bestehenden Seite aus dem Back/Forward-Cache bleibt derselbe Seitenstart.

`milestones_ms` enthält die Ausführungszeit des ersten Messskripts, den Aufruf von `engine.startGame`, die erste dargestellte spielbereite Szene und die Bedienbarkeit. `assets_finished_ms` ist das späteste beobachtete Ende von WASM/PCK-Transfers. Download, Kompilierung und Initialisierung können sich überlappen: Die Meilensteine sind keine addierbaren CPU-Teilzeiten. `transfer_bytes` und `encoded_body_bytes` summieren die verfügbaren Navigation-/Resource-Timing-Angaben für das Dokument und gleichursprüngliche JS-/WASM-/PCK-/PNG-Ressourcen bis zum Start. Sie sind beobachtete Browserwerte, keine Garantie für vollständige Netzwerkbytes; fehlende Angaben bleiben null. `asset_delivery` hält für die drei gleichnamigen Hauptdateien (JS, WASM, PCK) die Ladeart fest: `cache` (keine Übertragung bei bekannter positiver Inhaltsgröße), `revalidated` (Cache nach Serverprüfung), `network` oder `unknown`. Grundlage sind vorhandene Resource-Timing-Angaben; zusätzliche Anfragen entstehen nicht. Fehlende, mehrdeutige und durch Service Worker vermittelte Angaben bleiben unbekannt. `cache` fasst diese Dateien zusammen: `cache`, `revalidated` (alle aus dem Cache, mindestens eine nach Serverprüfung), `network`, `mixed` (Cache und Netz) oder `unknown`. Das beschreibt den HTTP-Ladeweg dieser Dateien, nicht den Zustand etwa des WASM-Kompilierungscaches oder des gesamten Geräts. Alte Messungen bleiben unbekannt. Hintergrundzeiten werden mit `hidden_during_start` markiert und nicht aus der Gesamtdauer herausgerechnet.

Der lokale Messwert bleibt über `window.OscherslebenStartup.snapshot()` und im Diagnosestatus erreichbar. Bei aktivierter Cloud-Leistungsdiagnose sendet `performance.js` einen eigenen `kind: startup`-Datensatz (Schema 2, darin `startup.schema: 1`) mit Build, Gerätekennung und Browser. Reine Bodenaufzeichnung, Anzeigen und Minimalmessung lösen keinen Startdatenversand aus. Der Datensatz hat einen reservierten normalen Diagnoseslot, bleibt bis zur Bestätigung vor dem Überlaufen der Leistungsblock-Warteschlange geschützt und wird bei Fehlern an derselben Stelle erneut geschrieben. Nach bestätigtem Versand wird er im selben Seitenstart nicht erneut versendet. Die bestehende Grenze von drei Versandfehlern gilt weiter; ein späterer neuer Aufnahmeversuch kann unbestätigte Daten erneut senden. `page_start_id` erlaubt dem P-Check das Entfernen solcher Duplikate. Die bestehenden Firebase-Regeln reichen aus; es gibt keinen neuen Datenbankpfad.

`milestones_ms` enthält für neue Web-Starts drei weitere Zeitpunkte in Millisekunden seit Navigationsbeginn. `godot_script_start_ms` erfasst den Eintritt in `_init()` des ersten Projekt-Autoloads (DrivingSetup). `player_ready_start_ms` und `player_ready_end_ms` markieren Beginn und erfolgreichen Abschluss von `Player._ready()`. Ihre Differenz misst die Dauer dieses Aufrufs. Die Zeit bis zur bereits erfassten ersten spielbereiten Szene schließt anschließend unter anderem die Bodenplatzierung und das Zeichnen des ersten Bildes ein.

Offen (später ergänzen): Den Abschnitt zwischen `player_ready_end_ms` und `scene_ready_ms` weiter aufschlüsseln, insbesondere Bodenplatzierung und Wartezeit bis zum ersten dargestellten Bild. Anlass: Notebook-Start von Build `a985a41f6745` am 11.11.2026 mit 18,67 s in diesem Abschnitt bei insgesamt 29,37 s Startzeit; die Ursache ist bislang nicht bestimmt.

## Referenzen an Aufnahmegrenzen

Beim Übernehmen einer neu aktivierten Leistungsaufnahme misst `reference_benchmark.gd` zuerst CPU/GPU, danach startet die Aufzeichnung. Beim manuellen Stoppen wird zuerst der letzte Leistungsblock abgeschlossen, danach gemessen. Szenenbaum und Rendering werden währenddessen pausiert und anschließend auf ihren vorherigen Zustand zurückgesetzt; ein DOM-Hinweis bleibt sichtbar. Reines Anzeigen, Minimalmessung, Bodenaufzeichnung und unveränderte Leistungsaufnahme starten keine Benchmarks. Die Kern-App delegiert den Ablauf an das separate Modul.

Die unveränderte CPU-Aufgabe liegt gemeinsam für Tests und Browser unter `godot/performance/reference_cpu.gd`. Web-Verfahren v2: 100 zusätzliche Aufwärmläufe in Zehnerblöcken, danach fünf Messwerte. GPU: `js/gpu_reference.js`, 512² Pixel, 128 Zeichenaufrufe, 30 Aufwärm- und neun Messblöcke; maximal 20 Sekunden GPU-Laufzeit. Fehlender Timer, Hintergrund oder Messfehler bleiben ausdrücklich als Status erhalten. Keine CPU-Stoppuhr als GPU-Ersatz.

Separate `kind: reference`-Datensätze enthalten `stage: before/after`, Rohwerte und Versionen. `reference_run` verbindet sie mit den Leistungsblöcken, auch bei mehreren Leistungsaufnahmen innerhalb einer Bodenaufnahme. Bestehender Diagnosepfad und Warteschlange, keine neuen Firebase-Regeln. Der P-Check zeigt fehlende Referenzen, Streuung > Faktor 1,25 und Änderungen der Median-Dauer unter 0,75/über 1,25 als Hinweise; Frame-, GPU-Fahrzeit- und Startgrenzen werden nicht skaliert. Bei automatischem Zeitlimit, Übertragungsabbruch oder Schließen kann die Nachher-Referenz fehlen. Aufwärmen verändert den Zustand nach Standby; dieser Test ersetzt keine Messung des Kaltstarts.

## Automatische Geräteklasse

Leistungsaufnahmen und Startdatensätze enthalten `device_type` und `device_type_source: browser_class`. Die bestehende Browserauswertung erkennt iPhone/iPod und Android mit Mobile-Kennung als Smartphone, iPad und Android ohne Mobile-Kennung als Tablet. Macintosh mit mehreren Touchpunkten wird als iPad im Desktopmodus behandelt. Nicht-touchfähige Windows-, macOS-, ChromeOS- und Linux-Browser bilden die P-Check-Klasse Notebook; sie umfasst auch Desktop-PCs und ist keine Hardware-Modellbestimmung. Andere oder uneindeutige Angaben bleiben `unknown` (beispielsweise Windows mit Touch). Fenstergröße und manuell gewählte Steuerung ändern die Klasse nicht. Der Gerätename bleibt optional. Neue Aufzeichnungen werden nach Geräteklasse ausgewertet, ältere ohne dieses Feld weiterhin nach dem bisherigen Namen. Alte namenlose Datensätze werden nicht rückwirkend geraten.

## Framezeiten in der Desktop-App

Unter **Einstellungen → Diagnose → Framezeiten – Wert und Histogramm** lässt sich auch lokal eine Anzeige einschalten. ✓ übernimmt, × verwirft die Änderung; nach App-Start ist die Anzeige aus. Sie zeigt EMA (Zeitkonstante 1 s), P95 mit Ampel von 10–40 ms und die sechs Histogrammklassen der Browseranzeige über die letzten 10 s. Über das Schloss ist sie verschiebbar; die Position bleibt lokal gespeichert. Zeitverlauf und Cloud-Aufzeichnung bleiben Browserfunktionen.

`frame_panel.gd` misst die Abstände seiner Bildaufrufe mit `Time.get_ticks_usec()` einschließlich Wartezeiten. Hintergrundwechsel und erneutes Einschalten beginnen eine neue Messung. Ausgeschaltet findet keine Bildmessung statt. `frame_stats.gd` begrenzt den Speicher auf 4.096 Werte; die Anzeige wird höchstens fünfmal pro Sekunde aktualisiert. Die Statistik zählt auch gerenderte Bilder bei pausierter Simulation; sie ist keine reine GPU-Zeit.
