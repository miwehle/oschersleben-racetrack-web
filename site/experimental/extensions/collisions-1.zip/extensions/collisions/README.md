# Kollisionen

Optionale Erweiterung für Fahr- und Flugmodus. Unter Einstellungen → Erweiterungen „Kollisionen“ aktivieren. Gebäude und Tribünen einschließlich halbtransparenter Platzhalter stoppen den Landspeeder; die Bodenbegrenzung bleibt unverändert.

Beim Aufprall erklingt einmal „PONG!“, abhängig von der Geschwindigkeit auf die Fläche zu. Stick und Gas loslassen, dann auf der Stelle drehen und mit RT weiterfahren. A setzt sofort zum freien Startplatz zurück, im Fahrmodus und im Stillstand. Wenn der einmalige Versuch zum Abstandschaffen scheitert, bleibt nur die Rückkehr zum Start. Die eingeblendeten Schaltflächen sind auch mit Maus und Touch bedienbar; ohne Gamepad dienen Pfeiltasten beziehungsweise Touch-Lenkung zum Drehen.

Die Erweiterung erzeugt ihre statischen Hindernisflächen einmalig aus den unveränderten Track-Meshes mit den Namen `Building …`, `LP …` und `Grandstand |…`. Ihre eigene Physikschicht 3 ist von Asphalt und Gelände getrennt. Ein Quader aus den Fahrzeugabmessungen prüft den Bewegungsweg; eine konservative Zugabe berücksichtigt die Drehung zwischen zwei Schritten. Zum Drehen wird einmal Platz für die Hüllkugel um den Fahrzeugursprung gesucht. Enge Stellen können deshalb bewusst nur „Zurück zum Start“ anbieten.

Die Kern-App bietet zwei optionale Callbacks für Bewegung und Schrittübernahme sowie Anhalten und Zurücksetzen. Alle Kollisionszustände, Hinweise, Hindernisse und der erzeugte Klang gehören zur Erweiterung. Der Browser spielt den Klang über den bereits entsperrten Audiokontext der App ab. Ohne geladene Erweiterung werden keine Hinderniskörper oder Raumabfragen dafür erzeugt.

`tests/test_collisions.gd` prüft beide Fahrmodelle und den Flugmodus, schnelle Aufpralle, Freigabe gehaltener Eingaben, Drehen, Pause, Rückkehr zum Start, Engstellen und Entfernen der Erweiterung. Der gemeinsame Web-Test-Runner führt ihn am Quellprojekt und am exportierten Paket aus. Die praktische Klangabstimmung und Performance auf dem Tablet werden bei der Testfahrt geprüft.
