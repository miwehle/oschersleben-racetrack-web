extends Node3D
## Optional stop-and-turn recovery. All obstacle bodies belong to this extension.
const LAYER := 4
const MARGIN := 0.04
const TURN_RATE := PI / 4.0
const NEUTRAL := 0.08
const Geometry = preload("res://vehicles/landspeeder_geometry.gd")
enum State { MOVING, RELEASE, TURNING, BLOCKED, RESET_RELEASE }
var state := State.MOVING
var vehicle: Vehicle
var bounds := AABB()
var box := BoxShape3D.new()
var sphere := SphereShape3D.new()
var query := PhysicsShapeQueryParameters3D.new()
var previous_pitch := 0.0
var previous_bank := 0.0
var previous_yaw := 0.0
var dt := 0.0
var contact := Vector3.ZERO
var normal := Vector3.ZERO
var stick_released := false
var gas_released := false
var overlay := PanelContainer.new()
var message := Label.new()
var reset_button := Button.new()
var continue_button := Button.new()
var sound := AudioStreamPlayer.new()
var impact_count := 0
var room_ready := false
var web_sample := ""

func _ready() -> void:
	vehicle = get_parent().get_node("Player")
	bounds = Geometry.bounds()
	box.size = bounds.size
	var radius := 0.0
	for i in 8: radius = maxf(radius, bounds.get_endpoint(i).length())
	sphere.radius = radius + MARGIN * 2.0
	query.collision_mask = LAYER
	query.margin = MARGIN
	_build_obstacles()
	get_parent().get_node("BaseEnvironment").changed.connect(_build_obstacles)
	_build_overlay()
	add_child(sound)
	sound.stream = _pong()
	if OS.has_feature("web"): web_sample = Marshalls.raw_to_base64(sound.stream.data)
	vehicle.simulation_override = _step
	vehicle.movement_filter = _filter_motion
	vehicle.simulation_event.connect(_on_event)

func _build_obstacles() -> void:
	for child in get_children():
		if child is StaticBody3D:
			remove_child(child)
			child.queue_free()
	# Original Track remains available when its rendering is replaced by lightmaps.
	# Build once, never walk the scene or recreate shapes during a simulation step.
	var track := get_parent().get_node_or_null("Track")
	if track == null: return
	for mesh: MeshInstance3D in track.find_children("*", "MeshInstance3D", true, false):
		var title := str(mesh.name)
		if not (title.begins_with("Building ") or title.begins_with("LP ") or title.begins_with("Grandstand |")): continue
		var body := StaticBody3D.new()
		body.name = "Obstacle_" + title.validate_node_name()
		body.collision_layer = LAYER
		body.collision_mask = 0
		var shape := CollisionShape3D.new()
		var triangles := mesh.mesh.create_trimesh_shape()
		triangles.backface_collision = true
		shape.shape = triangles
		body.add_child(shape)
		add_child(body)
		body.global_transform = mesh.global_transform

func _build_overlay() -> void:
	vehicle.get_node("HUD").add_child(overlay)
	var rows := VBoxContainer.new()
	overlay.add_child(rows)
	message.add_theme_font_size_override("font_size", 20)
	message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rows.add_child(message)
	var actions := HBoxContainer.new()
	rows.add_child(actions)
	continue_button.text = "RT: Weiterfahren"
	continue_button.pressed.connect(_continue)
	actions.add_child(continue_button)
	reset_button.text = "A: Zurück zum Start"
	for button in [reset_button, continue_button]:
		button.custom_minimum_size.y = 48
		button.add_theme_font_size_override("font_size", 20)
	reset_button.pressed.connect(_reset)
	actions.add_child(reset_button)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.02, 0.04, 0.06, 0.85)
	style.set_content_margin_all(12)
	overlay.add_theme_stylebox_override("panel", style)
	UiLayout.bind_hud(overlay)
	overlay.hide()

func _process(_delta: float) -> void:
	overlay.visible = state != State.MOVING and not vehicle.simulation_paused and vehicle.has_focus
	if not overlay.visible: return
	overlay.scale = Vector2.ONE * UiLayout.factor
	overlay.reset_size()
	var viewport_size := get_viewport().get_visible_rect().size
	overlay.position = Vector2((viewport_size.x - overlay.size.x * UiLayout.factor) / 2.0, viewport_size.y * 0.22)
	continue_button.visible = state == State.TURNING
	var gamepad: bool = vehicle.keyboard_controls.is_gamepad()
	continue_button.text = "RT: Weiterfahren" if gamepad else "Weiterfahren"
	reset_button.text = "A: Zurück zum Start" if gamepad else "Zurück zum Start"
	match state:
		State.RELEASE, State.RESET_RELEASE:
			message.text = "Bitte Lenkstick loslassen" if not stick_released else "Bitte RT loslassen"
			if not gamepad: message.text = "Bitte Lenkung und Gas loslassen"
		State.TURNING:
			message.text = "Mit dem Lenkstick drehen." if gamepad else "Mit Pfeiltasten oder Touch-Lenkung drehen."
		State.BLOCKED: message.text = "Kein Platz zum Drehen."

func _input(event: InputEvent) -> void:
	if state == State.MOVING or vehicle.simulation_paused or not vehicle.has_focus: return
	if event is InputEventJoypadButton and event.device == vehicle.gamepad.device:
		if event.button_index == JOY_BUTTON_START: return # Settings remain accessible.
		if event.pressed and event.button_index == JOY_BUTTON_A: _reset()
		get_viewport().set_input_as_handled()
	elif event is InputEventKey and event.keycode in [KEY_LEFT, KEY_RIGHT, KEY_UP, KEY_DOWN]:
		# Recovery reads physical keys, not the driving controller's latched steps.
		get_viewport().set_input_as_handled()

func _controls() -> Vector3:
	if vehicle.keyboard_controls.is_gamepad():
		var stick: Vector2 = vehicle.gamepad.raw_steering
		if vehicle.flight_mode and vehicle.flight_keyboard.pitch_inverted: stick.y *= -1
		return Vector3(stick.x, stick.y, vehicle.gamepad.raw_throttle)
	var stick := Vector2(float(Input.is_physical_key_pressed(KEY_RIGHT)) - float(Input.is_physical_key_pressed(KEY_LEFT)),
		float(Input.is_physical_key_pressed(KEY_DOWN)) - float(Input.is_physical_key_pressed(KEY_UP)))
	var touch = vehicle.keyboard_touch.tablet
	if touch and touch.active:
		stick = touch.joystick.value if touch.joystick_mode or vehicle.flight_mode else Vector2(-vehicle.keyboard_touch.tablet_steering, 0)
	if vehicle.flight_mode and vehicle.flight_keyboard.pitch_inverted: stick.y *= -1
	return Vector3(stick.x, stick.y, vehicle.keyboard_touch.tablet_throttle)

func _step(delta: float) -> bool:
	dt = delta
	previous_pitch = vehicle.flight.pitch
	previous_bank = vehicle.flight.bank
	previous_yaw = vehicle.heading_yaw
	if state == State.MOVING: return false
	var controls := _controls()
	if state in [State.RELEASE, State.RESET_RELEASE]:
		stick_released = stick_released or Vector2(controls.x, controls.y).length() <= NEUTRAL
		gas_released = gas_released or controls.z <= NEUTRAL
		if stick_released and gas_released:
			if state == State.RESET_RELEASE:
				state = State.MOVING
			else:
				room_ready = room_ready or _make_room()
				state = State.TURNING if room_ready else State.BLOCKED
	elif state == State.TURNING:
		if controls.z > NEUTRAL:
			_continue()
			return true
		_rotate(Vector2(controls.x, controls.y), delta)
	return true

func _attitude(pose: Transform3D, pitch: float, bank: float) -> Transform3D:
	if vehicle.flight_mode: pose.basis *= Basis.from_euler(Vector3(pitch, 0, bank))
	return pose

func _query_at(pose: Transform3D, shape: Shape3D, motion := Vector3.ZERO) -> void:
	query.shape = shape
	query.transform = pose
	query.motion = motion
	query.margin = MARGIN

func _box_pose(pose: Transform3D) -> Transform3D:
	return pose * Transform3D(Basis.IDENTITY, bounds.get_center())

func _space() -> PhysicsDirectSpaceState3D:
	return get_world_3d().direct_space_state

func _filter_motion(before: Transform3D, after: Transform3D) -> Transform3D:
	var old_attitude := _attitude(before, previous_pitch, previous_bank)
	var new_attitude := _attitude(after, vehicle.flight.pitch, vehicle.flight.bank)
	var motion := after.origin - before.origin
	# Bound the small per-step rotation as well as translation. This conservative
	# margin prevents a rotating corner passing through a wall between samples.
	var angle := old_attitude.basis.get_rotation_quaternion().angle_to(new_attitude.basis.get_rotation_quaternion())
	_query_at(_box_pose(old_attitude), box, motion)
	query.margin += sphere.radius * angle
	var hit := _space().get_rest_info(query)
	var fraction := 0.0
	if hit.is_empty():
		var cast := _space().cast_motion(query)
		if cast[0] >= 1.0: return after
		fraction = cast[0]
		query.transform.origin += motion * cast[1]
		query.motion = Vector3.ZERO
		hit = _space().get_rest_info(query)
	var accepted := before
	accepted.origin += motion * maxf(0, fraction - MARGIN / maxf(motion.length(), MARGIN))
	normal = hit.get("normal", -motion.normalized())
	contact = hit.get("point", accepted.origin)
	vehicle.flight.pitch = previous_pitch
	vehicle.flight.bank = previous_bank
	if vehicle.flight_mode: vehicle.flight.yaw = previous_yaw
	else: vehicle.driving.heading_yaw = previous_yaw
	vehicle.stop_motion()
	state = State.RELEASE
	stick_released = false
	gas_released = false
	room_ready = false
	impact_count += 1
	var impact_speed := maxf(0.0, -motion.dot(normal) / maxf(dt, 0.001))
	sound.volume_db = linear_to_db(clampf(impact_speed / 25.0, 0.03, 1.0)) - 4.0
	if OS.has_feature("web"):
		var audio = JavaScriptBridge.get_interface("OscherslebenEngineAudio")
		if audio: audio.playEffect(web_sample, sound.stream.mix_rate, db_to_linear(sound.volume_db))
	elif DisplayServer.get_name() != "headless":
		sound.play()
	return accepted

func _make_room() -> bool:
	if normal.is_zero_approx(): return false
	var start := vehicle.global_transform
	var destination := start
	var separation := (start.origin - contact).dot(normal)
	destination.origin += normal * maxf(0, sphere.radius + MARGIN * 2.0 - separation)
	if not vehicle.flight_mode:
		var ground_pose: Variant = vehicle.ground.sample_pose(destination.origin, vehicle.heading_yaw)
		if ground_pose == null: return false
		destination = ground_pose
	else:
		var attitude := _attitude(destination, vehicle.flight.pitch, vehicle.flight.bank)
		destination.origin.y += vehicle.ground.flight_height_correction(destination.origin, attitude.basis, vehicle.ground.sample_height(destination.origin))
	_query_at(_box_pose(_attitude(start, vehicle.flight.pitch, vehicle.flight.bank)), box, destination.origin - start.origin)
	if _space().cast_motion(query)[0] < 1.0: return false
	_query_at(Transform3D(Basis.IDENTITY, destination.origin), sphere)
	if not _space().intersect_shape(query, 1).is_empty(): return false
	vehicle.global_transform = destination
	vehicle.reset_physics_interpolation()
	return true

func _rotate(stick: Vector2, delta: float) -> void:
	var yaw: float = vehicle.heading_yaw - stick.x * TURN_RATE * delta
	if vehicle.flight_mode:
		var pitch_limit := deg_to_rad(float(vehicle.flight.limits.pitch_deg))
		var pitch := clampf(vehicle.flight.pitch - stick.y * TURN_RATE * delta, -pitch_limit, pitch_limit)
		var next := Transform3D(Basis(Vector3.UP, yaw), vehicle.position)
		# Ground still applies while pitching on the spot.
		var attitude := _attitude(next, pitch, vehicle.flight.bank)
		next.origin.y += vehicle.ground.flight_height_correction(next.origin, attitude.basis, vehicle.ground.sample_height(next.origin))
		_query_at(Transform3D(Basis.IDENTITY, vehicle.position), sphere, next.origin - vehicle.position)
		var clear_path := _space().cast_motion(query)[0] >= 1.0
		_query_at(Transform3D(Basis.IDENTITY, next.origin), sphere)
		if not clear_path or not _space().intersect_shape(query, 1).is_empty():
			state = State.BLOCKED
			return
		vehicle.flight.yaw = yaw
		vehicle.flight.pitch = pitch
		vehicle.global_transform = next
	else:
		var pose: Variant = vehicle.ground.sample_pose(vehicle.position, yaw)
		if pose == null:
			state = State.BLOCKED
			return
		_query_at(Transform3D(Basis.IDENTITY, pose.origin), sphere)
		if not _space().intersect_shape(query, 1).is_empty():
			state = State.BLOCKED
			return
		vehicle.driving.heading_yaw = yaw
		vehicle.global_transform = pose

func _continue() -> void:
	if state != State.TURNING: return
	vehicle.stop_motion()
	state = State.MOVING
	room_ready = false
	overlay.hide()

func _reset() -> void:
	vehicle.return_to_start()
	state = State.RESET_RELEASE
	stick_released = false
	gas_released = false

func _on_event(kind: StringName, _lap: int, _seconds: float) -> void:
	if kind in [&"pause", &"focus_out"]: sound.stop()
	if kind == &"reset":
		room_ready = false
		state = State.RESET_RELEASE
		stick_released = false
		gas_released = false
	elif state in [State.RELEASE, State.TURNING] and kind in [&"pause", &"focus_out"]:
		state = State.RELEASE
		# Keep the already-created space; rearm without another displacement.
		gas_released = false
		stick_released = false

func _exit_tree() -> void:
	sound.stop()
	if is_instance_valid(vehicle):
		vehicle.simulation_override = Callable()
		vehicle.movement_filter = Callable()
		if state != State.MOVING: vehicle.stop_motion()
	if is_instance_valid(overlay): overlay.queue_free()

static func _pong() -> AudioStreamWAV:
	# A short descending rubbery tone, generated only when loading the extension.
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = 22050
	var data := PackedByteArray()
	data.resize(11025 * 2)
	var phase := 0.0
	for i in 11025:
		var t := float(i) / stream.mix_rate
		phase += TAU * (170.0 + 420.0 * exp(-t * 18.0)) / stream.mix_rate
		var sample := (sin(phase) + 0.22 * sin(2.7 * phase)) * exp(-t * 9.0) * minf(t * 400.0, 1.0)
		data.encode_s16(i * 2, int(sample * 22000))
	stream.data = data
	return stream
