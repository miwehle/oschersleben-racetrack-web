extends TextureRect
## Pull right to lean, push left to enrich. Relative drag also works with a touchpad.
signal adjusted(percent: float)
var viewport := SubViewport.new()
var knob: Node3D
var value := 100.0
var dragging := false
var accumulated := 100.0

func _ready() -> void:
	expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	custom_minimum_size = Vector2(130, 130)
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_HSIZE
	viewport.own_world_3d = true
	viewport.transparent_bg = true
	viewport.handle_input_locally = false
	viewport.msaa_3d = Viewport.MSAA_2X
	viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(viewport)
	texture = viewport.get_texture()
	var document := GLTFDocument.new()
	var state := GLTFState.new()
	if document.append_from_buffer(FileAccess.get_file_as_bytes("res://extensions/cessna172/mixture/knob.glb"), "", state) != OK:
		push_error("C172P-Gemischknopf konnte nicht geladen werden.")
		return
	var model := document.generate_scene(state)
	viewport.add_child(model)
	knob = model.find_child("Mixture", true, false)
	# The shaft behind the mounting plane is inside the cockpit, not visible in this HUD.
	var clip := Shader.new()
	clip.code = """shader_type spatial;
	uniform sampler2D paint : source_color, filter_linear_mipmap;
	varying float shaft_x;
	void vertex() { shaft_x = (MODEL_MATRIX * vec4(VERTEX, 1.0)).x; }
	void fragment() {
		if (shaft_x < 0.0) { discard; }
		ALBEDO = texture(paint, UV).rgb;
		ROUGHNESS = 0.6;
	}"""
	for surface in knob.mesh.get_surface_count():
		var material := ShaderMaterial.new()
		material.shader = clip
		material.set_shader_parameter("paint", knob.get_active_material(surface).albedo_texture)
		knob.set_surface_override_material(surface, material)
	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.keep_aspect = Camera3D.KEEP_WIDTH
	camera.size = 0.28 * 130.0 / 220.0 # Crop side margins without enlarging the knob.
	camera.near = 0.01
	viewport.add_child(camera)
	camera.position = Vector3(0.25, 0.11, 0.5)
	camera.look_at(Vector3(0.065, 0, 0))
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-30, -25, 0)
	viewport.add_child(light)
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.environment.ambient_light_color = Color.WHITE
	environment.environment.ambient_light_energy = 0.4
	viewport.add_child(environment)
	resized.connect(update_resolution)
	update_resolution()
	display(value)

func update_resolution() -> void:
	viewport.size = Vector2i((size * get_global_transform().get_scale()).max(Vector2.ONE))
	viewport.render_target_update_mode = SubViewport.UPDATE_ONCE

func display(percent: float) -> void:
	value = percent
	if is_instance_valid(knob):
		knob.position.x = -percent / 100.0 * 0.115
		viewport.render_target_update_mode = SubViewport.UPDATE_ONCE

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		dragging = true
		accumulated = value
		accept_event()

func _input(event: InputEvent) -> void:
	if not dragging: return
	if event is InputEventMouseMotion:
		var movement: float = event.relative.x / get_global_transform().get_scale().x
		accumulated = clampf(accumulated - movement * (0.05 if event.shift_pressed else 0.5), 0, 100)
		adjusted.emit(accumulated)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		dragging = false
		get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT: dragging = false
