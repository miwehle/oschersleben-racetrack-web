extends PanelContainer
## Manual elevator trim; positive values mean nose up. Resetting the flight recalculates trim.
const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
const AircraftModel = preload("jsbsim_model.gd")
const SETTINGS := "user://cessna172-trim-hud.cfg"
var vehicle: Vehicle
var wheel = preload("trim/wheel.gd").new()
var grip := Control.new()
var magnification := 0.7795513820184827
var _resizing := false
var _start_mouse := Vector2.ZERO
var _start_size := Vector2.ZERO
var _start_scale := 1.0
var trim_value := Range.new()
var title := Label.new()
var value_label := Label.new()
var placement := Vector2(0, 1)
var _dragging := false
var _drag_offset := Vector2.ZERO

func _ready() -> void:
	name = "CessnaTrim"
	custom_minimum_size.x = 54
	gui_input.connect(_drag_input.bind(self))
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.03, 0.06, 0.09, 0.94)
	style.set_content_margin_all(6)
	style.content_margin_left = 3
	style.content_margin_right = 3
	style.set_corner_radius_all(6)
	add_theme_stylebox_override("panel", style)
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 4)
	add_child(rows)
	title.text = "Nose\ndown"
	title.add_theme_font_size_override("font_size", 12)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.mouse_filter = Control.MOUSE_FILTER_STOP
	title.mouse_default_cursor_shape = Control.CURSOR_MOVE
	title.gui_input.connect(_drag_input.bind(title))
	rows.add_child(title)
	rows.add_child(wheel)
	var up := Label.new()
	up.text = "Nose\nup"
	up.add_theme_font_size_override("font_size", 12)
	up.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	up.mouse_filter = Control.MOUSE_FILTER_STOP
	up.mouse_default_cursor_shape = Control.CURSOR_MOVE
	up.gui_input.connect(_drag_input.bind(up))
	rows.add_child(up)
	value_label.add_theme_font_size_override("font_size", 13)
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rows.add_child(value_label)
	trim_value.min_value = -22
	trim_value.max_value = 19
	trim_value.step = 0.05
	trim_value.hide()
	add_child(trim_value)
	wheel.adjusted.connect(func(percent): trim_value.value = trim_degrees(percent / 100.0))
	trim_value.value_changed.connect(func(value):
		wheel.display(trim_normalized(value) * 100.0)
		_changed(value))
	grip.custom_minimum_size = Vector2(16, 16)
	grip.mouse_default_cursor_shape = Control.CURSOR_FDIAGSIZE
	grip.draw.connect(func():
		for inset in [3, 7, 11]:
			grip.draw_line(Vector2(grip.size.x - inset, 15), Vector2(grip.size.x, 15 - inset), Color(0.5, 0.72, 0.8), 1.5, true))
	grip.gui_input.connect(_resize_input)
	rows.add_child(grip)
	var saved := ConfigFile.new()
	if saved.load(SETTINGS) == OK:
		var at = saved.get_value("hud", "position", placement)
		if at is Vector2 and at.is_finite(): placement.y = clampf(at.y, 0, 1)
		var zoom = saved.get_value("hud", "magnification", magnification)
		if (zoom is float or zoom is int) and is_finite(zoom): magnification = clampf(zoom, 0.5, 3.0)
	vehicle.presentation_finished.connect(refresh)
	vehicle.model_status_changed.connect(refresh)
	vehicle.configuration_changed.connect(refresh)
	UiLayout.changed.connect(_place)
	resized.connect(_place)
	_place.call_deferred()
	refresh()
	UiLayout.bind_hud(self)

# Derived tab angle, not a separately simulated JSBSim state.
# Pilot sign convention: positive nose up (tab down), negative nose down (tab up).
static func trim_degrees(normalized: float) -> float:
	return normalized * (19.0 if normalized >= 0.0 else 22.0)

static func trim_normalized(degrees: float) -> float:
	degrees = snappedf(degrees, 0.05)
	return degrees / (19.0 if degrees >= 0.0 else 22.0)

func _changed(value: float) -> void:
	if visible and vehicle.registered_model is AircraftModel:
		vehicle.registered_model.runtime.set_pitch_trim(trim_normalized(value))

func refresh() -> void:
	visible = vehicle.registered_model is AircraftModel and vehicle.registered_model.model_ready
	if not visible:
		_dragging = false
		_resizing = false
		wheel.cancel_drag()
		return
	var normalized: float = vehicle.registered_model.runtime.pitch_trim
	trim_value.set_value_no_signal(trim_degrees(normalized))
	if not is_equal_approx(wheel.value, normalized * 100.0): wheel.display(normalized * 100.0)
	value_label.text = UiNumbers.display("%.2f°" % trim_value.value)

func _place() -> void:
	if not is_inside_tree(): return
	var room := (get_viewport_rect().size - Vector2(0, 16)).max(Vector2.ONE)
	var factor := minf(UiLayout.factor * magnification, minf(room.x / maxf(1, size.x), room.y / maxf(1, size.y)))
	scale = Vector2.ONE * factor
	position = Vector2(0, 8 + maxf(0, room.y - size.y * scale.y) * placement.y)
	if wheel.is_inside_tree(): wheel.update_resolution()

func _drag_input(event: InputEvent, source: Control) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_dragging = true
		_drag_offset = source.get_global_transform_with_canvas() * event.position - position
		accept_event()

func _resize_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_resizing = true
		_start_mouse = grip.get_global_transform_with_canvas() * event.position
		_start_size = size * scale
		_start_scale = scale.x / UiLayout.factor
		accept_event()

func _input(event: InputEvent) -> void:
	if _resizing:
		if event is InputEventMouseMotion:
			magnification = clampf(_start_scale * (1 + (event.position - _start_mouse).dot(_start_size) / _start_size.length_squared()), 0.5, 3.0)
			_place()
			get_viewport().set_input_as_handled()
		elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
			_finish_drag()
			get_viewport().set_input_as_handled()
		return
	if not _dragging: return
	if event is InputEventMouseMotion:
		var space := (get_viewport_rect().size - Vector2(0, 16) - size * scale).max(Vector2.ZERO)
		position = Vector2(0, clampf(event.position.y - _drag_offset.y, 8, 8 + space.y))
		placement = Vector2(0, (position.y - 8) / maxf(1, space.y))
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		_finish_drag()
		get_viewport().set_input_as_handled()

func _finish_drag() -> void:
	if not _dragging and not _resizing: return
	_dragging = false
	_resizing = false
	var saved := ConfigFile.new()
	saved.set_value("hud", "position", placement)
	saved.set_value("hud", "magnification", magnification)
	if saved.save(SETTINGS) != OK: push_error("Trimm-HUD-Position konnte nicht gespeichert werden.")

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT: _finish_drag()
