extends VehicleModel
## Scene frame: X east, Y up, -Z north. JSBSim owns position and attitude.
const Runtime = preload("runtime/runtime.gd")
var runtime := Runtime.new()
var state: Dictionary = {}
var _origin := Vector3.ZERO
var _latitude := -44.0
var _longitude := 170.0
var _altitude := 400.0
var _north_radius := 0.0
var _east_radius := 0.0
var _reference: Dictionary = {}
const AIRFRAME := AABB(Vector3(-5.5, -1.5, -4), Vector3(11.0, 3.1, 10.3))
const GROUND_MARGIN := 5.0

func prepare(tree: SceneTree, pose: Transform3D, parameters: Dictionary, reference: Dictionary = {}) -> bool:
	model_ready = false
	model_error = ""
	model_pause_reason = ""
	configure_reference(pose, reference)
	var initial := parameters.duplicate()
	initial.merge({"latitude_deg": _latitude, "longitude_deg": _longitude, "altitude_m": _altitude,
		"heading_rad": -atan2(pose.basis.z.x, pose.basis.z.z)}, true)
	if not await runtime.load_runtime(tree): return _failed()
	if not runtime.initialize(initial): return _failed()
	state = runtime.read_state()
	if state.is_empty(): return _failed()
	model_ready = true
	model_speed_mps = state.get("airspeed_mps", 0.0)
	model_throttle = runtime.trim.w
	return model_ready

func step(pose: Transform3D, commands: VehicleCommands, delta: float, ground: GroundProbe) -> Transform3D:
	if not model_ready or not model_pause_reason.is_empty() or delta == 0.0: return pose
	var input := Vector4(0, 0, 0, runtime.trim.w)
	if commands != null:
		if not commands is VehicleCommands.Aircraft:
			model_error = "JSBSim erwartet Flugzeug-Steuerbefehle."
			model_ready = false
			return pose
		input = Vector4(commands.surfaces.x * 0.35, commands.surfaces.y * 0.25, commands.surfaces.z * 0.35, commands.throttle)
	model_throttle = input.w
	var previous := state
	state = runtime.step(input, delta)
	if state.is_empty():
		_failed()
		return pose
	var next := state_pose()
	model_pause_reason = movement_blocked(pose, next, ground)
	if not model_pause_reason.is_empty():
		state = previous
		return pose
	model_speed_mps = state.airspeed_mps
	return next

## Uses the same linear latitude/longitude rectangle as georeferenced terrain packages.
## Other scenes retain a local tangent frame, with their own height offset.
func configure_reference(pose: Transform3D, reference: Dictionary) -> void:
	_reference = reference.duplicate(true)
	_origin = pose.origin + Vector3.UP * 400.0
	_altitude = _origin.y + reference.get("height_offset_m", 0.0)
	_latitude = -44.0
	_longitude = 170.0
	if reference.has_all(["bounds_wgs84", "size_m"]):
		var bounds: Array = reference.bounds_wgs84
		var size: Array = reference.size_m
		_longitude = bounds[0] + _origin.x / size[0] * (bounds[2] - bounds[0])
		_latitude = bounds[3] - _origin.z / size[1] * (bounds[3] - bounds[1])
	var lat := deg_to_rad(_latitude)
	var d := 1.0 - 0.00669437999014 * sin(lat) * sin(lat)
	_north_radius = 6378137.0 * (1.0 - 0.00669437999014) / pow(d, 1.5)
	_east_radius = 6378137.0 / sqrt(d) * cos(lat)

func state_pose() -> Transform3D:
	var position := _origin + Vector3(
		deg_to_rad(wrapf(state.longitude_deg - _longitude, -180, 180)) * _east_radius,
		state.altitude_m - _altitude,
		-deg_to_rad(state.latitude_deg - _latitude) * _north_radius)
	if _reference.has_all(["bounds_wgs84", "size_m"]):
		var bounds: Array = _reference.bounds_wgs84
		var size: Array = _reference.size_m
		position.x = (state.longitude_deg - bounds[0]) / (bounds[2] - bounds[0]) * size[0]
		position.z = (bounds[3] - state.latitude_deg) / (bounds[3] - bounds[1]) * size[1]
	var attitude := Basis(Vector3.UP, -state.yaw_rad) * Basis(Vector3.RIGHT, state.pitch_rad) * Basis(Vector3.BACK, -state.roll_rad)
	return Transform3D(attitude, position)

func reset_model(pose: Transform3D) -> Transform3D:
	model_pause_reason = ""
	if not runtime.reset():
		_failed()
		return pose
	state = runtime.read_state()
	model_ready = not state.is_empty()
	if not model_ready:
		_failed()
		return pose
	model_speed_mps = state.airspeed_mps
	model_throttle = runtime.trim.w
	return state_pose()

func dispose() -> void:
	runtime.dispose()
	state.clear()
	model_ready = false

func _failed() -> bool:
	model_error = runtime.error
	model_ready = false
	return false

func visual_state() -> Dictionary:
	return state

func flight_instruments() -> Dictionary:
	if state.is_empty(): return {}
	return {"speed_mps": state.airspeed_mps, "altitude_m": state.altitude_m,
		"height_datum": _reference.get("height_datum", "MSL"),
		"heading_deg": fposmod(rad_to_deg(state.yaw_rad), 360), "roll_deg": rad_to_deg(state.roll_rad),
		"pitch_deg": rad_to_deg(state.pitch_rad), "throttle": model_throttle,
		# Ideal instruments: calibrated airspeed (no pitot errors), standard pressure, true heading.
		"indicated_kts": state.indicated_kts, "pressure_altitude_ft": state.pressure_altitude_ft,
		"climb_fpm": state.climb_fps * 60.0, "propeller_rpm": state.propeller_rpm,
		"turn_rate": rad_to_deg(state.roll_rate_rps) / 20.0 + rad_to_deg(state.yaw_rate_rps) / 3.0,
		"slip": -state.pilot_y_fps2 / state.pilot_z_fps2 * 10.0 if absf(state.pilot_z_fps2) > 0.01 else 0.0}

## Sweep the aircraft envelope in <=10 m steps, before accepting the new pose.
## The runtime is reset after a safety pause; it never resumes from the rejected step.
func movement_blocked(previous: Transform3D, next: Transform3D, ground: GroundProbe) -> String:
	var steps := maxi(1, ceili(previous.origin.distance_to(next.origin) / 10.0))
	for i in range(1, steps + 1):
		var pose := previous.interpolate_with(next, float(i) / steps)
		for corner in 8:
			var point := pose * AIRFRAME.get_endpoint(corner)
			if _reference.has("size_m"):
				var size: Array = _reference.size_m
				if point.x < 0 or point.z < 0 or point.x >= size[0] or point.z >= size[1]:
					return "Sicherheitspause: Rand des verfügbaren Geländes erreicht."
			var height: Variant = ground.sample_height(point)
			if height == null:
				if _reference.has("size_m"): return "Sicherheitspause: Geländehöhe nicht verfügbar."
			elif point.y <= float(height) + GROUND_MARGIN:
				return "Sicherheitspause vor Bodenkontakt."
	return ""
