extends TextureRect
## Original C172P wheel, viewed edge-on; relative motion preserves fine adjustment.
signal adjusted(percent: float)
var viewport := SubViewport.new()
var mesh: Node3D
var value := 0.0
var dragging := false
var accumulated := 0.0
var touch_index := -1

func _ready() -> void:
	expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	custom_minimum_size = Vector2(40, 220)
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_VSIZE
	viewport.own_world_3d = true
	viewport.transparent_bg = true
	viewport.handle_input_locally = false
	viewport.msaa_3d = Viewport.MSAA_2X
	viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(viewport)
	texture = viewport.get_texture()
	var document := GLTFDocument.new()
	var state := GLTFState.new()
	if document.append_from_buffer(FileAccess.get_file_as_bytes("res://extensions/cessna172/trim/wheel.glb"), "", state) != OK:
		push_error("C172P-Trimrad konnte nicht geladen werden.")
		return
	var model := document.generate_scene(state)
	viewport.add_child(model)
	mesh = model.find_child("TrimWheel", true, false)
	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.keep_aspect = Camera3D.KEEP_HEIGHT
	camera.size = 0.19
	camera.near = 0.01
	camera.position.z = 1
	viewport.add_child(camera)
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-30, -25, 0)
	light.light_energy = 0.8
	viewport.add_child(light)
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.environment.ambient_light_color = Color.WHITE
	environment.environment.ambient_light_energy = 0.25
	viewport.add_child(environment)
	resized.connect(update_resolution)
	update_resolution()
	display(value)

func update_resolution() -> void:
	viewport.size = Vector2i((size * get_global_transform().get_scale()).max(Vector2.ONE))
	viewport.render_target_update_mode = SubViewport.UPDATE_ONCE

func display(percent: float) -> void:
	value = percent
	if is_instance_valid(mesh):
		# Positive rotation moves the visible front rim down: nose up.
		mesh.rotation.x = deg_to_rad(percent * 7.2)
		viewport.render_target_update_mode = SubViewport.UPDATE_ONCE

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			dragging = true
			accumulated = value
		elif event.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
			adjusted.emit(clampf(value + (-1 if event.button_index == MOUSE_BUTTON_WHEEL_UP else 1) * (0.1 if event.shift_pressed else 0.5), -100, 100))
		accept_event()
	elif event is InputEventScreenTouch and event.pressed and touch_index < 0:
		touch_index = event.index
		accumulated = value
		accept_event()

func _input(event: InputEvent) -> void:
	var movement := 0.0
	if dragging and event is InputEventMouseMotion:
		movement = event.relative.y * (0.01 if event.shift_pressed else 0.1)
	elif dragging and event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		dragging = false
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and event.index == touch_index:
		movement = event.relative.y * 0.1
	elif event is InputEventScreenTouch and event.index == touch_index and not event.pressed:
		touch_index = -1
		get_viewport().set_input_as_handled()
	if movement != 0:
		accumulated = clampf(accumulated + movement / get_global_transform().get_scale().y, -100, 100)
		adjusted.emit(accumulated)
		get_viewport().set_input_as_handled()

func cancel_drag() -> void:
	dragging = false
	touch_index = -1

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT: cancel_drag()
