extends "mixture/knob.gd"
## Original lever on a resizable translucent background; The lock switches between lever operation and HUD placement.
const AircraftModel = preload("jsbsim_model.gd")
const SETTINGS := "user://cessna172-mixture-hud.cfg"
var vehicle: Vehicle
var placement := Vector2(1, 1)
var magnification := 1.181179140796775
var grip := Control.new()
var move_button := Button.new()
var percentage := Label.new()
var _resizing := false
var _start_mouse := Vector2.ZERO
var _start_size := Vector2.ZERO
var _start_position := Vector2.ZERO
var _moving := false
var _offset := Vector2.ZERO

func _ready() -> void:
	super._ready()
	name = "CessnaMixture"
	size = custom_minimum_size
	var background := Panel.new()
	background.name = "Background"
	background.show_behind_parent = true
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.03, 0.06, 0.09, 0.5)
	style.set_corner_radius_all(6)
	background.add_theme_stylebox_override("panel", style)
	add_child(background)
	percentage.position = Vector2(22, size.y - 24)
	percentage.size = Vector2(size.x - 44, 20)
	percentage.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	percentage.add_theme_font_size_override("font_size", 14)
	percentage.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(percentage)
	grip.position = size - Vector2(22, 22)
	grip.size = Vector2(22, 22)
	grip.mouse_default_cursor_shape = Control.CURSOR_FDIAGSIZE
	grip.draw.connect(func():
		for inset in [5, 10, 15]:
			grip.draw_line(Vector2(inset, 20), Vector2(20, inset), Color(0.5, 0.72, 0.8), 1.5, true))
	grip.gui_input.connect(_begin_resize)
	add_child(grip)
	move_button.toggle_mode = true
	move_button.focus_mode = Control.FOCUS_NONE
	move_button.custom_minimum_size = Vector2(32, 32)
	move_button.size = Vector2(32, 32)
	move_button.icon = preload("res://ui/icons/lock_icon.svg")
	move_button.toggled.connect(_set_move_mode)
	add_child(move_button)
	_set_move_mode(false)
	adjusted.connect(func(percent):
		if visible and vehicle.registered_model is AircraftModel:
			vehicle.registered_model.runtime.set_mixture(percent / 100.0)
			display(percent))
	var saved := ConfigFile.new()
	if saved.load(SETTINGS) == OK:
		var at = saved.get_value("hud", "position", placement)
		if at is Vector2 and at.is_finite(): placement = at.clamp(Vector2.ZERO, Vector2.ONE)
		var zoom = saved.get_value("hud", "magnification", magnification)
		if (zoom is float or zoom is int) and is_finite(zoom): magnification = clampf(zoom, 0.5, 3.0)
	UiLayout.bind_hud(self)
	vehicle.presentation_finished.connect(refresh)
	vehicle.model_status_changed.connect(refresh)
	vehicle.configuration_changed.connect(refresh)
	UiLayout.changed.connect(_place)
	_place()
	refresh()

func display(percent: float) -> void:
	super.display(percent)
	percentage.text = "%d %%" % roundi(percent)

func refresh() -> void:
	visible = vehicle.registered_model is AircraftModel and vehicle.registered_model.model_ready
	if not visible:
		_moving = false
		_resizing = false
		dragging = false
		return
	var percent: float = vehicle.registered_model.runtime.mixture * 100
	if not is_equal_approx(value, percent): display(percent)

func _place() -> void:
	var room := (get_viewport_rect().size - Vector2(16, 16)).max(Vector2.ONE)
	scale = Vector2.ONE * minf(UiLayout.factor * magnification, minf(room.x / size.x, room.y / size.y))
	position = Vector2(8, 8) + (room - size * scale) * placement
	# Match the frame-time HUD: keep the lock at 32 px even when this HUD is enlarged.
	# Match the instruments' 14 px footer at 230 px HUD height; both scale with their HUD.
	var text_scale := size.y / 230.0
	percentage.scale = Vector2.ONE * text_scale
	percentage.size = Vector2((size.x - 44) / text_scale, 20)
	percentage.position = Vector2(22, size.y - 26 * text_scale)
	move_button.scale = Vector2.ONE / scale
	move_button.position = Vector2(size.x - 36.0 / scale.x, 4.0 / scale.y)
	update_resolution()

func _set_move_mode(unlocked: bool) -> void:
	_finish_move()
	dragging = false
	move_button.icon = preload("res://ui/icons/unlock_icon.svg") if unlocked else preload("res://ui/icons/lock_icon.svg")
	mouse_default_cursor_shape = Control.CURSOR_MOVE if unlocked else Control.CURSOR_HSIZE

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed and move_button.button_pressed:
		_moving = true
		_offset = get_global_transform_with_canvas() * event.position - position
		accept_event()
	else: super._gui_input(event)

func _begin_resize(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_resizing = true
		_start_mouse = grip.get_global_transform_with_canvas() * event.position
		_start_size = size * scale
		_start_position = position
		grip.accept_event()

func _input(event: InputEvent) -> void:
	if _resizing:
		if event is InputEventMouseMotion:
			var delta: Vector2 = event.position - _start_mouse
			magnification = clampf((_start_size + delta).dot(size) / size.length_squared() / UiLayout.factor, 0.5, 3.0)
			_place()
			# Keep the top-left corner fixed unless the enlarged HUD leaves the screen.
			var space := (get_viewport_rect().size - Vector2(16, 16) - size * scale).max(Vector2.ZERO)
			position = _start_position.clamp(Vector2(8, 8), Vector2(8, 8) + space)
			placement = (position - Vector2(8, 8)) / space.max(Vector2.ONE)
			get_viewport().set_input_as_handled()
		elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
			_finish_move()
			get_viewport().set_input_as_handled()
		return
	if not _moving:
		super._input(event)
		return
	if event is InputEventMouseMotion:
		var space := (get_viewport_rect().size - Vector2(16, 16) - size * scale).max(Vector2.ZERO)
		position = (event.position - _offset).clamp(Vector2(8, 8), Vector2(8, 8) + space)
		placement = (position - Vector2(8, 8)) / space.max(Vector2.ONE)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		_finish_move()
		get_viewport().set_input_as_handled()

func _finish_move() -> void:
	if not _moving and not _resizing: return
	_moving = false
	_resizing = false
	var saved := ConfigFile.new()
	saved.set_value("hud", "position", placement)
	saved.set_value("hud", "magnification", magnification)
	if saved.save(SETTINGS) != OK: push_error("Gemisch-HUD-Position konnte nicht gespeichert werden.")

func _notification(what: int) -> void:
	super._notification(what)
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT: _finish_move()
