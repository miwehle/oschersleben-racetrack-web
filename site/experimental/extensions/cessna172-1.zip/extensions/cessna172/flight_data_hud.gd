extends PanelContainer
## Optional two-line strip: vertical terrain clearance and horizontal ground speed.
signal shown_changed(shown: bool)
const AircraftModel = preload("jsbsim_model.gd")
const SETTINGS := "user://cessna172-flight-data.cfg"
var vehicle: Vehicle
var shown := false
var placement := Vector2(0.5, 0.05)
var height_value := Label.new()
var speed_value := Label.new()
var _refresh_time := 0.0
var _dragging := false
var _offset := Vector2.ZERO

func _ready() -> void:
	name = "CessnaFlightData"
	mouse_default_cursor_shape = Control.CURSOR_MOVE
	gui_input.connect(_begin_drag)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.03, 0.06, 0.09, 0.9)
	style.set_content_margin_all(6)
	style.set_corner_radius_all(6)
	add_theme_stylebox_override("panel", style)
	var columns := HBoxContainer.new()
	columns.mouse_filter = Control.MOUSE_FILTER_IGNORE
	columns.add_theme_constant_override("separation", 24)
	add_child(columns)
	for item in [
		["Height (AGL)", height_value, "Höhe senkrecht über dem Gelände direkt unter dem Flugzeug. In Metern und Fuß. An diesem Streifen ziehen, um ihn zu verschieben."],
		["Speed (GS)", speed_value, "Horizontale Geschwindigkeit über Grund. In Knoten und Kilometern pro Stunde. An diesem Streifen ziehen, um ihn zu verschieben."]
	]:
		var rows := VBoxContainer.new()
		rows.custom_minimum_size.x = 185
		rows.mouse_filter = Control.MOUSE_FILTER_PASS
		rows.tooltip_text = item[2]
		rows.add_theme_constant_override("separation", 2)
		columns.add_child(rows)
		var caption := Label.new()
		caption.text = item[0]
		caption.add_theme_font_size_override("font_size", 13)
		caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		rows.add_child(caption)
		var value: Label = item[1]
		value.text = "—"
		value.add_theme_font_size_override("font_size", 20)
		value.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		rows.add_child(value)
	var saved := ConfigFile.new()
	if saved.load(SETTINGS) == OK:
		shown = bool(saved.get_value("hud", "shown", false))
		var at = saved.get_value("hud", "position", placement)
		if at is Vector2 and at.is_finite(): placement = at.clamp(Vector2.ZERO, Vector2.ONE)
	UiLayout.changed.connect(_place)
	resized.connect(_place)
	UiLayout.bind_hud(self)
	_place.call_deferred()
	refresh()

func set_shown(value: bool) -> void:
	shown = value
	_save()
	refresh()
	shown_changed.emit(value)

func _process(delta: float) -> void:
	_refresh_time -= delta
	if _refresh_time <= 0:
		_refresh_time = 0.2
		refresh()

func refresh() -> void:
	visible = shown and vehicle.registered_model is AircraftModel and vehicle.registered_model.model_ready
	if not visible:
		_dragging = false
		return
	var point := vehicle.global_position
	var ground: Variant = vehicle.ground.sample_height(point)
	height_value.text = "—" if ground == null else "%.0f m · %.0f ft" % [point.y - float(ground), (point.y - float(ground)) / 0.3048]
	var speed: float = vehicle.registered_model.state.ground_speed_mps
	speed_value.text = "%.0f kt · %.0f km/h" % [speed / 0.5144444444444444, speed * 3.6]

func _save() -> void:
	var saved := ConfigFile.new()
	saved.set_value("hud", "shown", shown)
	saved.set_value("hud", "position", placement)
	if saved.save(SETTINGS) != OK: push_error("Flugdaten-HUD konnte nicht gespeichert werden.")

func _place() -> void:
	if not is_inside_tree(): return
	var room := (get_viewport_rect().size - Vector2(16, 16)).max(Vector2.ONE)
	scale = Vector2.ONE * minf(UiLayout.factor, minf(room.x / maxf(1, size.x), room.y / maxf(1, size.y)))
	position = Vector2(8, 8) + (room - size * scale) * placement

func _begin_drag(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_dragging = true
		_offset = get_global_transform_with_canvas() * event.position - position
		accept_event()

func _input(event: InputEvent) -> void:
	if not _dragging: return
	if event is InputEventMouseMotion:
		var space := (get_viewport_rect().size - Vector2(16, 16) - size * scale).max(Vector2.ZERO)
		position = (event.position - _offset).clamp(Vector2(8, 8), Vector2(8, 8) + space)
		placement = (position - Vector2(8, 8)) / space.max(Vector2.ONE)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		_finish_drag()
		get_viewport().set_input_as_handled()

func _finish_drag() -> void:
	if not _dragging: return
	_dragging = false
	_save()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT: _finish_drag()
