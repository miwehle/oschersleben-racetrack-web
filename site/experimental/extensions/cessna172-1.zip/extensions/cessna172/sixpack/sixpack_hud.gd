extends Control
## Cessna-only HUD: drag its background; drag the lower-right grip to scale proportionally.
const BASE_SIZE := Vector2(1400, 230)
const SETTINGS := "user://cessna172-sixpack.cfg"
const AircraftModel = preload("../jsbsim_model.gd")
var vehicle: Vehicle
var instruments = preload("instruments.gd").new()
var footer := Label.new()
var grip := Control.new()
var width := 939.8479824480804
var placement := Vector2(0.5, 1.0)
var _drag := ""
var _start_mouse := Vector2.ZERO
var _start_position := Vector2.ZERO
var _start_size := Vector2.ZERO
var _dashboard: Control
var _replacing := false
var _previous_dashboard_visibility := true

func _ready() -> void:
	name = "CessnaSixpack"
	size = BASE_SIZE
	mouse_filter = Control.MOUSE_FILTER_STOP
	var background := Panel.new()
	background.name = "Background"
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.045, 0.05, 0.96)
	style.set_corner_radius_all(8)
	background.add_theme_stylebox_override("panel", style)
	add_child(background)
	gui_input.connect(_begin_drag.bind("move"))
	add_child(instruments)
	var picture := TextureRect.new()
	picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	picture.texture = instruments.get_texture()
	picture.name = "Instruments"
	var mask := ShaderMaterial.new()
	mask.shader = preload("round_instruments.gdshader")
	picture.material = mask
	picture.position = Vector2(8, 6)
	picture.size = Vector2(BASE_SIZE.x - 16, (BASE_SIZE.x - 16) / 7.0)
	picture.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(picture)
	footer.position = Vector2(12, 204)
	footer.add_theme_font_size_override("font_size", 14)
	footer.tooltip_text = "Fahrt: idealer Fahrtmesser in Knoten. Höhe: Druckhöhe bei 1013,25 hPa. Kurs: rechtweisend. Variometer: ft/min. Drehzahl: RPM."
	footer.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(footer)
	grip.draw.connect(func():
		for inset in [8, 15, 22]:
			grip.draw_line(Vector2(inset, 34), Vector2(34, inset), Color(0.5, 0.72, 0.8), 2, true))
	grip.position = Vector2(BASE_SIZE.x - 42, 188)
	grip.size = Vector2(42, 42)
	grip.mouse_filter = Control.MOUSE_FILTER_STOP
	grip.mouse_default_cursor_shape = Control.CURSOR_FDIAGSIZE
	grip.tooltip_text = "Ziehen zum Vergrößern oder Verkleinern"
	grip.gui_input.connect(_begin_drag.bind("resize"))
	add_child(grip)
	var saved := ConfigFile.new()
	if saved.load(SETTINGS) == OK:
		var saved_width = saved.get_value("hud", "width", width)
		var saved_position = saved.get_value("hud", "position", placement)
		if (saved_width is float or saved_width is int) and is_finite(saved_width): width = saved_width
		# Preserve gauge size when adding the tachometer (also supports the old two-row HUD).
		if saved.has_section_key("hud", "width"):
			var columns: int = saved.get_value("hud", "columns", 3)
			if columns in [3, 6]: width *= 7.0 / columns
		if saved_position is Vector2 and saved_position.is_finite(): placement = saved_position.clamp(Vector2.ZERO, Vector2.ONE)
	_dashboard = vehicle.get_node("HUD/DashboardPanel")
	vehicle.presentation_finished.connect(refresh)
	vehicle.configuration_changed.connect(refresh)
	vehicle.model_status_changed.connect(refresh)
	UiLayout.changed.connect(_place)
	_place()
	refresh()
	UiLayout.bind_hud(self)

func refresh() -> void:
	var active := vehicle.registered_model is AircraftModel and vehicle.registered_model.model_ready
	if active != _replacing:
		if active:
			_previous_dashboard_visibility = _dashboard.visible
			_dashboard.hide()
		else: _dashboard.visible = _previous_dashboard_visibility
		_replacing = active
	visible = active
	if not active:
		_drag = ""
		instruments.render_target_update_mode = SubViewport.UPDATE_DISABLED
		return
	var values: Dictionary = vehicle.registered_model.flight_instruments()
	instruments.display(values)
	footer.text = "Gas %d %%     Höhe: STD 1013 hPa     Kurs: wahr" % roundi(values.throttle * 100)

func _exit_tree() -> void:
	if _replacing and is_instance_valid(_dashboard): _dashboard.visible = _previous_dashboard_visibility

func _place() -> void:
	var extent := get_viewport_rect().size - Vector2(16, 16)
	var maximum := maxf(1, minf(extent.x, extent.y * BASE_SIZE.x / BASE_SIZE.y))
	var pixels := clampf(width * UiLayout.factor, minf(640 * UiLayout.factor, maximum), maximum)
	scale = Vector2.ONE * pixels / BASE_SIZE.x
	position = Vector2(8, 8) + (extent - BASE_SIZE * scale) * placement
	instruments.size = Vector2i(Vector2((BASE_SIZE.x - 16) * 4.0 / 7.0, (BASE_SIZE.x - 16) * 2.0 / 7.0) * scale)
	if visible: instruments.render_target_update_mode = SubViewport.UPDATE_ONCE

func _begin_drag(event: InputEvent, kind: String) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_drag = kind
		_start_mouse = (self if kind == "move" else grip).get_global_transform_with_canvas() * event.position
		_start_position = position
		_start_size = BASE_SIZE * scale
		accept_event()

func _input(event: InputEvent) -> void:
	if _drag.is_empty(): return
	if event is InputEventMouseMotion:
		var delta: Vector2 = event.position - _start_mouse
		if _drag == "resize":
			width = (_start_size + delta).dot(BASE_SIZE) / BASE_SIZE.length_squared() * BASE_SIZE.x / UiLayout.factor
			_place()
			# Keep the upper-left corner fixed while resizing, unless it leaves the viewport.
			_move_to(_start_position)
		else: _move_to(_start_position + delta)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		_finish_drag()
		get_viewport().set_input_as_handled()

func _move_to(at: Vector2) -> void:
	var space := (get_viewport_rect().size - Vector2(16, 16) - BASE_SIZE * scale).max(Vector2.ZERO)
	position = at.clamp(Vector2(8, 8), Vector2(8, 8) + space)
	placement = (position - Vector2(8, 8)) / space.max(Vector2.ONE)

func _finish_drag() -> void:
	if _drag.is_empty(): return
	_drag = ""
	width = BASE_SIZE.x * scale.x / UiLayout.factor
	var saved := ConfigFile.new()
	saved.set_value("hud", "columns", 7)
	saved.set_value("hud", "width", width)
	saved.set_value("hud", "position", placement)
	if saved.save(SETTINGS) != OK: push_error("Sixpack-Position konnte nicht gespeichert werden.")

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT: _finish_drag()
