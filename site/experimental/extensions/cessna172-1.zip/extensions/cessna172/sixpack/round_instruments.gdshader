shader_type canvas_item;
// The original cockpit mask hides square instrument cards. Make that mask transparent,
// retaining the seven opaque circular faces (80 mm gauges in a 90 mm grid).
void fragment() {
	// Source atlas order: airspeed, attitude, altitude, turn, heading, vertical speed, RPM.
	// Display order: 1, 2, 4, 6, 3, 5, RPM.
	float column = min(floor(UV.x * 7.0), 6.0);
	vec2 cell = vec2(UV.x * 7.0 - column, UV.y);
	const float order[7] = float[7](0.0, 1.0, 3.0, 5.0, 2.0, 4.0, 6.0);
	float source = order[int(column)];
	vec2 source_uv = (vec2(mod(source, 4.0), floor(source / 4.0)) + cell) / vec2(4.0, 2.0);
	vec4 instrument = texture(TEXTURE, source_uv);
	vec2 local = (cell - 0.5) * 0.09;
	float distance = length(local);
	float edge = fwidth(distance);
	instrument.a *= 1.0 - smoothstep(0.0398 - edge, 0.0398, distance);
	COLOR = instrument;
}
