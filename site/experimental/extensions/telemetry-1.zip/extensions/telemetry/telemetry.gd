extends "res://extension_system/extension.gd"
## Optional observer. All vehicle access here is read-only.
const Recording = preload("res://extensions/telemetry/recording.gd")
const CONFIG := "user://telemetry.cfg"
var player
var settings_menu
var recording: Recording
var saved := false
var busy := false
var controls: VBoxContainer
var indicator := Label.new()
var status := Label.new()
var start_button: Button
var stop_button: Button
var save_button: Button
var folder_button: Button
var discard_button: Button
var confirm := ConfirmationDialog.new()
var folder_dialog := FileDialog.new()
var folder := ""
var save_after_folder := false
var browser
var browser_callback
var row := PackedFloat64Array()
var previous_velocity := Vector3.ZERO
var derivative_valid := false
var step_pending := false
var before_position := Vector3.ZERO
var before_rotation := Quaternion.IDENTITY
var next_status := 0

func register() -> void:
	player = get_parent().get_node("Player")
	settings_menu = player.get_node("HUD/SettingsMenu")
	row.resize(Recording.STATE_WIDTH - 2)
	controls = VBoxContainer.new()
	extension_manager.add_dialog_section(self, controls, "Telemetrie · lokale ZIP-Datei", {"apply": _configuration_applied})
	extension_manager.add_hud_control(self, indicator)
	indicator.add_theme_font_size_override("font_size", 18)
	indicator.add_theme_color_override("font_color", Color(0.3, 0.85, 1))
	indicator.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	controls.add_child(status)
	start_button = settings_menu.add_action_button(controls, "Aufnahme starten", start_recording)
	stop_button = settings_menu.add_action_button(controls, "Aufnahme beenden", stop_recording)
	save_button = settings_menu.add_action_button(controls, "Als Datei speichern", save_recording)
	folder_button = settings_menu.add_action_button(controls, "Ordner ändern", choose_folder)
	discard_button = settings_menu.add_action_button(controls, "Aufnahme verwerfen", func(): confirm.popup_centered())
	confirm.dialog_text = "Diese Aufnahme aus dem Arbeitsspeicher verwerfen?"
	confirm.confirmed.connect(func():
		recording = null
		saved = false
		_refresh("Aufnahme verworfen."))
	add_child(confirm)
	folder_dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
	folder_dialog.access = FileDialog.ACCESS_FILESYSTEM
	folder_dialog.use_native_dialog = true
	folder_dialog.dir_selected.connect(func(path):
		folder = path
		var config := ConfigFile.new()
		config.set_value("export", "directory", folder)
		config.save(CONFIG)
		_refresh("Zielordner: " + folder)
		if save_after_folder:
			save_after_folder = false
			_export())
	folder_dialog.canceled.connect(func(): save_after_folder = false)
	add_child(folder_dialog)
	var config := ConfigFile.new()
	if config.load(CONFIG) == OK: folder = config.get_value("export", "directory", "")
	if OS.has_feature("web"):
		JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/telemetry/browser.js"), true)
		browser = JavaScriptBridge.get_interface("OscherslebenTelemetryFiles")
		browser_callback = JavaScriptBridge.create_callback(_browser_result)
		browser.init(browser_callback)
	observe(player.simulation_step_started, _begin_step)
	observe(player.simulation_step_finished, _finish_step)
	observe(player.simulation_event, _event)
	_refresh("Bereit · Aufnahme zunächst nur im RAM.")

func can_remove() -> bool:
	if busy or (recording != null and (recording.active or not saved)):
		_refresh("Vor dem Entfernen Aufnahme beenden und speichern oder verwerfen.")
		return false
	return true

func start_recording() -> void:
	if busy or (recording != null and not saved):
		_refresh("Vor einer neuen Aufnahme bitte speichern oder verwerfen.")
		return
	recording = Recording.new()
	saved = false
	var stamp := Time.get_datetime_string_from_system(true).replace(":", "-")
	var id := stamp + "-" + Crypto.new().generate_random_bytes(6).hex_encode()
	var info := {
		"format_version": 1, "recording_id": id, "created_utc": stamp,
		"build": settings_menu._build_version(), "scene": get_parent().scene_file_path,
		"route": player.ROUTE_FILE, "vehicle": "landspeeder",
		"track_length_m": player.route.length,
		"track_distance": "HUD distance from start/finish in meters, wraps at track_length_m; empty in flight",
		"physics_hz": Engine.physics_ticks_per_second, "state_every_ticks": 3,
		"time": "simulation seconds since start; tick N commands produce state N; resets preserve clock",
		"coordinates": "Godot world: Y up; quaternion x,y,z,w; body forward=-Z, left=-X; angular velocity world axes",
		"forces": "N, axle wheel axes: x forward, y left; static normal loads; limit includes sliding reduction",
		"derivatives": "velocity/acceleration/angular velocity from accepted poses each tick; empty after reset; no gravity subtraction",
		"missing": "empty CSV cell; ground_contact unknown in flight; lap times unvalidated",
		"initial_mode": "flight" if player.flight_mode else "ground",
		"initial_pose": {"position": player.position, "rotation": player.rotation},
		"driving_model": snapshot(player.driving), "engine": snapshot(player.engine_model),
		"flight": snapshot(player.flight), "gamepad": snapshot(player.gamepad),
		"keyboard": snapshot(player.keyboard_controls), "flight_keyboard": snapshot(player.flight_keyboard),
		"automatic_upshift": player.automatic_upshift, "auto_upshift_rpm": player.auto_upshift_rpm,
		"gamepad_name": Input.get_joy_name(player.gamepad.device) if player.gamepad.device >= 0 else "",
		"input_columns": Recording.INPUT_COLUMNS, "state_columns": Recording.STATE_COLUMNS,
		"event_columns": Recording.EVENT_COLUMNS,
	}
	recording.start(info)
	recording.metadata["configuration_changes"] = {}
	derivative_valid = false
	step_pending = false
	_refresh("Aufnahme läuft · maximal 32 MiB Messpuffer.")

static func snapshot(object: Object) -> Dictionary:
	var result := {"script": object.get_script().resource_path}
	for property in object.get_property_list():
		if not property.usage & PROPERTY_USAGE_SCRIPT_VARIABLE: continue
		var value: Variant = object.get(property.name)
		if typeof(value) in [TYPE_BOOL, TYPE_INT, TYPE_FLOAT, TYPE_STRING, TYPE_VECTOR2, TYPE_VECTOR3, TYPE_DICTIONARY]:
			result[property.name] = value.duplicate(true) if value is Dictionary else value
	return result

func _configuration_applied(_persist: bool) -> void:
	if recording == null or not recording.active: return
	# Changes happen in the paused settings UI, outside the hot sampling path.
	# Tick is the end of the last completed step; this snapshot applies afterwards.
	recording.metadata.configuration_changes[str(recording.tick)] = {
		"time_s": recording.time_s, "driving_model": snapshot(player.driving),
		"engine": snapshot(player.engine_model), "flight": snapshot(player.flight),
		"gamepad": snapshot(player.gamepad), "keyboard": snapshot(player.keyboard_controls),
		"flight_keyboard": snapshot(player.flight_keyboard),
		"automatic_upshift": player.automatic_upshift, "auto_upshift_rpm": player.auto_upshift_rpm}

func stop_recording() -> void:
	if recording: recording.stop()
	_refresh("Aufnahme beendet · noch nicht gespeichert.")

func _begin_step(dt: float, ground: Vector3, hold: bool, stick: Vector2, target: float) -> void:
	if recording == null or not recording.active: return
	step_pending = recording.begin_step(dt, ground, hold, stick, target)
	before_position = player.position
	before_rotation = player.quaternion

func _finish_step(dt: float) -> void:
	if not step_pending: return
	step_pending = false
	var velocity: Vector3 = (player.position - before_position) / dt
	var rotation_delta: Quaternion = player.quaternion * before_rotation.inverse()
	if rotation_delta.w < 0: rotation_delta = -rotation_delta
	var angular := rotation_delta.get_axis() * rotation_delta.get_angle() / dt if rotation_delta.get_angle() > 0.000001 else Vector3.ZERO
	var acceleration := (velocity - previous_velocity) / dt if derivative_valid else Vector3(NAN, NAN, NAN)
	previous_velocity = velocity
	derivative_valid = true
	if recording.tick % 3 != 0: return
	row.fill(NAN)
	var p: Vector3 = player.position
	var q: Quaternion = player.quaternion
	row[0] = p.x; row[1] = p.y; row[2] = p.z
	row[3] = q.x; row[4] = q.y; row[5] = q.z; row[6] = q.w
	row[7] = velocity.x; row[8] = velocity.y; row[9] = velocity.z
	row[10] = angular.x; row[11] = angular.y; row[12] = angular.z
	row[13] = acceleration.dot(-player.basis.z)
	row[14] = acceleration.dot(-player.basis.x)
	row[24] = NAN if player.flight_mode else float(not player.ground_blocked and not player.ground_placement_pending)
	row[25] = float(player.flight_mode)
	row[26] = NAN if player.flight_mode else player._lap_progress()
	if not player.flight_mode and player.driving == player.bicycle_model and row[24] == 1:
		var m = player.bicycle_model
		row[15] = m.front_tire_force.x; row[16] = m.front_tire_force.y
		row[17] = m.rear_tire_force.x; row[18] = m.rear_tire_force.y
		row[19] = m.mass_kg * m.GRAVITY * m.front_load_percent / 100.0
		row[20] = m.mass_kg * m.GRAVITY - row[19]
		row[21] = m.grip_g
		row[22] = row[19] * m.grip_g * lerpf(1, m.front_residual_percent / 100.0, m.front_slide)
		row[23] = row[20] * m.grip_g * lerpf(1, m.rear_residual_percent / 100.0, m.rear_slide)
	recording.sample(row)

func _event(kind: StringName, lap: int, seconds: float) -> void:
	if kind in [&"reset", &"mode_change", &"resume", &"focus_in"]: derivative_valid = false
	if recording:
		var index := Recording.EVENT_NAMES.find(String(kind))
		if index >= 0: recording.event(index, lap, seconds)

func _process(_dt: float) -> void:
	if recording != null and recording.active and Time.get_ticks_msec() >= next_status:
		next_status = Time.get_ticks_msec() + 1000
		_refresh("Aufnahme läuft · %.1f s · %d Zustände" % [recording.time_s, recording.state_count])
	elif recording != null and recording.full and not stop_button.disabled:
		_refresh("Puffer voll · Aufnahme beendet. Bitte speichern.")

func _refresh(message: String) -> void:
	status.text = message
	var active: bool = recording != null and recording.active
	indicator.text = "Telemetrie · Aufnahme läuft" if active else ("Telemetrie · bitte speichern" if recording != null and not saved else "")
	indicator.reset_size()
	indicator.position = Vector2(maxf(8, (get_viewport().get_visible_rect().size.x - indicator.size.x) / 2), 8)
	start_button.disabled = busy or (recording != null and not saved)
	stop_button.disabled = busy or not active
	save_button.disabled = busy or recording == null or active
	discard_button.disabled = busy or recording == null or active
	folder_button.disabled = busy or active
	if browser: browser.setUnsaved(recording != null and not saved)

func choose_folder() -> void:
	if browser:
		browser.choose()
	else:
		if not folder.is_empty(): folder_dialog.current_dir = folder
		folder_dialog.popup_centered(Vector2i(800, 500))

func save_recording() -> void:
	if recording == null or recording.active or busy: return
	if browser:
		busy = true
		_refresh("Speicherziel wird geöffnet …")
		browser.prepare()
	elif folder.is_empty() or not DirAccess.dir_exists_absolute(folder):
		save_after_folder = true
		choose_folder()
	else:
		_export()

func _export() -> void:
	busy = true
	_refresh("ZIP-Datei wird erstellt …")
	var filename: String = "telemetry-" + recording.metadata.recording_id + ".zip"
	var path := "user://telemetry-export.zip" if browser else folder.path_join(filename)
	var error := recording.write_zip(path)
	if error != OK:
		busy = false
		_refresh("Speichern fehlgeschlagen (%s). Aufnahme bleibt erhalten." % error_string(error))
		return
	if browser:
		var data := FileAccess.get_file_as_bytes(path)
		DirAccess.remove_absolute(path)
		browser.save(Marshalls.raw_to_base64(data), filename)
	else:
		saved = true
		busy = false
		_refresh("Gespeichert: " + path)

func _browser_result(args: Array) -> void:
	var kind := str(args[0])
	if kind == "ready":
		_export()
		return
	if kind in ["saved", "error", "download"]: busy = false
	if kind == "saved": saved = true
	# Download handoff cannot prove that the browser actually wrote the file.
	_refresh(str(args[1]))

func cleanup() -> void:
	if browser: browser.detach()
