extends "res://extension_system/extension.gd"
## The installer can be removed independently of the packages it installed.
var panel

func register() -> void:
	var menu = get_parent().get_node("Player/HUD/SettingsMenu")
	panel = preload("res://extensions/base_scene_installer/panel.gd").new()
	panel.name = "BaseSceneInstallerPanel"
	extension_manager.add_dialog_control(self, panel)
	panel.build(menu)

func can_remove() -> bool:
	if is_instance_valid(panel) and panel.busy:
		panel.status.text = "Bitte die Dateiauswahl oder Installation zuerst abschließen."
		return false
	return true
