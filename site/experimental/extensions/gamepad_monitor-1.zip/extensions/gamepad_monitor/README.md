# Gamepad-Monitor

## Vorfall am 16.11.2026 · Gamepad-Steuerung in Chrome ausgefallen

Während einer Web-Testfahrt (Build `84a1c64`, Xbox Wireless Controller über Bluetooth) kam der Landspeeder zum Stillstand. RT gab kein Gas mehr. Framezeit und Einstellungen reagierten weiter. Der F8-Bericht um 13:46:34 Uhr zeigte die Steuerung freigegeben, das Spiel fokussiert und die Simulation unpausiert. Triggerwerte fehlten im Bericht.

| Gegenprobe | Beobachtung |
| --- | --- |
| Windows (`joy.cpl`) | RT und LT bewegten die Achse und kehrten beim Loslassen in die Mitte zurück. |
| Chrome | Der im betroffenen Tab abgefragte RT-Wert blieb bei 0. Auch der unabhängige Gamepad-Tester erkannte nach Tastendruck kein Gerät. Ein Neustart des Controllers half nicht. |
| Firefox | Derselbe VeSKi-Build ließ sich mit demselben Gamepad fahren. |

**Einschätzung.** Die Gegenproben sprechen für eine Störung des Gamepad-Zugriffs in der laufenden Chrome-Sitzung. Eine Ursache allein in VeSKi ist unwahrscheinlich. Nach Abschluss eines ausstehenden Chrome-Updates und Neustart des Browsers funktionierte die Steuerung wieder. Der Auslöser ist offen; ob ein Neustart allein genügt hätte, wurde nicht geprüft.

### Vorgemerkt: „Störung markieren“ (F8) erweitern

Auch ein als verbunden gemeldetes Gamepad kann auf Bedienung nicht mehr reagieren. Im Störungsfall einen Stick deutlich bewegen oder eine Gamepad-Taste drücken, dann **F8 auf der Tastatur** drücken. Der Bericht soll zeigen, bis wohin diese Eingabe gelangt ist.

- **Zeitfenster:** Zwei Minuten vor F8 und fünf Sekunden danach sichern. Die bisherige Laufzeit des Monitors mit angeben, damit eine kurze Vorgeschichte einzuordnen ist.
- **Gamepad:** Für Browser und Godot jeweils das erkannte Gerät und die letzte merkliche Änderung einer beliebigen Taste oder Achse mit Zeitpunkt und Wert erfassen. Kleine Schwankungen eines ruhenden Sticks ignorieren.
- **Simulation:** Auf derselben Zeitachse die tatsächlich übernommenen Befehle erfassen, beim Fahren insbesondere Gas, Bremse und Lenkung. Ausgebliebene Simulationsschritte müssen von einem gültigen Nullwert unterscheidbar sein.

F8 genügt als Bedienung. Konstant gehaltene Eingaben sind beim Fahren normal und rechtfertigen allein keine automatische Pause.

## Akkustand unter Windows

Am 16.11.2026 meldete Windows für den per Bluetooth verbundenen Xbox Wireless Controller zunächst **67 %**, um 14:35 Uhr **66 %**. So lässt sich der von Windows gemeldete Prozentwert in PowerShell abfragen, wenn genau ein solcher Controller vorhanden ist:

```powershell
$pad = Get-PnpDevice -PresentOnly -Class Bluetooth -FriendlyName 'Xbox Wireless Controller'
Get-PnpDeviceProperty -InstanceId $pad.InstanceId -KeyName '{104EA319-6EE2-4701-BD47-8DDBF425BBE5} 2' |
    Select-Object Type, Data
```

`Data` enthält den Prozentwert als `Byte`. Die Uhrzeit bezeichnet den Abruf. Wann der Controller den Wert zuletzt aktualisiert hat und wie genau er die Restladung abbildet, ist offen.

## Native Windows-App

Der Monitor fragt den Batteriestand bei aktivierter Batteriewarnung einmal pro Minute ab. Neben der Status-LED stehen zum Vergleich beide Quellen, beispielsweise „Bluetooth: 37 % · WinRT: 10 %“. Fehlende oder ungültige Werte erscheinen als „unbekannt“. So lassen sich die Angaben während längerer Nutzung vergleichen.

Ein gültiger, eindeutig zugeordneter Bluetooth-Wert genügt auch ohne WinRT-Batteriebericht für die Bewertung der Status-LED. In den Details steht dann beispielsweise „Windows meldet 37 %“. Bis einschließlich 30 % warnt die LED vor niedrigem Akkustand.

Die Abfrage versucht zuerst die Zuordnung über das von WinRT erkannte Gamepad und dessen HID-Gerät. Fehlt diese Zuordnung bei einem Xbox-Controller, verwendet sie die oben gezeigte Bluetooth-Abfrage, sofern Godot genau ein aktives Xbox-Gamepad und Windows genau ein passendes Bluetooth-Gerät melden. Mehrdeutige Zuordnungen bleiben unbekannt. Die Abfrage läuft in einem separaten Prozess mit einem Zeitlimit von 15 Sekunden.

Liegen beide Batterieangaben vor, werden sie weiterhin verglichen. Weichen sie um mehr als 20 Prozentpunkte ab oder liegen sie auf unterschiedlichen Seiten der Warnschwelle, zeigt der Monitor „Akkustand unklar“ und in den Details beide Werte. Am 17.11.2026 meldete die gemeinsame Abfrage auf diesem Notebook **Bluetooth 37 % und WinRT 10 %**. Die unmittelbar folgende manuelle Bluetooth-Abfrage bestätigte 37 %. Welche Angabe die tatsächliche Restladung genauer beschreibt, ist offen.

Der F8-Bericht enthält beide Quellen unter `windows_reading` und den Abrufzeitpunkt unter `battery_read_utc`. Die Tests in [test_monitor.gd](tests/test_monitor.gd) prüfen unter anderem Bluetooth-Werte ohne WinRT-Bericht, Grenzwerte, ungültige Angaben und widersprüchliche Quellen.

**Web-App:** Die PowerShell-Abfrage läuft außerhalb des Browsers. Die Web-Erweiterung verwendet in [browser.js](browser.js) den Bluetooth-Dienst `battery_service`. Die Windows-Abfrage liefert einen Vergleichswert für dessen Prüfung.
