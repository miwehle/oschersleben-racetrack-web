extends Node3D

const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
## Only this session reads the local vehicle. Transport and remote presentation
## are independent. The session is a sibling of Player, so local pauses are safe.

const RemoteRider = preload("res://extensions/multiplayer/remote_rider.gd")
const DialogPanel = preload("res://ui/dialogs/dialog_panel.gd")
const INTERVAL := 1.0 / 15.0
@export var transport_script: Script
var transport: Node
var riders: Dictionary = {}
var ages: Array[float] = []
var timer := 0.0
var status_label: Label
var metrics_label: Label
var room_input: LineEdit
var nick_input: LineEdit
var link_input: LineEdit
var controls: VBoxContainer
var joined := false
var connection_state := "idle"
var entry_controls: BoxContainer
var room_controls: BoxContainer
var room_code: LineEdit
var member_label: Label
var leave_button: Button
var copy_link_button: Button
var copy_code_button: Button
var details_button: Button
var panel: DialogPanel
var navigation_toggle: Button
var room_scroll: ScrollContainer
var dialog_frame: VBoxContainer
var ui_layer: CanvasLayer
const PRESENTATION_PATH := "user://multiplayer_presentation.cfg"
var show_uncertainty := false
var ellipse_control: CheckBox

func _load_presentation() -> void:
	var config := ConfigFile.new()
	if config.load(PRESENTATION_PATH) != OK:
		return
	show_uncertainty = bool(config.get_value("view", "ellipse", false))

func _save_presentation() -> void:
	show_uncertainty = ellipse_control.button_pressed
	var config := ConfigFile.new()
	config.set_value("view", "ellipse", show_uncertainty)
	if config.save(PRESENTATION_PATH) != OK:
		push_warning("Multiplayer-Darstellung konnte nicht gespeichert werden")
	for rider in riders.values():
		_configure_rider(rider)

func _configure_rider(rider: Node) -> void:
	rider.show_uncertainty = show_uncertainty

func _build_presentation_ui() -> void:
	var options := VBoxContainer.new()
	metrics_label.visibility_changed.connect(func(): options.visible = metrics_label.visible)
	controls.add_child(options)
	options.hide()
	ellipse_control = CheckBox.new()
	ellipse_control.text = "Unsicherheitsellipse anzeigen"
	ellipse_control.tooltip_text = "Geschätzter Bereich, keine garantierte Grenze."
	ellipse_control.button_pressed = show_uncertainty
	options.add_child(ellipse_control)
	ellipse_control.toggled.connect(func(_value): _save_presentation())


func _input(event: InputEvent) -> void:
	var focused := get_viewport().gui_get_focus_owner()
	if panel == null or focused == null or not panel.is_ancestor_of(focused):
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if not panel.get_global_rect().has_point(event.position):
			get_viewport().gui_release_focus()
	elif event is InputEventScreenTouch and event.pressed:
		if not panel.get_global_rect().has_point(event.position):
			get_viewport().gui_release_focus()
	elif event is InputEventKey and event.pressed and event.keycode in [KEY_ENTER, KEY_KP_ENTER, KEY_ESCAPE]:
		get_viewport().gui_release_focus()
		get_viewport().set_input_as_handled()

func _ready() -> void:
	if not OS.has_feature("web") and not "--multiplayer-preview" in OS.get_cmdline_user_args():
		set_process(false)
		return
	_load_presentation()
	_build_ui()
	if transport_script == null:
		status_label.text = "Kein Transport eingerichtet"
		return
	transport = transport_script.new()
	add_child(transport)
	transport.event_received.connect(_on_event)
	transport.start()
	room_input.text = transport.initial_invitation()
	if not room_input.text.is_empty():
		controls.visible = true

func _build_ui() -> void:
	var canvas := CanvasLayer.new()
	ui_layer = canvas
	canvas.layer = 15
	add_child(canvas)
	panel = DialogPanel.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	panel.offset_left = -330
	panel.offset_right = -12
	panel.offset_top = 102
	canvas.add_child(panel)
	var toggle = preload("res://ui/controls/navigation_button.gd").new()
	toggle.icon = preload("res://ui/icons/multiplayer_icon.svg")
	toggle.tooltip_text = "Gemeinsam fahren"
	toggle.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	toggle.position = Vector2(-94, 18)
	canvas.add_child(toggle)
	navigation_toggle = toggle
	var column := panel.build("GEMEINSAM FAHREN", func():
		controls.hide()
		get_viewport().gui_release_focus())
	panel.add_header_separator()
	room_scroll = panel.scroll
	dialog_frame = panel.frame
	controls = VBoxContainer.new()
	controls.add_theme_constant_override("separation", 12)
	controls.visible = false
	column.add_child(controls)
	controls.visibility_changed.connect(func(): panel.visible = controls.visible)
	panel.hide()
	toggle.activated.connect(func():
		controls.visible = not controls.visible
		get_viewport().gui_release_focus())
	status_label = _label("Nicht verbunden")
	controls.add_child(status_label)
	entry_controls = BoxContainer.new()
	entry_controls.add_theme_constant_override("separation", 12)
	controls.add_child(entry_controls)
	var create_column := _column(entry_controls)
	var join_column := _column(entry_controls)
	create_column.add_child(_label("Dein Name"))
	nick_input = _input_field("Dein Name")
	nick_input.max_length = 24
	create_column.add_child(nick_input)
	_action(create_column, "Neuen Raum erstellen", _create_room)
	join_column.add_child(_label("Raumcode oder Einladungslink"))
	room_input = _input_field("Raumcode oder Einladungslink")
	join_column.add_child(room_input)
	_action(join_column, "Beitreten", _join_room)
	room_controls = BoxContainer.new()
	room_controls.add_theme_constant_override("separation", 12)
	controls.add_child(room_controls)
	var invitation_column := _column(room_controls)
	var members_column := _column(room_controls)
	invitation_column.add_child(_label("Raumcode"))
	var code_row := HBoxContainer.new()
	invitation_column.add_child(code_row)
	room_code = _input_field("")
	room_code.editable = false
	room_code.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	code_row.add_child(room_code)
	var copy_code = preload("res://ui/controls/navigation_button.gd").new()
	copy_code.icon = preload("res://ui/icons/copy_icon.svg")
	copy_code.tooltip_text = "Raumcode kopieren"
	copy_code.activated.connect(func(): DisplayServer.clipboard_set(room_code.text))
	code_row.add_child(copy_code)
	copy_code_button = copy_code
	link_input = _input_field("Einladungslink")
	link_input.editable = false
	invitation_column.add_child(link_input)
	copy_link_button = _action(invitation_column, "Einladung kopieren", func(): DisplayServer.clipboard_set(link_input.text))
	member_label = _label("")
	members_column.add_child(member_label)
	leave_button = _action(members_column, "Raum verlassen", _leave_room)
	members_column.add_child(_label("X schließt nur dieses Fenster. Du bleibst im Raum."))
	details_button = _action(controls, "Darstellung & Verbindungsdetails", func(): metrics_label.visible = not metrics_label.visible)
	details_button.toggle_mode = true
	metrics_label = _label("")
	metrics_label.add_theme_color_override("font_color", Color(0.58, 0.72, 0.82))
	metrics_label.add_theme_font_size_override("font_size", 18)
	metrics_label.hide()
	controls.add_child(metrics_label)
	_build_presentation_ui()
	_refresh_connection_ui()
	var ui_theme := Theme.new()
	ui_theme.default_font_size = 20
	panel.theme = ui_theme
	panel.minimum_size_changed.connect(_place_ui.call_deferred)
	controls.minimum_size_changed.connect(_place_ui.call_deferred)
	controls.visibility_changed.connect(_place_ui.call_deferred)
	UiLayout.changed.connect(_place_ui)
	_place_ui.call_deferred()

func _place_ui() -> void:
	if not is_inside_tree():
		return
	var factor := UiLayout.factor
	navigation_toggle.scale = Vector2.ONE * factor
	navigation_toggle.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	navigation_toggle.position = Vector2(UiLayout.extent.x - 60, 12) * factor
	panel.scale = Vector2.ONE * factor
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	var width := minf(780, UiLayout.extent.x - 24)
	# Use the tablet width to avoid a long, narrow stack. Phones retain a single
	# scrollable column; expanded details or many riders can still overflow.
	var stacked := width < 640 or UiLayout.extent.y < 440
	entry_controls.vertical = stacked
	room_controls.vertical = stacked
	var content_height := controls.get_combined_minimum_size().y
	var chrome_height := dialog_frame.get_combined_minimum_size().y + panel.get_theme_stylebox("panel").get_minimum_size().y
	panel.size = Vector2(width, minf(content_height + chrome_height, UiLayout.extent.y - 24))
	panel.position = (UiLayout.extent - panel.size) * factor * 0.5


func _column(parent: Control) -> VBoxContainer:
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)
	parent.add_child(column)
	return column

func _label(text: String) -> Label:
	var label := Label.new()
	label.text = text
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return label

func _input_field(placeholder: String) -> LineEdit:
	var field := LineEdit.new()
	field.placeholder_text = placeholder
	field.custom_minimum_size.y = 48
	return field

func _action(parent: Control, text: String, action: Callable) -> Button:
	var button := Button.new()
	button.text = text
	button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	button.custom_minimum_size.y = 48
	button.pressed.connect(action)
	parent.add_child(button)
	return button

func _refresh_connection_ui() -> void:
	entry_controls.visible = not joined
	room_controls.visible = joined
	leave_button.text = "Verbindung abbrechen" if connection_state == "connecting" else "Raum verlassen"
	copy_link_button.disabled = link_input.text.is_empty()
	copy_code_button.disabled = room_code.text.is_empty()
	_refresh_members()

func _refresh_members() -> void:
	var names: Array[String] = []
	for rider in riders.values():
		if rider.visible:
			var age: float = rider.data_age()
			var freshness := "Vorhersagegrenze erreicht" if age > RemoteRider.PREDICTION_LIMIT else "aktuell"
			names.append("%s · ≈ %.0f ms alt · Abstand %.0f ms · %s" % [rider.label.text, age * 1000, rider.receive_interval * 1000, freshness])
	names.sort()
	var own_name := nick_input.text.strip_edges()
	if own_name.is_empty():
		own_name = "Fahrer"
	member_label.text = "Du: %s\nMitfahrende (%d):\n%s" % [own_name, names.size(), "Noch niemand im Raum" if names.is_empty() else "\n".join(names)]

func _create_room() -> void:
	if transport == null or not transport.is_available():
		return
	room_input.text = transport.create_room_code()
	_join_room()

func _join_room() -> void:
	if transport == null or not transport.is_available():
		return
	link_input.text = ""
	room_code.text = ""
	joined = true
	connection_state = "connecting"
	_refresh_connection_ui()
	transport.join(room_input.text, nick_input.text)
	get_viewport().gui_release_focus()

func _leave_room() -> void:
	joined = false
	if transport != null:
		transport.leave()
	link_input.text = ""
	room_code.text = ""
	connection_state = "idle"
	_refresh_connection_ui()
	get_viewport().gui_release_focus()

func _on_event(event: Dictionary) -> void:
	match event.get("type", ""):
		"connection":
			connection_state = str(event.state)
			joined = connection_state != "idle"
			_refresh_connection_ui()
		"status":
			status_label.text = str(event.message)
		"room":
			link_input.text = str(event.link)
			room_code.text = str(event.room)
			_refresh_connection_ui()
		"clear":
			for rider in riders.values():
				rider.queue_free()
			riders.clear()
			ages.clear()
			_refresh_members()
		"remove":
			if riders.has(event.id):
				riders[event.id].queue_free()
				riders.erase(event.id)
				_refresh_members()
		"state":
			if not _valid_state(event.get("state")):
				return
			if not riders.has(event.id):
				var rider := RemoteRider.new()
				rider.name = str(event.id)
				_configure_rider(rider)
				add_child(rider)
				riders[event.id] = rider
			riders[event.id].accept(event.state, float(event.age) / 1000.0)
			ages.append(float(event.age))
			if ages.size() > 300:
				ages.pop_front()

static func _valid_state(value: Variant) -> bool:
	if not value is Dictionary:
		return false
	for key in ["x", "y", "z", "yaw", "speed", "turn", "t", "revision", "vx", "vy", "vz"]:
		if not value.has(key) or not (value[key] is float or value[key] is int) or not is_finite(float(value[key])):
			return false
	for key in ["vx", "vy", "vz"]:
		if absf(float(value[key])) > 100:
			return false
	return value.get("paused") is bool and value.get("crashed") is bool and value.get("nick") is String

func _process(delta: float) -> void:
	var vehicle := get_parent().get_node("Player")
	if ui_layer != null:
		ui_layer.visible = not vehicle.simulation_paused
	if transport == null or not transport.is_available() or not joined:
		return
	timer += delta
	if timer < INTERVAL:
		return
	timer = 0.0
	transport.send_state(vehicle.multiplayer_state())
	var stats: Dictionary = transport.statistics()
	var visible_count := 0
	for rider in riders.values():
		if rider.visible:
			visible_count += 1
	var summary := "%d Mitfahrer | Nutzdaten\nGesendet: %.1f KB\nEmpfangen: %.1f KB" % [visible_count, stats.sent / 1000.0, stats.received / 1000.0]
	if not ages.is_empty():
		var sorted := ages.duplicate()
		sorted.sort()
		summary += "\nDatenalter ≈ %.0f ms Median / %.0f ms P95" % [sorted[sorted.size() / 2], sorted[mini(sorted.size() - 1, int(sorted.size() * 0.95))]]
	metrics_label.text = UiNumbers.display(summary)
	_refresh_members()

func _exit_tree() -> void:
	if UiLayout.changed.is_connected(_place_ui):
		UiLayout.changed.disconnect(_place_ui)
	if is_instance_valid(transport):
		if transport.event_received.is_connected(_on_event):
			transport.event_received.disconnect(_on_event)
		if transport.has_method("stop"):
			transport.stop()
		else:
			transport.leave()
