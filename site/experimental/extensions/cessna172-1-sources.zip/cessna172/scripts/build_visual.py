"""Rebuild the pinned C172P exterior without downloading or changing its sources."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

PROJECT = Path(__file__).resolve().parents[1]
WORK = PROJECT.parent / "work/c172p-visual"
ASSETS = PROJECT / "godot/extensions/cessna172/visual"

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--blender", required=True, type=Path)
    args = parser.parse_args()
    archive = PROJECT / "visual-source.zip"
    manifest = json.loads((ASSETS / "provenance.json").read_text())
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest["archive_sha256"]
    source = WORK / "source"
    with zipfile.ZipFile(archive) as z:
        for entry in z.namelist():
            assert (source / entry).resolve().is_relative_to(source.resolve())
        z.extractall(source)
    subprocess.run([str(args.blender.resolve()), "-b", "--python", str(PROJECT / "scripts/convert_visual.py"), "--", str(source), str(WORK)], check=True)
    for name in ["c172p.glb", "rig.json"]:
        shutil.copyfile(WORK / name, ASSETS / name)
