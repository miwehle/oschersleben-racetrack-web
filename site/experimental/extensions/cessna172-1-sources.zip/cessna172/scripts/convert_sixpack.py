"""Convert the pinned C172P instrument meshes for one orthographic HUD viewport.
Run with Blender: blender -b --python convert_sixpack.py
The original AC3D/XML/PNG files and GPL license are retained in sixpack-source.zip.
"""
import json
import math
import shlex
import zipfile
import hashlib
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
import bpy
from mathutils import Vector

PROJECT = Path(__file__).resolve().parents[1]
OUTPUT = PROJECT / "godot/extensions/cessna172/sixpack"
NAMES = ["asi", "AI", "alt", "tc", "hi", "VSI", "RPM"]
# Only moving parts of the six flight instruments; knobs remain at their defaults.
PARTS = {"asi": ["Needle"], "AI": ["Pitch", "Roll"],
         "alt": ["Needle100", "Needle1000", "Needle10000"],
         "tc": ["Airplane", "Ball"], "hi": ["Face"], "VSI": ["PointerCentre", "PointerTip"], "RPM": ["PointerCentre", "PointerTip"]}

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from ac_reader import read_ac

def ac(v): return Vector((-v[2], -v[0], v[1]))  # Blender right / forward / up

def fg(v): return Vector((v[1], -v[0], v[2]))

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
OUTPUT.mkdir(parents=True, exist_ok=True)
rig = {}
with tempfile.TemporaryDirectory() as directory:
    source = Path(directory)
    with zipfile.ZipFile(PROJECT / "sixpack-source.zip") as archive: archive.extractall(source)
    for instrument in NAMES:
        folder = source / "Models/Interior/Panel/Instruments" / instrument
        materials, objects = read_ac(folder / (instrument + ".ac"))
        xml = ET.parse(folder / (instrument + ".xml")).getroot()
        rotations = {}
        for animation in xml.findall("animation"):
            if animation.findtext("type") != "rotate": continue
            for name in animation.findall("object-name"):
                if name.text in PARTS[instrument]: rotations[name.text] = animation
        # Align instrument centres to a regular 4 x 2 grid (all original gauges are 80 mm).
        centre = [float(next(iter(rotations.values())).findtext("center/" + c + "-m")) for c in "xyz"]
        centre[0] = -0.38
        index = NAMES.index(instrument)
        offset = Vector(((index % 4 - 1.5) * .09, 0, (.5 - index // 4) * .09)) - fg(centre)
        cache = {}
        for obj in objects:
            name = obj["name"]
            if not obj["vertices"] or name in ["HdgBug", "RollRefGlass"]: continue
            animation = rotations.get(name)
            pivot = fg([float(animation.findtext("center/"+c+"-m")) for c in "xyz"]) if animation is not None else Vector()
            mesh = bpy.data.meshes.new(instrument + "_" + name)
            mesh.from_pydata([ac(v) - pivot for v in obj["vertices"]], [], [[int(r[0]) for r in refs] for _, refs in obj["faces"]])
            mesh.update()
            uv = mesh.uv_layers.new(name="UVMap")
            slots = {}
            for polygon, (material, refs) in zip(mesh.polygons, obj["faces"]):
                key = (material, obj["texture"])
                if key not in cache:
                    label, color, alpha = materials[material]
                    m = bpy.data.materials.new(instrument + "_" + label)
                    m.use_nodes = True
                    shader = m.node_tree.nodes.get("Principled BSDF")
                    shader.inputs["Base Color"].default_value = (*color, alpha)
                    if obj["texture"]:
                        tex = m.node_tree.nodes.new("ShaderNodeTexImage")
                        tex.image = bpy.data.images.load(str(folder / obj["texture"]), check_existing=True)
                        m.node_tree.links.new(tex.outputs["Color"], shader.inputs["Base Color"])
                        if instrument in ("tc", "hi"):
                            m.node_tree.links.new(tex.outputs["Alpha"], shader.inputs["Alpha"])
                    m.use_backface_culling = False
                    cache[key] = m
                if key not in slots:
                    slots[key] = len(mesh.materials); mesh.materials.append(cache[key])
                polygon.material_index = slots[key]
                for loop, ref in zip(polygon.loop_indices, refs):
                    u, v = ref[1]*obj["texrep"][0], ref[2]*obj["texrep"][1]
                    # Source Kollsman window at standard pressure, 29.92 inHg.
                    if instrument == "alt" and name == "inhg":
                        angle = math.radians(-202.0)
                        u, v = .25+(u-.25)*math.cos(angle)-(v-.25)*math.sin(angle), .25+(u-.25)*math.sin(angle)+(v-.25)*math.cos(angle)
                    uv.data[loop].uv = u, v
            node = bpy.data.objects.new(instrument + "_" + name, mesh)
            bpy.context.collection.objects.link(node)
            node.location = pivot + offset
            if instrument == "tc" and name == "Flag": node.location.z += .004
            if animation is not None:
                table = [[float(e.findtext("ind")), float(e.findtext("dep"))] for e in animation.findall("interpolation/entry")]
                rig[node.name] = {"factor": float(animation.findtext("factor", "1")), "table": table}
    # The cockpit panel normally masks the square texture cards behind the round bezels.
    # Retain that mask in the standalone HUD; knobs in front remain visible.
    mask = bpy.data.materials.new("Panel_mask")
    mask.use_nodes = True
    mask.node_tree.nodes.get("Principled BSDF").inputs["Base Color"].default_value = (0.012, 0.016, 0.018, 1)
    for index in range(len(NAMES)):
        centre = Vector(((index % 4 - 1.5) * .09, -.012, (.5 - index // 4) * .09))
        vertices, faces = [], []
        for segment in range(64):
            a = segment * math.tau / 64
            x, y = math.cos(a), math.sin(a)
            for r in [.0398, .045 / max(abs(x), abs(y))]: vertices.append(centre + Vector((r*x, 0, r*y)))
            n = segment * 2; m = ((segment + 1) % 64) * 2
            faces.append([n, n+1, m+1, m])
        mesh = bpy.data.meshes.new("Panel_mask")
        mesh.from_pydata(vertices, [], faces); mesh.materials.append(mask)
        node = bpy.data.objects.new("Panel_mask_%d" % index, mesh)
        bpy.context.collection.objects.link(node)
    bpy.ops.export_scene.gltf(filepath=str(OUTPUT / "instruments.glb"), export_format="GLB", export_yup=True, export_animations=False)
    (OUTPUT / "LICENSE").write_bytes((source / "LICENSE").read_bytes())
(OUTPUT / "rig.json").write_text(json.dumps(rig, indent=2)+"\n", encoding="utf-8")
(OUTPUT / "provenance.json").write_text(json.dumps({
    "source": "https://github.com/c172p-team/c172p", "revision": "66ae50bd092ab2487caea3f53fbee7640920cdb9",
    "license": "GPL-2.0", "archive_sha256": hashlib.sha256((PROJECT / "sixpack-source.zip").read_bytes()).hexdigest(),
    "conversion": "Original instrument geometry/UVs; regular grid, orthographic unlit HUD; standard-pressure window; heading bug and reflective glass omitted."
}, indent=2)+"\n", encoding="utf-8")
print("SIXPACK", (OUTPUT / "instruments.glb").stat().st_size, "bytes")
