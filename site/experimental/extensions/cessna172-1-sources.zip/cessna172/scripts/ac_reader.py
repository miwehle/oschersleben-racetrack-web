"""Reader for the AC3D subset used by the pinned C172P cockpit assets."""
import shlex

def read_ac(path):
    lines = iter(path.read_text(encoding="utf-8").splitlines())
    assert next(lines) == "AC3Db"
    materials, objects = [], []
    for line in lines:
        p = shlex.split(line)
        if not p: continue
        key, args = p[0], p[1:]
        if key == "MATERIAL": materials.append((args[0], list(map(float, args[2:5])), 1-float(args[-1])))
        elif key == "OBJECT":
            obj = dict(name="", vertices=[], faces=[], texture="", texrep=[1, 1]); objects.append(obj)
        elif key == "name": obj["name"] = args[0]
        elif key == "texture": obj["texture"] = args[0]
        elif key == "texrep": obj["texrep"] = list(map(float, args))
        elif key == "data": assert len(next(lines).encode()) == int(args[0])
        elif key == "numvert": obj["vertices"] = [list(map(float, next(lines).split())) for _ in range(int(args[0]))]
        elif key == "numsurf":
            for _ in range(int(args[0])):
                flags = int(next(lines).split()[1], 0)
                material = int(next(lines).split()[1])
                refs = [list(map(float, next(lines).split())) for _ in range(int(next(lines).split()[1]))]
                assert flags & 15 == 0
                obj["faces"].append((material, refs))
        elif key not in ("kids", "crease"): raise ValueError(line)
    return materials, objects

