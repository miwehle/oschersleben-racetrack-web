"""Export the original C172P trim wheel. Run with Blender --background --python."""
import bpy, shlex, json, hashlib, tempfile, zipfile, sys
from pathlib import Path
from mathutils import Vector
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ac_reader import read_ac
project=Path(__file__).resolve().parents[1]
mixture = '--mixture' in sys.argv
output=project/('godot/extensions/cessna172/mixture' if mixture else 'godot/extensions/cessna172/trim')
output.mkdir(exist_ok=True)
temporary=tempfile.TemporaryDirectory()
folder=Path(temporary.name)
with zipfile.ZipFile(project/'trim-source.zip') as archive: archive.extractall(folder)
materials,objects=read_ac(folder/'c172p-interior.ac')
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for obj in objects:
 if obj['name'] not in (['Mixture', 'MixtureMount'] if mixture else ['TrimWheel']): continue
 vertices=[Vector((v[0] + .365, -v[2] - .0915, v[1] + .2065)) if mixture else Vector((-v[2],-v[0],v[1])) for v in obj['vertices']]
 centre=Vector(tuple((min(v[i] for v in vertices)+max(v[i] for v in vertices))/2 for i in range(3)))
 print('WHEEL_SIZE',tuple(max(v[i] for v in vertices)-min(v[i] for v in vertices) for i in range(3)))
 mesh=bpy.data.meshes.new(obj['name']);mesh.from_pydata([v if mixture else v-centre for v in vertices],[],[[int(r[0]) for r in refs] for _,refs in obj['faces']]);mesh.update()
 uv=mesh.uv_layers.new(name='UVMap');slots={}
 for poly,(mi,refs) in zip(mesh.polygons,obj['faces']):
  if mi not in slots:
   name,color,alpha=materials[mi];m=bpy.data.materials.new(name);m.use_nodes=True
   shader=m.node_tree.nodes.get('Principled BSDF');shader.inputs['Base Color'].default_value=(*color,1);shader.inputs['Roughness'].default_value=.6
   texture=m.node_tree.nodes.new('ShaderNodeTexImage');texture.image=bpy.data.images.load(str(folder/obj['texture']),check_existing=True);m.node_tree.links.new(texture.outputs['Color'],shader.inputs['Base Color'])
   slots[mi]=len(mesh.materials);mesh.materials.append(m)
  poly.material_index=slots[mi];poly.use_smooth=True
  for li,r in zip(poly.loop_indices,refs): uv.data[li].uv=(r[1],r[2])
 wheel=bpy.data.objects.new(obj['name'],mesh);bpy.context.collection.objects.link(wheel)

bpy.ops.export_scene.gltf(filepath=str(output/('knob.glb' if mixture else 'wheel.glb')),export_format='GLB',export_yup=True,export_animations=False)
(output/'LICENSE').write_bytes((folder/'LICENSE').read_bytes())
(output/'provenance.json').write_text(json.dumps({"source":"https://github.com/c172p-team/c172p","revision":"66ae50bd092ab2487caea3f53fbee7640920cdb9","license":"GPL-2.0","archive_sha256":hashlib.sha256((project/'trim-source.zip').read_bytes()).hexdigest(),"conversion": "Original Mixture and MixtureMount meshes and UVs; original proportions retained." if mixture else "Original TrimWheel mesh and UVs from c172p-interior.ac, panel_parts.png; centred on axle; original proportions retained."},indent=2)+'\n',encoding='utf-8')
temporary.cleanup()
