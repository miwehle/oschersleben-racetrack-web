"""Run the same Godot runtime fixture on Windows and in Edge, then compare results."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
from build_runtime import PROJECT, WORK

CORE = PROJECT.parent.parent / "vehicle-simulation-kit"


def run(args, log_name):
    try:
        result = subprocess.run(list(map(str, args)), capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=180)
    except subprocess.TimeoutExpired as error:
        (WORK / log_name).write_bytes((error.stdout or b"") + (error.stderr or b""))
        raise
    (WORK / log_name).write_text(result.stdout + result.stderr, encoding="utf-8")
    if result.returncode or "SCRIPT ERROR:" in result.stdout + result.stderr:
        raise RuntimeError(f"Failed; see {WORK / log_name}")


def compare():
    native = json.loads((WORK / "native.json").read_text())
    web = json.loads((WORK / "web.json").read_text())
    assert not native["failures"] and not web["failures"]
    assert len(native["samples"]) == len(web["samples"]) == 31
    # Sub-metre position, small fraction of a degree; tolerances are below visible flight differences.
    limits = {"latitude_deg": 0.000001, "longitude_deg": 0.000001,
              "altitude_m": 0.1, "airspeed_mps": 0.02,
              "roll_rad": 0.0001, "pitch_rad": 0.0001, "yaw_rad": 0.0001, "time_s": 0.00000001}
    maxima = {key: max(abs(a[key] - b[key]) for a, b in zip(native["samples"], web["samples"])) for key in limits}
    failures = [key for key in limits if maxima[key] > limits[key]]
    assert all(abs(a-b) < 0.00001 for a,b in zip(native['trim'],web['trim'])), "Trim differs"
    report = {"max_abs_difference": maxima, "limits": limits, "failed_fields": failures,
              "native_mean_step_us": native["mean_step_us"], "web_mean_step_us": web["mean_step_us"]}
    (WORK / "comparison.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    assert not failures, "Native/WASM comparison failed"
    print("PASS: native + Web ZIP loading, 40s manoeuvres, pause, reset, independent instances and reload")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--godot", type=Path, default=CORE / "tools/godot/Godot_v4.7.2-stable_win64_console.exe")
    parser.add_argument("--node", type=Path, default=CORE / "tools/node-v24.22.2-win-x64/node.exe")
    parser.add_argument("--native-only", action="store_true")
    args = parser.parse_args()
    project = WORK / "probe"
    project.mkdir(parents=True, exist_ok=True)
    for name in ["main.gd", "main.tscn", "project.godot", "export_presets.cfg"]:
        shutil.copyfile(PROJECT / "runtime_probe" / name, project / name)
    run([args.godot, "--headless", "--path", project, "--", "--package=" + str(WORK / "cessna172-runtime.zip"), "--report=" + str(WORK / "native.json")], "native.log")
    print("Native runtime probe PASS", flush=True)
    if not args.native_only:
        web = WORK / "web"
        web.mkdir(exist_ok=True)
        run([args.godot, "--headless", "--path", project, "--editor", "--import"], "import.log")
        run([args.godot, "--headless", "--path", project, "--export-release", "Web", web / "index.html"], "export.log")
        shutil.copyfile(WORK / "cessna172-runtime.zip", web / "cessna172-runtime.zip")
        run([args.node, PROJECT / "runtime_probe/browser.cjs", web], "browser-run.log")
        compare()
