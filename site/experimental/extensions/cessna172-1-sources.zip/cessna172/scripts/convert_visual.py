"""Blender background converter for the pinned c172p-team AC3D model (GPL-2.0).
Run: blender -b --python convert_visual.py -- SOURCE_DIR OUTPUT_DIR
Only the AC3D features used by this pinned source are accepted.
"""
import bpy
import json
import math
import shlex
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from mathutils import Vector

source, output = (Path(p).resolve() for p in sys.argv[sys.argv.index('--') + 1:])
output.mkdir(parents=True, exist_ok=True)
def read_ac(path):
    lines = iter(path.read_text().splitlines())
    assert next(lines) == 'AC3Db'
    materials = []
    objects = []
    current = None
    for line in lines:
        parts = shlex.split(line)
        if not parts: continue
        key, args = parts[0], parts[1:]
        if key == 'MATERIAL':
            materials.append(dict(name=args[0], rgb=list(map(float,args[2:5])), alpha=1-float(args[-1])))
        elif key == 'OBJECT':
            current = dict(kind=args[0], name='', vertices=[], faces=[], texture='', texrep=[1,1])
            objects.append(current)
        elif key == 'name': current['name'] = args[0]
        elif key == 'data':
            # Exporter object metadata is one line in this source.
            assert len(next(lines).encode()) == int(args[0])
        elif key == 'texture': current['texture'] = args[0]
        elif key == 'texrep': current['texrep'] = list(map(float,args))
        elif key == 'numvert': current['vertices'] = [list(map(float,next(lines).split())) for _ in range(int(args[0]))]
        elif key == 'numsurf':
            for _ in range(int(args[0])):
                flags = int(next(lines).split()[1], 0)
                material = int(next(lines).split()[1])
                count = int(next(lines).split()[1])
                refs = [list(map(float,next(lines).split())) for _ in range(count)]
                assert flags & 15 == 0, 'Only polygons expected'
                current['faces'].append((flags,material,refs))
        elif key in ('kids','crease'): pass
        else: raise ValueError('Unsupported AC3D field: '+line)

    return materials, objects

materials, objects = read_ac(source / "Models/c172-common.ac")

# Use the original cabin geometry, with plain finishes for close cockpit views.
# Painted seams in the exterior atlas are too coarse at this viewing distance.
interior_finishes = {
    "lining": ((0.42, 0.40, 0.36), {"chassis", "doorint_left", "doorint_right",
        "windowframeleftint", "windowframerightint", "baggagedoorinterior"}),
    "floor": ((0.045, 0.05, 0.055), {"carpet", "Firewall"}),
    "seats": ((0.12, 0.14, 0.16), {"pilotseat_left", "pilotseat_right", "backseat_left"}),
}
_, interior = read_ac(source / "Models/c172p-interior.ac")
for finish, (rgb, names) in interior_finishes.items():
    index = len(materials)
    materials.append(dict(name="Cabin_" + finish, rgb=rgb, alpha=1))
    selected = [obj for obj in interior if obj["name"] in names]
    assert {obj["name"] for obj in selected} == names
    for obj in selected:
        obj["texture"] = ""
        obj["faces"] = [(flags, index, refs) for flags, _, refs in obj["faces"]]
    objects.extend(selected)

# AC3D: X aft, Y up, Z left. Blender: X right, Y forward, Z up.
def ac(v): return Vector((-v[2],-v[0],v[1]))
def fg(v): return Vector((v[1],-v[0],v[2]))
def godot(v): return [v[1],v[2],v[0]]

xml=ET.parse(source/'Models/c172p.xml').getroot()
animated = {}
rig = {}
for animation in xml.findall('animation'):
    names=[n.text for n in animation.findall('object-name')]
    first=names[0] if names else ''
    if first not in ['leftaileron','rightaileron','elevatorleft','elevatorright','rudder_1','Propeller']: continue
    if animation.findtext('type') not in ('rotate','spin'): continue
    axis=animation.find('axis')
    if axis.find('x1-m') is not None:
        a=[float(axis.findtext(c+'1-m')) for c in 'xyz']
        b=[float(axis.findtext(c+'2-m')) for c in 'xyz']
        direction=(Vector(b)-Vector(a)).normalized()
    else:
        a=[float(animation.findtext('center/'+c+'-m')) for c in 'xyz']
        direction=Vector([float(axis.findtext(c)) for c in 'xyz']).normalized()
    rig[first]={'center':godot(a), 'axis':godot(direction)}
    for name in names: animated[name]=(first,fg(a))
# The existing blurred disk shares the propeller axis.
animated['Propeller.Fast']=animated['Propeller']

bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
cache={}
def material(index,texture):
    item=materials[index]
    key=(index,texture)
    if key in cache: return cache[key]
    m=bpy.data.materials.new(item['name']+'_'+Path(texture).stem)
    m.use_nodes=True
    shader=m.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Metallic'].default_value=0
    shader.inputs['Roughness'].default_value=0.6
    shader.inputs['Base Color'].default_value=(*item['rgb'],1)
    alpha=item['alpha']
    if texture:
        tex=m.node_tree.nodes.new('ShaderNodeTexImage')
        tex.image=bpy.data.images.load(str(source/'Models'/texture),check_existing=True)
        m.node_tree.links.new(tex.outputs['Color'],shader.inputs['Base Color'])
        if texture=='prop.png':
            multiply=m.node_tree.nodes.new('ShaderNodeMath')
            multiply.operation='MULTIPLY';multiply.inputs[1].default_value=0.25
            m.node_tree.links.new(tex.outputs['Alpha'],multiply.inputs[0])
            m.node_tree.links.new(multiply.outputs[0],shader.inputs['Alpha'])
            alpha=0.25
    if 'glass' in item['name'].lower() or texture=='glass-alpha.png':
        shader.inputs['Base Color'].default_value=(0.38,0.55,0.62,1)
        alpha=0.22
    if texture!='prop.png': shader.inputs['Alpha'].default_value=alpha
    if alpha<1: m.surface_render_method='DITHERED'
    m.use_backface_culling=False
    cache[key]=m
    return m

skip={'PropellerCowlPlugs','BeaconOffX','courtesyon-l','courtesyon-r','landinglight','taxilight','sun_and_view_blocker'}
rig_nodes={}
static=[]
for obj in objects:
    name=obj['name']
    if not obj['vertices'] or name in skip or 'hotspot' in name.lower() or name.startswith('TieDown'): continue
    # Glass is represented by its exterior surface, not two coincident layers.
    if 'glas_' in name or name.endswith('window_interior'): continue
    pivot=animated.get(name,('',Vector()))[1]
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata([ac(v)-pivot for v in obj['vertices']],[],[[int(r[0]) for r in f[2]] for f in obj['faces']])
    mesh.update()
    uv=mesh.uv_layers.new(name='UVMap')
    slots={}
    for poly,face in zip(mesh.polygons,obj['faces']):
        flags,index,refs=face
        if index not in slots:
            slots[index]=len(mesh.materials);mesh.materials.append(material(index,obj['texture']))
        poly.material_index=slots[index]
        poly.use_smooth=bool(flags & 16)
        for loop,ref in zip(poly.loop_indices,refs): uv.data[loop].uv=(ref[1]*obj['texrep'][0],ref[2]*obj['texrep'][1])
    mesh.validate(clean_customdata=False)
    mesh.set_sharp_from_angle(angle=math.radians(50))
    node=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(node)
    if name in animated:
        key=animated[name][0]
        if key not in rig_nodes:
            parent=bpy.data.objects.new(key+'_pivot',None);bpy.context.collection.objects.link(parent)
            parent.location=pivot;rig_nodes[key]=parent
        node.parent=rig_nodes[key]
    else: static.append(node)
# Merge static geometry to avoid one draw submission per tiny part.
bpy.ops.object.select_all(action='DESELECT')
for node in static: node.select_set(True)
bpy.context.view_layer.objects.active=static[0];bpy.ops.object.join();static[0].name='Airframe'
# Embed textures for a single portable GLB, requiring no Godot import cache.
bpy.ops.wm.save_as_mainfile(filepath=str(output/'c172p.blend'))
bpy.ops.export_scene.gltf(filepath=str(output/'c172p.glb'),export_format='GLB',export_yup=True,export_animations=False,export_extras=False)
(output/'rig.json').write_text(json.dumps(rig,indent=2)+'\n')
triangles=sum(len(p.vertices)-2 for ob in bpy.context.scene.objects if ob.type=='MESH' for p in ob.data.polygons)
print('C172P_VISUAL',json.dumps({'triangles':triangles,'objects':len(bpy.context.scene.objects),'bytes':(output/'c172p.glb').stat().st_size}))

