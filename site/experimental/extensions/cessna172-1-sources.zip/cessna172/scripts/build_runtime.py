"""Build the Windows JSBSim GDExtension and the desktop/browser extension ZIP.
Generated tools, sources, binaries and reports stay in veski-extensions/work/.
"""
import argparse
import base64
import hashlib
import json
import os
import shutil
from pathlib import Path
import subprocess
import sys
import tarfile
import urllib.request
import zipfile

PROJECT = Path(__file__).resolve().parents[1]
WORK = PROJECT.parent / "work/cessna-runtime"
RES = "extensions/cessna172/runtime"
SOURCES = {
    "llvm": ("https://github.com/mstorsjo/llvm-mingw/releases/download/20251104/llvm-mingw-20251104-ucrt-x86_64.zip", "171b298f46fa4b5653dc7b01cc5e709caca645991be8e1b0724466c4a282a1ac"),
    "jsbsim": ("https://codeload.github.com/JSBSim-Team/jsbsim/zip/refs/tags/v1.2.4", "17cc37d7ebb308a3a80424a21a8b29ad5c2ac42a524568ff576a4b2d19dc73e4"),
    "godot-cpp": ("https://codeload.github.com/godotengine/godot-cpp/zip/refs/tags/godot-4.4-stable", "0d64106ce1e09547f6054743b6fb9db903f23f27d1e669c7556a0a02669bd9ba"),
}
if sys.platform != "win32":
    SOURCES["llvm"] = ("https://github.com/mstorsjo/llvm-mingw/releases/download/20251104/llvm-mingw-20251104-ucrt-ubuntu-22.04-x86_64.tar.xz", "3aed6fa47be909884cb3e5634d6b7254604d7104832d6312f8435fb23d5a9bab")
SDK_INTEGRITY = "sdTCq4ymQqmwTbMzpm0MMkXl2OHRaVb9tSP+F/0fAm2+AptV3YXUmA7NIpcCPsfN4S6EPNDvztzTz2rE5Rnvrw=="


def sources():
    WORK.mkdir(parents=True, exist_ok=True)
    paths = {}
    for name, (url, digest) in SOURCES.items():
        archive = WORK / (name + (".tar.xz" if url.endswith(".tar.xz") else ".zip"))
        if not archive.exists():
            print("Download", name, flush=True)
            urllib.request.urlretrieve(url, archive)
        if hashlib.sha256(archive.read_bytes()).hexdigest() != digest:
            raise RuntimeError(f"Checksum mismatch: {archive}")
        dest = WORK / name
        if not dest.exists():
            if archive.suffix == ".xz":
                with tarfile.open(archive) as t: t.extractall(dest, filter="data")
            else:
                with zipfile.ZipFile(archive) as z: z.extractall(dest)
        paths[name] = next(dest.iterdir())
    archive = WORK / "jsbsim-wasm.tgz"
    if not archive.exists():
        urllib.request.urlretrieve("https://registry.npmjs.org/@0x62/jsbsim-wasm/-/jsbsim-wasm-1.2.4-beta.4.tgz", archive)
    if base64.b64encode(hashlib.sha512(archive.read_bytes()).digest()).decode() != SDK_INTEGRITY:
        raise RuntimeError("WASM SDK checksum mismatch")
    if not (WORK / "sdk/package").exists():
        with tarfile.open(archive) as t:
            t.extractall(WORK / "sdk", filter="data")
    paths["sdk"] = WORK / "sdk/package"
    return paths


def build(paths):
    tools = WORK / "python-tools"
    suffix = ".exe" if sys.platform == "win32" else ""
    cmake = tools / ("cmake/data/bin/cmake" + suffix)
    ninja = tools / ("bin/ninja" + suffix)
    if not cmake.exists() or not ninja.exists():
        subprocess.run([sys.executable, "-m", "pip", "install", "--target", str(tools), "cmake==3.31.6", "ninja==1.11.1.3"], check=True)
    env = os.environ.copy()
    env["PATH"] = str(paths["llvm"] / "bin") + os.pathsep + env["PATH"]
    command = [str(cmake), "-S", str(PROJECT / "native"), "-B", str(WORK / "build"), "-G", "Ninja",
               f"-DCMAKE_MAKE_PROGRAM={ninja.as_posix()}", "-DCMAKE_BUILD_TYPE=Release",
               "-DCMAKE_SYSTEM_NAME=Windows", "-DCMAKE_SYSTEM_PROCESSOR=x86_64",
               "-DCMAKE_C_COMPILER=x86_64-w64-mingw32-clang" + suffix, "-DCMAKE_CXX_COMPILER=x86_64-w64-mingw32-clang++" + suffix,
               f"-DGODOT_CPP_SOURCE={paths['godot-cpp'].as_posix()}", f"-DJSBSIM_SOURCE={paths['jsbsim'].as_posix()}"]
    stamp = WORK / "configure.sha256"
    configuration = hashlib.sha256((json.dumps(command) + (PROJECT / "native/CMakeLists.txt").read_text() + (PROJECT / "native/build_profile.json").read_text()).encode()).hexdigest()
    commands = [] if stamp.exists() and stamp.read_text() == configuration and (WORK / "build/CMakeCache.txt").exists() else [command]
    commands.append([str(cmake), "--build", str(WORK / "build"), "--target", "veski_jsbsim", "-j", "4"])
    with (WORK / "build.log").open("w", encoding="utf-8") as log:
        for args in commands:
            result = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT)
            if result.returncode:
                raise RuntimeError(f"Build failed; see {WORK / 'build.log'}")
    stamp.write_text(configuration)


def package(paths, output=None):
    files = {}
    for p in (PROJECT / "godot").rglob("*"):
        if p.is_file() and p.suffix not in (".uid", ".import"):
            content = p.read_bytes()
            if p.suffix in (".gd", ".tscn", ".tres", ".json", ".txt", ".md", ".js"):
                content = content.replace(b"\r\n", b"\n")
            files[p.relative_to(PROJECT / "godot").as_posix()] = content
    native = {
        "native/veski_jsbsim.dll": (WORK / "build/bin/veski_jsbsim.dll").read_bytes(),
        "native/veski_jsbsim.gdextension": b'[configuration]\nentry_symbol = "veski_jsbsim_init"\ncompatibility_minimum = "4.4"\n[libraries]\nwindows.x86_64 = "veski_jsbsim.dll"\n',
    }
    data = ["aircraft/c172p/c172p.xml", "engine/eng_io320.xml", "engine/prop_75in2f.xml"]
    for name in data:
        native["data/" + name] = (paths["jsbsim"] / name).read_bytes()
    for name, content in native.items():
        files[RES + "/" + name] = content
    for name in ["index.js", "wasm/jsbsim_wasm.mjs", "wasm/jsbsim_wasm.wasm"]:
        files[RES + "/web/" + Path(name).name] = (paths["sdk"] / "dist" / name).read_bytes()
    manifest = {"native": {k: hashlib.sha256(v).hexdigest() for k, v in native.items()}, "data": data}
    files[RES + "/assets.json"] = json.dumps(manifest).encode()
    for name, path in {"JSBSim-LGPL.txt": paths["jsbsim"] / "COPYING", "godot-cpp-MIT.txt": paths["godot-cpp"] / "LICENSE.md", "SDK-MIT.txt": paths["sdk"] / "LICENSE", "LLVM-runtime.txt": paths["llvm"] / "LICENSE.TXT"}.items():
        files[RES + "/licenses/" + name] = path.read_bytes()
    provenance = {"JSBSim": "1.2.4", "godot-cpp": "godot-4.4-stable", "WASM-SDK": "1.2.4-beta.4", "sources": SOURCES}
    files[RES + "/licenses/sources.json"] = json.dumps(provenance, indent=2).encode()
    # Keep rebuildable sources beside the binary package for later distribution.
    with zipfile.ZipFile(WORK / "cessna172-runtime-sources.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for name in ["jsbsim.zip", "godot-cpp.zip", "jsbsim-wasm.tgz"]:
            archive.write(WORK / name, "upstream/" + name)
        archive.write(PROJECT / "extension.yaml", "cessna172/extension.yaml")
        archive.write(PROJECT / "visual-source.zip", "cessna172/visual-source.zip")
        archive.write(PROJECT / "sixpack-source.zip", "cessna172/sixpack-source.zip")
        archive.write(PROJECT / "trim-source.zip", "cessna172/trim-source.zip")
        for folder in [PROJECT / "native", PROJECT / "scripts", PROJECT / "godot"]:
            for path in folder.rglob("*"):
                if path.is_file() and "__pycache__" not in path.parts:
                    archive.write(path, "cessna172/" + path.relative_to(PROJECT).as_posix())
    package_path = WORK / "cessna172-runtime.zip"
    if output:
        # The package version remains owned by extension.yaml.
        import yaml
        version = yaml.safe_load((PROJECT / "extension.yaml").read_text(encoding="utf-8"))["version"]
        output.mkdir(parents=True, exist_ok=True)
        package_path = output / f"cessna172-{version}.zip"
        shutil.copyfile(WORK / "cessna172-runtime-sources.zip", output / f"cessna172-{version}-sources.zip")
    with zipfile.ZipFile(package_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(name)
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
    print(f"Package: {package_path} ({package_path.stat().st_size:,} bytes)", flush=True)
    return package_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-only", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    paths = sources()
    if not args.package_only:
        build(paths)
    package(paths, args.output)
