extends Node3D
## C172P sound curves (closed cabin); live RPM, airspeed, alpha and flaps from JSBSim.
## Adapted from c172-sound.xml and Systems/{sounds,c172p-sounds}.xml; see provenance.
const AircraftModel = preload("../jsbsim_model.gd")
const SETTINGS := "user://cessna172-sound.cfg"
const ROOT := "res://extensions/cessna172/sounds/"
var vehicle: Vehicle
const DEFAULT_LEVELS := {"engine": 1.0, "stall": 1.0, "wind": 1.0}
# C172P horn pitch table: alpha degrees, then normalized pitch at flaps 0/10/20/30°.
const HORN_PITCH := [
	[9.5, 0, 0, 0, 0], [9.5428, 0, 0, 0, 0.5],
	[10.0, 0, 0, 0, 0.5], [10.0428, 0, 0, 0.5, 0.5],
	[10.5, 0, 0, 0.5, 0.5], [10.5428, 0, 0.5, 0.5, 1],
	[11.0, 0, 0.5, 0.5, 1], [11.0428, 0.5, 0.5, 1, 1],
	[11.5, 0.5, 0.5, 1, 1], [11.5428, 0.5, 1, 1, 1],
	[12.0, 0.5, 1, 1, 1], [12.0428, 1, 1, 1, 1],
]
var levels := DEFAULT_LEVELS.duplicate()
var hud_shown := false
var voices := {}
var _web: JavaScriptObject

func _ready() -> void:
	var saved := ConfigFile.new()
	if saved.load(SETTINGS) == OK:
		for key in levels:
			var value = saved.get_value("volume", key, levels[key])
			if (value is float or value is int) and is_finite(value): levels[key] = clampf(value, 0, 1)
		hud_shown = bool(saved.get_value("hud", "shown", false))
	var wind := _stream("wind1.wav")
	_add_voice("engine", _stream("engine.wav"), Vector3(0, 0, -2))
	_add_voice("starter", _stream("engine-crank.wav"), Vector3(0, 0, -2))
	_add_voice("idle", _stream("engine-idle.wav"), Vector3(0, 0, -2))
	_add_voice("stall", _stream("stall2.wav"), Vector3.ZERO)
	voices.stall.attenuation_model = AudioStreamPlayer3D.ATTENUATION_DISABLED
	_add_voice("wind_left", wind, Vector3(-1.5, 0, 0))
	_add_voice("wind_right", wind, Vector3(1.5, 0, 0))

func _stream(file: String) -> AudioStreamWAV:
	var sample := AudioStreamWAV.load_from_buffer(FileAccess.get_file_as_bytes(ROOT + file))
	if sample != null:
		sample.loop_end = roundi(sample.get_length() * sample.mix_rate)
		sample.loop_begin = 0
		sample.loop_mode = AudioStreamWAV.LOOP_FORWARD
	return sample

func _add_voice(id: String, sample: AudioStreamWAV, at: Vector3) -> void:
	var voice := AudioStreamPlayer3D.new()
	voice.name = id
	voice.stream = sample
	voice.position = at
	voice.unit_size = 20
	voice.max_db = 0
	voice.volume_db = -80
	# Desktop streams raw WAVs; Web Audio mirrors these mixing parameters.
	voice.playback_type = AudioServer.PLAYBACK_TYPE_STREAM
	add_child(voice)
	voices[id] = voice

func _process(delta: float) -> void:
	var model = vehicle.registered_model
	if not model is AircraftModel or not model.model_ready or vehicle.simulation_stopped:
		for voice in voices.values(): voice.stop()
		if _web != null: _web.pause()
		return
	global_transform = vehicle.global_transform
	var paused: bool = vehicle.simulation_paused or not vehicle.has_focus or not model.model_pause_reason.is_empty()
	mix(model.state, delta, paused)
	if OS.has_feature("web"):
		if _web == null:
			JavaScriptBridge.eval(FileAccess.get_file_as_string(ROOT + "web_audio.js"), true)
			var files := {"engine": "engine.wav", "idle": "engine-idle.wav", "starter": "engine-crank.wav", "stall": "stall2.wav", "wind": "wind1.wav"}
			for key in files: files[key] = Marshalls.raw_to_base64(FileAccess.get_file_as_bytes(ROOT + files[key]))
			_web = JavaScriptBridge.get_interface("VeskiCessnaAudio").start(JSON.stringify(files))
		var camera: Transform3D = vehicle.camera.global_transform
		var values := {"paused": paused, "position": _xyz(camera.origin), "forward": _xyz(-camera.basis.z), "up": _xyz(camera.basis.y), "voices": {}}
		for id in voices:
			var voice: AudioStreamPlayer3D = voices[id]
			values.voices[id] = {"gain": voice.volume_linear, "pitch": voice.pitch_scale, "position": _xyz(voice.global_position)}
		_web.update(JSON.stringify(values))

func mix(state: Dictionary, delta: float, paused := false) -> void:
	var cranking: bool = state.get("engine_cranking", 0.0) > 0 and state.get("engine_running", 1.0) == 0
	_drive("starter", levels.engine * 0.7843 if cranking else 0.0, 1, delta, paused)
	var rpm: float = maxf(0, state.propeller_rpm)
	var knots: float = maxf(0, state.indicated_kts)
	# Closed-cabin gain = 1. Idle remains layered beneath the running-engine sample.
	# SimGear adds the positive volume offset after multiplying its volume factors.
	var running := clampf(rpm * 0.001, 0, 1)
	var engine := clampf(running * clampf(rpm * 0.000294118, 0.5, 0.95) + 0.205882353, 0, 1) if rpm > 10 else 0.0
	var idle := running * clampf(1.923076923 - rpm * 0.000769231, 0, 1) if rpm > 10 else 0.0
	_drive("engine", levels.engine * engine, clampf(rpm * 0.000434783, 0, 2) + 0.01, delta, paused)
	_drive("idle", levels.engine * idle, 1, delta, paused)
	var alpha: float = state.alpha_deg
	var flaps := clampf(state.flap_deg, 0, 30)
	var threshold := lerpf(11.6364, 10.1364, flaps / 10) if flaps <= 10 else lerpf(10.1364, 9.6364, (flaps - 10) / 20)
	# Guard log10's domain; below the threshold the clipped source curve is silent.
	var horn := clampf(log(maxf(1, (alpha - threshold + 0.5) * 2)) / log(10), 0, 1)
	if knots <= 10 or state.weight_on_wheels > 0: horn = 0
	_drive("stall", levels.stall * horn, _horn_pitch(alpha, flaps), delta, paused)
	# Authored altitude attenuation and per-side wind gain; doors/windows closed.
	var altitude := clampf(1 - state.altitude_m / 0.3048 * 0.000015, 0.1, 1)
	var wind := maxf(0, altitude * clampf(knots * 0.0015, 0.03, 0.25) * 0.7 - 0.03) * float(levels.wind)
	for id in ["wind_left", "wind_right"]:
		_drive(id, wind, 1.25 + knots * 0.0035, delta, paused)

func _horn_pitch(alpha: float, flaps: float) -> float:
	var row := 0
	while row < HORN_PITCH.size() - 2 and alpha > HORN_PITCH[row + 1][0]: row += 1
	var column := mini(int(flaps / 10), 2)
	var fraction := (flaps - column * 10) / 10
	var low := lerpf(HORN_PITCH[row][column + 1], HORN_PITCH[row][column + 2], fraction)
	var high := lerpf(HORN_PITCH[row + 1][column + 1], HORN_PITCH[row + 1][column + 2], fraction)
	var weight := clampf(inverse_lerp(HORN_PITCH[row][0], HORN_PITCH[row + 1][0], alpha), 0, 1)
	return 0.9 + 0.2 * lerpf(low, high, weight)

func _drive(id: String, gain: float, pitch: float, delta: float, paused: bool) -> void:
	var voice: AudioStreamPlayer3D = voices[id]
	voice.pitch_scale = pitch
	voice.volume_linear = lerpf(voice.volume_linear, gain, 1 - exp(-delta * 15)) if gain > 0 else 0.0
	if not voice.playing and not paused:
		voice.play(4.2 if id == "wind_right" else 0.0)
	voice.stream_paused = paused

func set_level(id: String, value: float) -> void:
	if levels.has(id) and is_finite(value): levels[id] = clampf(value, 0, 1)

func save() -> void:
	var saved := ConfigFile.new()
	for key in levels: saved.set_value("volume", key, levels[key])
	saved.set_value("hud", "shown", hud_shown)
	if saved.save(SETTINGS) != OK: push_error("Cessna-Lautstärken konnten nicht gespeichert werden.")

func _xyz(value: Vector3) -> Array:
	return [value.x, value.y, value.z]

func _exit_tree() -> void:
	if _web != null: _web.dispose()
	for voice in voices.values():
		voice.stop()
		voice.stream = null
