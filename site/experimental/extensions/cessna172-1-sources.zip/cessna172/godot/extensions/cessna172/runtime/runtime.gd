extends RefCounted
## Common JSBSim policy for Windows and Web. Angles are radians, distances metres.
## load_runtime(tree) -> initialize(initial) -> step(commands, delta_t) / read_state().
## Commands: trim-relative aileron/elevator/rudder (-1..1), absolute throttle (0..1).
## Pause freezes simulation time; reset repeats the initial trimmed state; dispose frees it.
const ROOT := "res://extensions/cessna172/runtime/"
const STATE_PROPERTIES := {
	"latitude_deg": "position/lat-geod-deg", "longitude_deg": "position/long-gc-deg",
	"altitude_m": "position/h-sl-ft", "airspeed_mps": "velocities/vtrue-fps",
	"roll_rad": "attitude/phi-rad", "pitch_rad": "attitude/theta-rad", "yaw_rad": "attitude/psi-rad",
	"time_s": "simulation/sim-time-sec",
	"left_aileron_rad": "fcs/left-aileron-pos-rad", "right_aileron_rad": "fcs/right-aileron-pos-rad",
	"elevator_rad": "fcs/elevator-pos-rad", "rudder_rad": "fcs/rudder-pos-rad",
	"propeller_rpm": "propulsion/engine/propeller-rpm",
	"engine_running": "propulsion/engine/set-running",
	"engine_cranking": "propulsion/starter_cmd",
	"ground_speed_mps": "velocities/vg-fps",
	"stall_warning": "systems/stall-warn-norm",
	"alpha_deg": "aero/alpha-deg", "flap_deg": "fcs/flap-pos-deg",
	"weight_on_wheels": "gear/wow",
	"indicated_kts": "velocities/vc-kts", "pressure_altitude_ft": "atmosphere/pressure-altitude",
	"climb_fps": "velocities/h-dot-fps", "roll_rate_rps": "velocities/p-rad_sec",
	"yaw_rate_rps": "velocities/r-rad_sec", "pilot_y_fps2": "accelerations/a-pilot-y-ft_sec2",
	"pilot_z_fps2": "accelerations/a-pilot-z-ft_sec2",
}
var error := ""
var ready := false
var paused := false
var trim := Vector4.ZERO
var starter_seconds := 0.0
var mixture := 1.0 # Lever position: 0 = idle cutoff, 1 = full rich.
var pitch_trim := 0.0 # Pilot convention: positive means nose up, opposite to JSBSim elevator sign.
var _backend: Variant
var _initial: Dictionary
var _ticket: Variant
var _generation := 0

func load_runtime(tree: SceneTree) -> bool:
	dispose()
	error = ""
	var generation := _generation
	if not FileAccess.file_exists(ROOT + "assets.json"):
		return _fail("JSBSim runtime assets are missing; build the runtime package first.")
	var manifest: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(ROOT + "assets.json"))
	if OS.has_feature("web"):
		JavaScriptBridge.eval(FileAccess.get_file_as_string(ROOT + "web_backend.js"), true)
		var data := {}
		for path in manifest.data:
			data[path] = FileAccess.get_file_as_string(ROOT + "data/" + path)
		_ticket = JavaScriptBridge.get_interface("VeskiJSBSimWeb").start(
			FileAccess.get_file_as_string(ROOT + "web/index.js"),
			FileAccess.get_file_as_string(ROOT + "web/jsbsim_wasm.mjs"),
			Marshalls.raw_to_base64(FileAccess.get_file_as_bytes(ROOT + "web/jsbsim_wasm.wasm")), JSON.stringify(data))
		while _ticket != null and _ticket.state == "loading" and generation == _generation:
			await tree.process_frame
		if generation != _generation: return false
		if _ticket.state != "ready": return _fail(str(_ticket.error))
		_backend = _ticket.backend
		_ticket = null
	elif OS.get_name() == "Windows" and Engine.get_architecture_name() == "x86_64":
		var directory := _extract_native(manifest.native)
		if directory.is_empty(): return false
		var library := directory + "/native/veski_jsbsim.gdextension"
		if not GDExtensionManager.is_extension_loaded(library):
			if ClassDB.class_exists("VeskiJSBSimBackend"):
				return _fail("A different JSBSim library is loaded; restart VeSKi to update it.")
			if GDExtensionManager.load_extension(library) != GDExtensionManager.LOAD_STATUS_OK:
				return _fail("Could not load the native JSBSim library.")
		_backend = ClassDB.instantiate("VeskiJSBSimBackend")
		if not _backend.open(directory + "/data"): return _fail(str(_backend.get_error()))
	else:
		return _fail("JSBSim currently supports Web and Windows x86_64.")
	if not _backend.loadModel("c172p"): return _fail("Could not load C172P: " + str(_backend.get_error()))
	return true

func _extract_native(files: Dictionary) -> String:
	# Native libraries and JSBSim XML must be physical files, not ZIP-only resources.
	var directory := ProjectSettings.globalize_path("user://cessna172-runtime/" + FileAccess.get_sha256(ROOT + "assets.json"))
	for path: String in files:
		if path.is_absolute_path() or ".." in path.split("/"):
			_fail("Invalid runtime asset path.")
			return ""
		var target := directory.path_join(path)
		if FileAccess.file_exists(target) and FileAccess.get_sha256(target) == files[path]: continue
		if FileAccess.get_sha256(ROOT + path) != files[path]:
			_fail("Runtime asset checksum mismatch: " + path)
			return ""
		if DirAccess.make_dir_recursive_absolute(target.get_base_dir()) != OK:
			_fail("Could not create runtime directory.")
			return ""
		var file := FileAccess.open(target, FileAccess.WRITE)
		if file == null:
			_fail("Could not extract runtime asset: " + path)
			return ""
		file.store_buffer(FileAccess.get_file_as_bytes(ROOT + path))
		file.close()
	return directory

func _number(value: float) -> Variant:
	# JavaScriptBridge narrows numeric call arguments to float32; decimal strings retain double precision.
	return String.num(value, 17) if OS.has_feature("web") else value

func initialize(initial: Dictionary = {}) -> bool:
	if _backend == null: return _fail("Load the runtime before initialization.")
	starter_seconds = 0.0
	_initial = initial.duplicate()
	var properties := {
		"ic/h-sl-ft": initial.get("altitude_m", 400.0) / 0.3048,
		"ic/vc-kts": initial.get("calibrated_airspeed_mps", 100.0 * 0.5144444444444444) / 0.5144444444444444,
		"ic/lat-geod-deg": initial.get("latitude_deg", -44.0), "ic/long-gc-deg": initial.get("longitude_deg", 170.0),
		"ic/psi-true-deg": rad_to_deg(initial.get("heading_rad", 0.0)),
		"ic/phi-deg": 0.0, "ic/theta-deg": 0.0, "ic/gamma-deg": 0.0,
		"ic/p-rad_sec": 0.0, "ic/q-rad_sec": 0.0, "ic/r-rad_sec": 0.0,
		"fcs/aileron-cmd-norm": 0.0, "fcs/elevator-cmd-norm": 0.0, "fcs/rudder-cmd-norm": 0.0,
		"fcs/pitch-trim-cmd-norm": 0.0, "fcs/roll-trim-cmd-norm": 0.0, "fcs/yaw-trim-cmd-norm": 0.0,
		"fcs/throttle-cmd-norm": 0.65,
		"fcs/mixture-cmd-norm": 1.0, "propulsion/starter_cmd": 0.0, "propulsion/magneto_cmd": 3.0, "propulsion/set-running": -1.0,
	}
	_backend.setDt(_number(1.0 / 60.0))
	for key: String in properties: _backend.setPropertyValue(key, _number(properties[key]))
	if not _backend.runIc(): return _fail("JSBSim initialization failed: " + str(_backend.get_error()))
	_backend.doTrim(1) # Full initial equilibrium, not an in-flight autopilot.
	if not str(_backend.get_error()).is_empty(): return _fail(str(_backend.get_error()))
	trim = Vector4(_backend.getPropertyValue("fcs/aileron-cmd-norm"), _backend.getPropertyValue("fcs/elevator-cmd-norm"), _backend.getPropertyValue("fcs/rudder-cmd-norm"), _backend.getPropertyValue("fcs/throttle-cmd-norm"))
	pitch_trim = -float(_backend.getPropertyValue("fcs/pitch-trim-cmd-norm"))
	mixture = float(_backend.getPropertyValue("fcs/mixture-cmd-norm"))
	ready = true
	paused = false
	return true

func start_engine() -> void:
	if not ready or paused or starter_seconds > 0.0: return
	if float(_backend.getPropertyValue("propulsion/engine/set-running")) > 0.0: return
	_backend.setPropertyValue("propulsion/magneto_cmd", _number(3.0))
	_backend.setPropertyValue("propulsion/starter_cmd", _number(1.0))
	starter_seconds = 5.0

func set_mixture(value: float) -> void:
	if not ready or not is_finite(value): return
	mixture = clampf(value, 0.0, 1.0)
	_backend.setPropertyValue("fcs/mixture-cmd-norm", _number(mixture))

func set_pitch_trim(value: float) -> void:
	if not ready or not is_finite(value): return
	pitch_trim = clampf(value, -1.0, 1.0)
	_backend.setPropertyValue("fcs/pitch-trim-cmd-norm", _number(-pitch_trim))

func step(commands: Vector4, delta_t: float) -> Dictionary:
	if not ready: return {}
	if paused: return read_state()
	if not is_finite(delta_t) or delta_t <= 0.0 or not commands.is_finite():
		_fail("JSBSim requires finite commands and a positive time step.")
		return {}
	if starter_seconds > 0.0:
		starter_seconds = maxf(0.0, starter_seconds - delta_t)
		if float(_backend.getPropertyValue("propulsion/engine/set-running")) > 0.0: starter_seconds = 0.0
		if starter_seconds == 0.0: _backend.setPropertyValue("propulsion/starter_cmd", _number(0.0))
	_backend.setDt(_number(delta_t))
	_backend.setPropertyValue("fcs/aileron-cmd-norm", _number(clampf(trim.x + commands.x, -1.0, 1.0)))
	_backend.setPropertyValue("fcs/elevator-cmd-norm", _number(clampf(trim.y - commands.y, -1.0, 1.0)))
	_backend.setPropertyValue("fcs/rudder-cmd-norm", _number(clampf(trim.z + commands.z, -1.0, 1.0)))
	_backend.setPropertyValue("fcs/throttle-cmd-norm", _number(clampf(commands.w, 0.0, 1.0)))
	if not _backend.run():
		_fail("JSBSim step failed: " + str(_backend.get_error()))
		return {}
	return read_state()

func read_state() -> Dictionary:
	if not ready: return {}
	var result := {}
	for key: String in STATE_PROPERTIES:
		var value := float(_backend.getPropertyValue(STATE_PROPERTIES[key]))
		if not is_finite(value):
			_fail("JSBSim returned a non-finite state: " + key)
			return {}
		if key.ends_with("_rad"): value = wrapf(value, -PI, PI)
		result[key] = value * 0.3048 if key in ["altitude_m", "airspeed_mps", "ground_speed_mps"] else value
	return result

func reset() -> bool:
	if _backend == null: return _fail("Load the runtime before reset.")
	_backend.resetToInitialConditions(0)
	return initialize(_initial)

func dispose() -> void:
	_generation += 1
	if _ticket != null:
		_ticket.cancelled = true
		if _ticket.backend != null: _ticket.backend.destroy()
		_ticket = null
	if _backend != null:
		_backend.destroy()
		_backend = null
	ready = false
	paused = false
	# Keep the native library mapped; live Godot class bindings cannot be safely unloaded here.

func _fail(message: String) -> bool:
	error = message
	dispose()
	return false
