// Loaded from the mounted ZIP. All runtime bytes come from Godot's virtual FS.
globalThis.VeskiJSBSimWeb = {
  start(sdkSource, moduleSource, wasmBase64, dataJSON) {
    const ticket = {state: 'loading', error: '', backend: null, cancelled: false};
    (async () => {
      const urls = [];
      const url = source => {const u = URL.createObjectURL(new Blob([source], {type: 'text/javascript'})); urls.push(u); return u;};
      let sdk;
      const destroy = () => {
        if (!sdk) return;
        // SDK beta.4 only calls optional module.destroy; embind actually provides exec.delete().
        if (!sdk.module.destroy) sdk.exec.delete();
        sdk.destroy();
        sdk = null;
      };
      try {
        const {JSBSimSdk} = await import(url(sdkSource));
        const {default: factory} = await import(url(moduleSource));
        const wasmBinary = Uint8Array.from(atob(wasmBase64), c => c.charCodeAt(0));
        sdk = await JSBSimSdk.create({moduleFactory: options => factory({...options, wasmBinary}), log: {console: false}});
        for (const [name, contents] of Object.entries(JSON.parse(dataJSON))) sdk.writeDataFile(name, contents);
        const backend = {error: '', get_error() {return this.error;}, destroy};
        for (const name of ['loadModel', 'setPropertyValue', 'getPropertyValue', 'setDt', 'runIc', 'doTrim', 'resetToInitialConditions', 'run']) {
          backend[name] = (...args) => {
            try {
              if (name === 'setDt') args[0] = Number(args[0]);
              if (name === 'setPropertyValue') args[1] = Number(args[1]);
              return sdk[name](...args);
            } catch (e) {backend.error = String(e); return false;}
          };
        }
        if (ticket.cancelled) destroy();
        else {ticket.backend = backend; ticket.state = 'ready';}
      } catch (e) {
        destroy(); ticket.error = String(e); ticket.state = 'error';
      } finally {urls.forEach(u => URL.revokeObjectURL(u));}
    })();
    return ticket;
  },
};
